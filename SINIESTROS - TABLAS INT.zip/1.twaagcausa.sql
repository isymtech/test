REM INSERTING into TWAAGCAUSA
SET DEFINE OFF;
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('173','1','0','TODAS LAS CAUSAS','Reclamaci�n Protecci�n Jur�dica','|6|7|8|10|',null,'<p>AXA se har&aacute; cargo de la reclamaci&oacute;n de da&ntilde;os y/o perjuicios que otras personas que no teniendo ning&uacute;n contrato con el asegurado, le hayan causado, a la Edificaci&oacute;n y/o Enseres asegurados y a su persona, expresamente reclamaci&oacute;n de da&ntilde;os corporales en caso de conducci&oacute;n de bicicletas, atropello y ca&iacute;da accidental atribuible a un tercero.<br />
&middot; Reclamaci&oacute;n contractual por obras en el inmueble: AXA se har&aacute; cargo de la reclamaci&oacute;n derivada de incumplimientos de contratos de prestaci&oacute;n de servicios de reparaci&oacute;n, mantenimiento o reforma que hayan suscrito en relaci&oacute;n con la Edificaci&oacute;n y/o enseres asegurados, siempre que se haya abonado la factura y salvo que se trate de contratos de suministro de agua, luz, gas, tel&eacute;fono o Internet.<br />
&middot; Reclamaci&oacute;n contractual por cosas muebles: AXA se har&aacute; cargo de la reclamaci&oacute;n derivada de incumplimientos del vendedor, en contratos de compraventa que afecten a los Enseres asegurados.<br />
&middot; Reclamaciones por riesgos extraordinarios: AXA gestionar&aacute; la reclamaci&oacute;n en caso de incumplimiento por parte del Consorcio de Compensaci&oacute;n de Seguros que impida que el asegurado pueda hacer efectivos los derechos que se derivan de la cl&aacute;usula de cobertura de riesgos extraordinarios que se incluye en la p&oacute;liza.<br />
. Reclamaciones frente a otras aseguradoras: En caso de incumplimiento de otra Aseguradora por p&oacute;lizas de seguro en vigor en relaci&oacute;n con la vivienda asegurada, contratadas por el asegurado, o de las que cliente fuera beneficiario, AXA realizar&aacute; la reclamaci&oacute;n para hacer valer sus derechos.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'133','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('108','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Perdida de beneficios','|8|10|','PJ','<p>Aquellas reclamaciones que no hubieran sido identificadas en las subcausas anteriores.</p>',to_date('30/11/21','DD/MM/RR'),'10','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('107','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Otros','|6|7|8|10|','PJ','<p>Aquellas reclamaciones que no hubieran sido identificadas en las subcausas anteriores.</p>',to_date('30/11/21','DD/MM/RR'),'9','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('48','1','9','INCENDIO','Explosion','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
&middot; Da&ntilde;os materiales que sufran los bienes asegurados cuando se destruyan a consecuencia de incendio y/o explosi&oacute;n.<br />
&middot; Los da&ntilde;os ocasionados a los veh&iacute;culos a motor, remolques, caravanas y embarcaciones de recreo cuando se encuentren estacionados dentro del garaje de la vivienda asegurada en el momento de producirse el incendio.<br />
<strong>No est&aacute; cubierto:</strong><br />
&middot; Los da&ntilde;os en los bienes asegurados que no sean debidos a incendio, por ejemplo, los da&ntilde;os provocados por chispas, chispazos, cigarrillos, braseros o elementos de calor, de los que no se derive incendio.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'102','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('120','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Perjuicios','|6|7|8|10|','PJ','<p>La reclamaci&oacute;n de da&ntilde;os y/o perjuicios que otras personas que no teniendo ning&uacute;n contrato con Usted, le hayan causado, a la Edificaci&oacute;n y/o Enseres asegurados.</p>',to_date('30/11/21','DD/MM/RR'),'25','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('35','1','5','ROTURAS','Rotura vitroceramica','|6|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
La rotura de cristal de placa vitrocer&aacute;mica o de inducci&oacute;n, incluidos los gastos de transporte, colocaci&oacute;n y montaje.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Simples ara&ntilde;azos, raspaduras, desconchados o deterioros superficiales<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'168','																																																									 
								Si el aparato afectado es de MARCA TEKA , recuerda que puedes asignar a TEKA INDUSTRIAL manualmente, para esta causa.  Recuerda que en esta garant�a solo cubrimos la rotura del cristal, las aver�as tienen como causa de apertura Da�os el�ctricos.
				 
												 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('185','1','1','DA�OS AGUA-OTROS L�QUIDOS','Atasco - Da�os Agua','|6|7|8|10|',null,null,to_date('22/06/22','DD/MM/RR'),'197',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('186','1','1','DA�OS AGUA-OTROS L�QUIDOS','Atasco - Sin Da�os','|6|7|8|10|',null,null,to_date('22/06/22','DD/MM/RR'),'198',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('115','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Reclamaci�n frente a otras Aseguradoras','|6|','PJ','<p>Aquellas reclamaciones que no hubieran sido identificadas en las subcausas anteriores.</p>',to_date('30/11/21','DD/MM/RR'),'30','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('116','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Reclamaci�n honorarios ','|8|10|','PJ','<p>La reclamaci&oacute;n amistosa, o judicial en su caso, de los honorarios del tomador del seguro o asegurado generados en el ejercicio de la actividad profesional descrita.</p>',to_date('30/11/21','DD/MM/RR'),'13','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('117','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Reclamaci�n lesiones','|6|8|10|','PJ','<p>La reclamaci&oacute;n de da&ntilde;os y/o perjuicios que otras personas que no teniendo ning&uacute;n contrato con Usted, le hayan causado a sus personas.</p>',to_date('30/11/21','DD/MM/RR'),'24','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('118','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Reclamaci�n por incumplimento contrato servicios','|6|7|8|10|','PJ','<p>La reclamaci&oacute;n por incumplimiento de los contratos de arrendamiento de servicios, que afecten a la actividad del tomador del seguro o asegurado y de los que sea titular y destinatario &uacute;ltimo.</p>',to_date('30/11/21','DD/MM/RR'),'12','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('111','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Reclamaci�n al Propietario/ Arrendador','|6|8|10|','PJ','<p>Como inquilino, esta garant&iacute;a comprende:<br />
&bull; La defensa y reclamaci&oacute;n en los conflictos derivados del contrato de alquiler. No quedan cubiertos por esta garant&iacute;alos juicios de desahucio por falta de pago.</p>',to_date('30/11/21','DD/MM/RR'),'29','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('112','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Reclamacion contractual','|6|7|8|10|','PJ','<p>Aquellas reclamaciones que no hubieran sido identificadas en las subcausas anteriores.</p>',to_date('30/11/21','DD/MM/RR'),'12','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('114','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Reclamaci�n de morosos ','|7|','PJ','<p>La Defensa de los intereses de la Comunidad de Propietarios, reclamando amistosa o judicialmente en su caso, contra aquellos propietarios morosos que no est&eacute;n al corriente de pago de los gastos generales que les corresponde de acuerdo su cuota de participaci&oacute;n.</p>',to_date('30/11/21','DD/MM/RR'),'33','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('119','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Reclamaci�n reparadores','|6|7|8|10|','PJ','<p>La reclamaci&oacute;n por incumplimiento de los contratos de servicios de reparaci&oacute;n o mantenimiento de las instalaciones del local.</p>',to_date('30/11/21','DD/MM/RR'),'15','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('15','3','15','AUTOS','Da�os Producidos por la carga','|2|',null,'<p>Siniestro ocasionado por  el desprendimiento de carga transportada en el veh&iacute;culo asegurado y que haya causado da&ntilde;os a terceros, o por carga desprendida de otro veh&iacute;culo que haya causado da&ntilde;os en el veh&iacute;culo asegurado.</p>',to_date('14/03/17','DD/MM/RR'),'229',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('2','4','2','SANCIONES','Conducir con tasa de alcohol superior a la permitida (Alcoholemia)','|2|',null,'<p>Circular con una tasa de alcohol en aire espirado superior a la reglamentariamente establecida.</p>',to_date('06/04/17','DD/MM/RR'),'2',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('3','4','3','SANCIONES','Sanci�n de tr�fico en v�a ejecutiva','|2|','Providencia de Apremio','<p>Supuestos en los que se reciba notificaci&oacute;n de multa con un porcentaje de recargo a&ntilde;adido procedente de agencia tributaria, de hacienda, diputaci&oacute;n o ayuntamieno cuando ya ha finalizado el periodo de pago voluntaria y se encuentra en v&iacute;a ejecutiva (ejecuci&oacute;n forzosa)</p>',to_date('06/04/17','DD/MM/RR'),'24',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('174','1','0','TODAS LAS CAUSAS','Responsabilidad civil','|6|7|8|10|',null,'<p>El &aacute;mbito geogr&aacute;fico de cobertura, es de aplicaci&oacute;n en todo el mundo a excepci&oacute;n de Estados Unidos de Am&eacute;rica y Canad&aacute;.<br />
  <strong>Qu&eacute; est&aacute; cubierto:<br />
Responsabilidad civil como propietario del inmueble</strong><br />
Si el asegurado es el propietario de la edificaci&oacute;n asegurada y por esta causa el cliente o los miembros de su familia fueran civilmente responsables, AXA cubre la obligaci&oacute;n de indemnizar los da&ntilde;os y perjuicios causados a terceros.<br />
<strong>Responsabilidad civil familiar</strong><br />
AXA cubre la obligaci&oacute;n de indemnizar los da&ntilde;os y perjuicios causados a terceros, cuando el asegurado o los miembros de su familia sean civilmente responsables en el &aacute;mbito de su vida familiar privada.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
Las reclamaciones derivadas de:<br />
&middot; El uso, tenencia, transporte o almacenamiento de armas y/o explosivos de cualquier clase.<br />
&middot; Da&ntilde;os a bienes de terceros que est&eacute;n en su poder.<br />
&middot; Obligaciones contractuales.<br />
&middot; Responsabilidades profesionales.<br />
&middot; Da&ntilde;os que deban ser objeto de cobertura por un seguro obligatorio; quedar&aacute; tambi&eacute;n excluido el exceso de lo legal.<br />
&middot; Incumplimiento de disposiciones oficiales. En ning&uacute;n caso la Entidad Aseguradora se hace cargo de multas o sanciones ni de las consecuencias de su impago.<br />
&middot; Perjuicios no consecutivos, entendi&eacute;ndose por tales, las p&eacute;rdidas econ&oacute;micas que no sean consecuencia directa de un da&ntilde;o personal o material, as&iacute; como aquellas p&eacute;rdidas econ&oacute;micas que sean consecuencia de un da&ntilde;o personal o material no amparado por la p&oacute;liza.<br />
&middot; Da&ntilde;os que tengan su origen en la pr&aacute;ctica deportiva, cuando el asegurado o los miembros de su familia dispongan de ficha federativa.<br />
&middot; El uso y circulaci&oacute;n de veh&iacute;culos a motor, y/o de los elementos remolcados o incorporados a los mismos.<br />
&middot; Derivadas de la contaminaci&oacute;n del suelo, las aguas o la atm&oacute;sfera.<br />
&middot; Reclamaciones que el propietario-arrendador haga al inquilino-asegurado, diferentes de las derivadas de incendio, explosi&oacute;n y da&ntilde;os por agua<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&neas generales de contrataci�n, para el siniestro en concreto se aplicar�n las condiciones generales y particulares de la p�liza contratada por el asegurado.</strong>',to_date('30/11/21','DD/MM/RR'),'122','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('175','1','0','TODAS LAS CAUSAS','Robo','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
El robo y expoliaci&oacute;n producido con fuerza en las cosas para acceder a ellas o con violencia o intimidaci&oacute;n a las personas, y que afecte a:<br />
&middot; El mobiliario<br />
&middot; Las joyas o alhajas hasta el l&iacute;mite indicado en p&oacute;liza. <br />
&middot; Dinero en efectivo, hasta el l&iacute;mite indicado en p&oacute;liza.<br />
. Los da&ntilde;os materiales y desperfectos causados a los bienes asegurados durante el robo.<br />
. El robo de los elementos de la edificaci&oacute;n<br />
. Los gastos de reposici&oacute;n de llaves y cerraduras, por otras de similares prestaciones y caracter&iacute;sticas, si deben ser sustituidas a consecuencia de un robo como medida de precauci&oacute;n para evitar el f&aacute;cil acceso a la vivienda, hasta el l&iacute;mite indicado en p&oacute;liza. <br />
. El uso fraudulento de tarjetas de cr&eacute;dito, hasta el l&iacute;mite indicado en p&oacute;liza.<br />
. Hurto, o sustracci&oacute;n sin fuerza en las cosas para acceder al lugar donde se encuentran, ni violencia o intimidaci&oacute;n en las personas, hasta el l&iacute;mite indicado en el apartado Tabla Resumen y que afecte a los enseres asegurados.<br />
. El robo fuera de la vivienda cometido con violencia o intimidaci&oacute;n hacia el asegurado o miembros de su familia de:<br />
&middot; Enseres, hasta el l&iacute;mite indicado en p&oacute;liza.<br />
&middot; Dinero en efectivo, hasta el l&iacute;mite indicado en p&oacute;liza.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; El Hurto de dinero en efectivo.<br />
&middot; El robo y/o hurto de los objetos de valor art&iacute;stico.<br />
. El robo o hurto que afecte a enseres que se encuentren en dependencias que no sean de su uso exclusivo.<br />
&middot; El robo o hurto que afecte a joyas que se encuentren al aire libre, en patios o jardines, o en el interior de construcciones abiertas.<br />
&middot; P&eacute;rdidas o extrav&iacute;os<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'118','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('176','1','0','TODAS LAS CAUSAS','Rotura de r�tulos o letreros','|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
La rotura de letreros y r&oacute;tulos de cristal, metacrilato u otros pl&aacute;sticos de similares caracter&iacute;sticas, que formen parte del acondicionamiento del local hasta el l&iacute;mite del capital contratado, incluidos los gastos de transporte, colocaci&oacute;n y montaje.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Los ara&ntilde;azos, raspaduras, desconchados o deterioros superficiales.<br />
&middot; Marcos, molduras y muebles de los que formen parte.<br />
&middot; Valor de los decorados art&iacute;sticos.<br />
&middot; L&aacute;mparas, bombillas de todas clases, cristaler&iacute;as, aparatos de visi&oacute;n y sonido, lentes, objetos de uso personal.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'126','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('177','1','0','TODAS LAS CAUSAS','Rotura Acuario','|6|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
La rotura de acuarios o peceras de cristal o cualquier otro material, siempre que su capacidad sea superior a 30 litros, incluidos los gastos de transporte, colocaci&oacute;n y montaje. <br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Simples ara&ntilde;azos, raspaduras, desconchados o deterioros superficiales. <br />
&middot; Marcos, molduras y muebles de los que formen parte. <br />
&middot; Valor de los decorados art&iacute;sticos<br />
&middot; L&aacute;mparas y bombillas de todas clases, cristaler&iacute;as, aparatos de visi&oacute;n y sonido, lentes, objetos de uso personal y elementos decorativos no adosados a la edificaci&oacute;n o enseres del hogar de forma fija como: figuras de cristal o m&aacute;rmol, portarretratos.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'175','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('178','1','0','TODAS LAS CAUSAS','Rotura Metacrilato','|6|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
La rotura de muebles, mamparas o estanter&iacute;as de cristal, metacrilato u otros pl&aacute;sticos de similares, incluidos los gastos de transporte, colocaci&oacute;n y montaje.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Simples ara&ntilde;azos, raspaduras, desconchados o deterioros superficiales. <br />
&middot; Marcos, molduras y muebles de los que formen parte. <br />
&middot; Valor de los decorados art&iacute;sticos.<br />
&middot; L&aacute;mparas y bombillas de todas clases, cristaler&iacute;as, aparatos de visi&oacute;n y sonido, lentes, objetos de uso personal y elementos decorativos no adosados a la edificaci&oacute;n o enseres del hogar de forma fija como: figuras de cristal o m&aacute;rmol, portarretratos.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'174','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('179','1','0','TODAS LAS CAUSAS','Rotura placas solares','|6|7|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
La rotura de cristal de placa solar, incluidos los gastos de transporte, colocaci&oacute;n y montaje.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Simples ara&ntilde;azos, raspaduras, desconchados o deterioros superficiales. <br />
&middot; Marcos, molduras y muebles de los que formen parte. <br />
&middot; Valor de los decorados art&iacute;sticos<br />
&middot; L&aacute;mparas y bombillas de todas clases, cristaler&iacute;as, aparatos de visi&oacute;n y sonido, lentes, objetos de uso personal y elementos decorativos no adosados a la edificaci&oacute;n o enseres del hogar de forma fija como: figuras de cristal o m&aacute;rmol, portarretratos.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'169','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('180','1','0','TODAS LAS CAUSAS','Rotura vitroceramica','|6|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
La rotura de cristal de placa vitrocer&aacute;mica o de inducci&oacute;n, incluidos los gastos de transporte, colocaci&oacute;n y montaje.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Simples ara&ntilde;azos, raspaduras, desconchados o deterioros superficiales<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'168','																																																									 
								Si el aparato afectado es de MARCA TEKA , recuerda que puedes asignar a TEKA INDUSTRIAL manualmente, para esta causa.  Recuerda que en esta garant�a solo cubrimos la rotura del cristal, las aver�as tienen como causa de apertura Da�os el�ctricos.
				 
												 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('181','1','0','TODAS LAS CAUSAS','Ruina total','|6|7|',null,'<p>Se cubren los da&ntilde;os materiales a la edificaci&oacute;n y/o enseres asegurados consecuencia directa de obras realizadas por terceros en fincas o edificios colindantes u obras p&uacute;blicas realizadas en las calles adyacentes o el subsuelo y que determine la ruina total de la vivienda asegurada</p>',to_date('30/11/21','DD/MM/RR'),'191','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('182','1','0','TODAS LAS CAUSAS','Todo Riesgo Objetos de arte','|6|7|8|',null,'<p>Cubrimos los objetos de valor art&iacute;stico, que se encuentren declarados en la p&oacute;liza, de robo, atraco, expoliaci&oacute;n o hurto, p&eacute;rdida, incendio o da&ntilde;os accidentales o causados por mala intenci&oacute;n de terceros.</p>',to_date('30/11/21','DD/MM/RR'),'184','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('184','1','0','TODAS LAS CAUSAS','Viento','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os materiales a los bienes asegurados cuando se destruyan a consecuencia del viento de intensidad tal que afecte a varios edificios de buena construcci&oacute;n en las proximidades de la vivienda asegurada. Se incluyen los da&ntilde;os producidos por objetos arrastrados o proyectados por el viento o la lluvia:<br />
&middot; Si la cantidad de lluvia es superior a 40l/m2 y hora, o la velocidad del viento es superior a 84 Km/h., no ser&aacute; necesario el requisito que varios edificios se encuentren afectados.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Los da&ntilde;os a los enseres del hogar que est&eacute;n depositados al aire libre, aun cuando se hallen protegidos por materiales flexibles o contenidos en el interior de construcciones abiertas.<br />
&middot; Los da&ntilde;os producidos por nieve, agua, arena o el polvo que entre por puertas, ventanas u otras aberturas que est&eacute;n sin cerrar o con cierre defectuoso.<br />
&middot; Los da&ntilde;os producidos por heladas, frio o hielo.<br />
&middot; Los da&ntilde;os producidos por olas o mareas, incluso cuando estos fen&oacute;menos hayan sido causados por el viento.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'105','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('113','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Reclamaci�n Da�os por obras','|6|7|8|10|','PJ','<p>La reclamaci&oacute;n de da&ntilde;os y/o perjuicios que otras personas que no teniendo ning&uacute;n contrato con Usted, le hayan causado, a la Edificaci&oacute;n y/o Enseres asegurados.<br />
</p>',to_date('30/11/21','DD/MM/RR'),'3','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('152','1','0','TODAS LAS CAUSAS','Coparticipaci�n Comunidad','|6|8|10|',null,'<p>La coparticipaci&oacute;n es el porcentaje en el que el asegurado participa en copropiedad junto a otras Comunidades en el uso y disfrute de instalaciones comunes, pertenecientes a dichas Comunidades.<br />
Este porcentaje de coparticipaci&oacute;n formar&aacute; parte del capital asegurado para los diferentes tipos de siniestros.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'130','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('183','1','0','TODAS LAS CAUSAS','Traslado por decisi�n de la autoridad','|6|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
AXA se hace cargo de los gastos derivados de inhabitabilidad a consecuencia de una orden administrativa o judicial y siempre que esta situaci&oacute;n no se deba a un expediente administrativo de declaraci&oacute;n de ruina. Abona un alojamiento provisional similar si el asegurado no puede hacer uso de su vivienda a consecuencia del siniestro cubierto por la p&oacute;liza y los gastos de traslado temporal de mobiliario y objetos personales del asegurado: hotel, mudanza, guardamuebles, con los l&iacute;mites que se detallan en la p&oacute;liza.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'176','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('153','1','0','TODAS LAS CAUSAS','Corrimiento de terreno','|6|7|8|10|',null,'<p><strong>Cu&aacute;ndo est&aacute; cubierto:</strong><br />
Dentro de la garant&iacute;a de Todo Riesgo se cubren especialmente las siguientes circunstancias: Asentamiento, hundimiento, desprendimiento, corrimiento o ablandamiento del terreno.<br />
<strong>No est&aacute; cubierto: </strong><br />
Hundimiento y corrimiento de tierras, desprendimiento de rocas y aludes, salvo que est&eacute; contratada la garant&iacute;a Todo Riesgo<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'178','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('154','1','0','TODAS LAS CAUSAS','Rotura de cristales y espejos','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
La rotura, incluidos los gastos de transporte, colocaci&oacute;n y montaje de:<br />
&middot; Cristales y espejos fijados a la edificaci&oacute;n o a los enseres.<br />
&middot; Cristales planos destinados a cubrir muebles de forma permanente.<br />
&middot; Encimeras de m&aacute;rmol, granito u otras piedras naturales o artificiales.<br />
&middot; Elementos sanitarios de cualquier material.<br />
&middot; Cristal de placa vitrocer&aacute;mica o de inducci&oacute;n.<br />
&middot; Cristal de placa solar.<br />
&middot; Acuarios o peceras de cristal o cualquier otro material.<br />
&middot; Muebles, mamparas o estanter&iacute;as de cristal, metacrilato u otros pl&aacute;sticos de similares caracter&iacute;sticas<br />
<strong>No est&aacute;n cubiertos</strong><br />
&middot; Simples ara&ntilde;azos, raspaduras, desconchados o deterioros superficiales. <br />
&middot; Marcos, molduras y muebles de los que formen parte. <br />
&middot; Valor de los decorados art&iacute;sticos<br />
&middot; L&aacute;mparas y bombillas de todas clases, cristaler&iacute;as, aparatos de visi&oacute;n y sonido, lentes, objetos de uso personal y elementos decorativos no adosados a la edificaci&oacute;n o enseres del hogar de forma fija como: figuras de cristal o m&aacute;rmol, portarretratos<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'125','							Recuerda abrir tantos siniestros como roturas existan ,siempre que estas no sean producidas por el mismo origen.
																																																												 
												 
												 
												 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('155','1','0','TODAS LAS CAUSAS','Da�os Agua','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
&middot; Los da&ntilde;os materiales a consecuencia de derrame accidental o filtraciones de agua provenientes de instalaciones fijas o aparatos conectados a la red de agua.<br />
&middot; Da&ntilde;os que tengan su origen en redes de saneamiento subterr&aacute;neas, tales como fosas s&eacute;pticas, arquetas, cloacas, alcantarillados y similares.<br />
&middot; Da&ntilde;os por agua que se produzcan a causa de heladas.<br />
&middot; Los gastos necesarios de localizaci&oacute;n o reparaci&oacute;n de aver&iacute;as causantes de los da&ntilde;os, en las instalaciones fijas privativas.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Da&ntilde;os debidos a corrosi&oacute;n generalizada o desgastes notorios de las instalaciones de la edificaci&oacute;n.<br />
&middot; Los gastos de desatasco.<br />
&middot; Los gastos de reparaci&oacute;n de aparatos o instalaciones de agua u otros l&iacute;quidos distintos a las propias tuber&iacute;as o conducciones de agua u otros l&iacute;quidos tales como: electrodom&eacute;sticos, grifer&iacute;as, o llaves de paso, aparatos sanitarios, calderas, calentadores, acumuladores, radiadores, arquetas, fosas s&eacute;pticas e instalaciones subterr&aacute;neas.<br />
&middot; Los gastos de reparaci&oacute;n de tejados o fachadas, aunque se hayan producido da&ntilde;os por agua garantizados por la p&oacute;liza.<br />
&middot; Gastos necesarios para corregir instalaciones defectuosas o mal dise&ntilde;adas.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'115','																																																								Recuerda que en casos de da�os provocados por las lluvias, debes abrir el siniestro por la causa Lluvia.  				 
												 
												 
												 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('156','1','0','TODAS LAS CAUSAS','Da�os el�ctricos','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Da&ntilde;os materiales sufridos por la instalaci&oacute;n el&eacute;ctrica, as&iacute; como la propia edificaci&oacute;n y/o los aparatos el&eacute;ctricos y/o electr&oacute;nicos, como consecuencia de sobretensi&oacute;n, un cortocircuito, incluso las producidas por tormenta o rayo.<br />
<strong>No est&aacute;n cubiertos</strong>:<br />
&middot; Reparaciones de aparatos el&eacute;ctricos y/o electr&oacute;nicos que no hayan sido realizadas por nuestros <br />
profesionales.<br />
&middot; Las bombillas, l&aacute;mparas, hal&oacute;genos, tubos fluorescentes o similares<br />
&middot; Los aparatos de antig&uuml;edad superior a 8 a&ntilde;os.<br />
&middot; Los aparatos de valor inferior a 150 euros.<br />
. Da&ntilde;os y/o p&eacute;rdidas de los que sea legal o contractualmente responsable el fabricante o proveedor del aparato.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'132','																									Si los aparatos afectados son de la marca TEKA, recuerda que puedes asignar a TEKA INDUSTRIAL manualmente, para esta causa.
						
																									 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('157','1','0','TODAS LAS CAUSAS','Da�os Mercancia Transportada','|8|',null,'<p><strong>Qu&eacute; est&aacute; cubierto</strong><br />
El choque de un veh&iacute;culo terrestre identificado o de las mercanc&iacute;as por el mismo transportadas, cuyo conductor o propietario no sea el asegurado, ni ning&uacute;n copropietario y/o inquilino, ni una persona que sea civilmente responsable de ellos.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'124','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('158','1','0','TODAS LAS CAUSAS','Derrame Mercancias L�quidas','|8|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> los da&ntilde;os y o p&eacute;rdidas de las mercanc&iacute;as l&iacute;quida, hasta el l&iacute;mite indicado en p&oacute;liza, a consecuencia de: destrucci&oacute;n, rotura, revent&oacute;n o agrietamiento de car&aacute;cter accidental de los dep&oacute;sitos que las contienen.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Los defectos de construcci&oacute;n fabricaci&oacute;n o instalaci&oacute;n de los dep&oacute;sitos, as&iacute; como los debidos a vetustez, desgaste, oxidaci&oacute;n o corrosi&oacute;n de los mismos.<br />
&middot; Las p&eacute;rdidas durante su trasvase o llenado; as&iacute; como los debidos a fallos en los aparatos y l&iacute;neas de conducci&oacute;n, llenado o trasvase.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'129','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('159','1','0','TODAS LAS CAUSAS','Deterioro Bienes Refrigerados','|6|8|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
La podredumbre de bienes refrigerados o congelados dentro del frigor&iacute;fico o congelador, como consecuencia de falta de suministro el&eacute;ctrico o aver&iacute;a de dichos aparatos<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Da&ntilde;os que hayan podido sufrir el frigor&iacute;fico o congelador.<br />
&middot; Da&ntilde;os que puedan causar los bienes al deteriorarse.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'116','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('160','1','0','TODAS LAS CAUSAS','Env�o profesionales','|6|7|8|10|',null,'<p>Si el asegurado necesita realizar una reparaci&oacute;n, obras de reforma o mejoras en la vivienda asegurada, AXA pone a su disposici&oacute;n una amplia red de reparadores.<br />
Los gastos de desplazamiento del profesional y el presupuesto oportuno ser&aacute;n a cargo de AXA.</p>
<p>El coste de la renovaci&oacute;n de los materiales da&ntilde;ados, excepto cuando los da&ntilde;os tengan su origen en cualquiera de los riesgos cubiertos por la p&oacute;liza, ser&aacute;n a cargo del cliente.</p>
<p><strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'192','							Recuerda que este servicio lo tiene que pagar el cliente.
																																																														 
												 
												 
												 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('161','1','0','TODAS LAS CAUSAS','Equipos informaticos','|6|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Da&ntilde;os materiales sufridos por ordenadores personales y sus equipos perif&eacute;ricos, en el interior de la edificaci&oacute;n asegurada, a primer riesgo, a consecuencia de:<br />
&middot; Impericia o negligencia.<br />
&middot; Impactos y colisiones accidentales.<br />
&middot; Derrame de l&iacute;quidos o introducci&oacute;n de cuerpos extra&ntilde;os, accidentalmente.<br />
&middot; Ca&iacute;das, excepto en equipos y elementos port&aacute;tiles.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; P&eacute;rdidas o da&ntilde;os a equipos alquilados, si es responsable el propietario, ya sea legalmente o seg&uacute;n <br />
convenio de alquiler y/o mantenimiento.<br />
&middot; Elementos cuya antig&uuml;edad sea superior a 10 a&ntilde;os.<br />
&middot; Electrodom&eacute;sticos.<br />
&middot; Ca&iacute;das sufridas por equipos y elementos port&aacute;tiles.<br />
. Defectos est&eacute;ticos, como raspaduras de superficies pintadas, pulidas o barnizadas.<br />
&middot; Cualquier gasto ocasionado con objeto de eliminar fallos operacionales, a menos que dichos fallos sean causados por p&eacute;rdida o da&ntilde;o indemnizable ocurrido a bienes asegurados.<br />
&middot; Cualquier gasto derivado del mantenimiento de los bienes asegurados. Tal exclusi&oacute;n se aplica a las <br />
partes recambiadas en el curso de dichas operaciones de mantenimiento.<br />
&middot; Las p&eacute;rdidas o da&ntilde;os causados directa o indirectamente por variaci&oacute;n o interrupci&oacute;n en el <br />
aprovisionamiento de corriente el&eacute;ctrica de la red p&uacute;blica.<br />
&middot; Defectos y vicios, as&iacute; como el desgaste o deterioro paulatino derivado del uso habitual.<br />
&middot; Ensayos y pruebas en cuyo transcurso sea sometido el bien asegurado a un desgaste superior al normal.<br />
&middot; Da&ntilde;os de los que sea responsable, legal o contractualmente, el fabricante o proveedor.<br />
&middot; Elementos susceptibles de desgaste por el uso habitual.<br />
&middot; El software y los programas inform&aacute;ticos en general, incluso los sistemas electr&oacute;nicos de protecci&oacute;n de paquetes de software (llaves de seguridad).<br />
&middot; Da&ntilde;os y gastos cubiertos por contrato de asistencia t&eacute;cnica o mantenimiento.<br />
&middot; Las roturas que se produzcan como consecuencia de la realizaci&oacute;n de obras, de la manipulaci&oacute;n y/o del transporte.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'179','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('163','1','0','TODAS LAS CAUSAS','Humo','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os materiales a los bienes asegurados cuando se produzca un escape repentino en conducciones de extracci&oacute;n de humo (chimeneas, extractores, etc) tanto si se han originado en el interior de la vivienda como en el exterior de la misma.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Los da&ntilde;os causados por la acci&oacute;n continuada del humo.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'110','																																																								Recuerda que los da�os por  humo derivados de un incendio se gestionan por la causa Incendio. 			 
												 
												 
												 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('164','1','0','TODAS LAS CAUSAS','Hurto o p�rdida de llaves','|6|',null,'<p>En el caso de hurto (sustracci&oacute;n sin fuerza) o p&eacute;rdida de llaves de acceso a la vivienda cubrimos la reposici&oacute;n de llaves y cambio de cerradura. <br />A tener en cuenta: En las p&oacute;lizas flexibles s&oacute;lo queda cubierto por Robo o Atraco y tiene que tener contratada la garant&iacute;a opcional de &ldquo;Reposici&oacute;n de llaves y cerraduras&rdquo;.<br /><br /></p>',to_date('30/11/21','DD/MM/RR'),'195','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('165','1','0','TODAS LAS CAUSAS','Incendio','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
&middot; Los da&ntilde;os materiales que sufran los bienes asegurados cuando se destruyan a causa de incendio y/o explosi&oacute;n.<br />
&middot; Los da&ntilde;os ocasionados a los veh&iacute;culos a motor, remolques, caravanas y embarcaciones de recreo cuando se encuentren estacionados dentro del garage de la vivienda asegurada en el momento de producirse el incendio.<br />
<strong>Qu&eacute; no est&aacute; cubierto: </strong><br />
&middot; Los da&ntilde;os en los bienes asegurados que no sean debidos a incendio, por ejemplo, los da&ntilde;os producidos por chispas, chispazos, cigarrillos, braseros o elementos de calor de los que no se derive incendio.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'101','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('166','1','0','TODAS LAS CAUSAS','Rotura de loza y marmoles','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
La rotura, incluidos los gastos de transporte, colocaci&oacute;n y montaje de:<br />
&middot; Encimeras de m&aacute;rmol, granito u otras piedras naturales o artificiales.<br />
&middot; Elementos sanitarios: pilas, lavabos, fregaderos, inodoros, ba&ntilde;eras, platos de ducha y bid&eacute;s de cualquier material.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Simples ara&ntilde;azos, raspaduras, desconchados o deterioros superficiales. <br />
&middot; Marcos, molduras y muebles de los que formen parte. <br />
&middot; Valor de los decorados art&iacute;sticos.<br />
&middot; L&aacute;mparas y bombillas de todas clases, cristaler&iacute;as, aparatos de visi&oacute;n y sonido, lentes, objetos de uso personal y elementos decorativos no adosados a la edificaci&oacute;n o enseres del hogar de forma fija como: figuras de cristal o m&aacute;rmol, portarretratos.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'127','						Recuerda abrir tantos siniestros como roturas existan ,siempre que estas no sean producidas por el mismo origen.
																																																															 
												 
												 
												 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('162','1','0','TODAS LAS CAUSAS','Explosion','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
&middot; Da&ntilde;os materiales que sufran los bienes asegurados cuando se destruyan a consecuencia de incendio y/o explosi&oacute;n.<br />
&middot; Los da&ntilde;os ocasionados a los veh&iacute;culos a motor, remolques, caravanas y embarcaciones de recreo cuando se encuentren estacionados dentro del garaje de la vivienda asegurada en el momento de producirse el incendio.<br />
<strong>No est&aacute; cubierto:</strong><br />
&middot; Los da&ntilde;os en los bienes asegurados que no sean debidos a incendio, por ejemplo, los da&ntilde;os provocados por chispas, chispazos, cigarrillos, braseros o elementos de calor, de los que no se derive incendio.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'102','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('167','1','0','TODAS LAS CAUSAS','Ondas S�nicas','|6|7|8|10|',null,'<p><strong>Impacto de objetos y Detonaciones s&oacute;nicas (Comunidades)<br />
  Qu&eacute; est&aacute; cubierto:</strong><br />
La acci&oacute;n directa de las ondas s&oacute;nicas producidas por aparatos a&eacute;reos o espaciales cuando franqueen la barrera del sonido.</p>

<p><strong>Detonaciones s&oacute;nicas (Comercio y Hogar)</strong><br />
  <strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os materiales a los bienes asegurados cuando se destruyan a consecuencia de detonaciones s&oacute;nicas.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
Los da&ntilde;os a los bienes asegurados depositados al aire libre, aun cuando se hallen protegidos por materiales flexibles (lonas, pl&aacute;sticos, construcciones hinchables o similares) o contenidos en el interior de construcciones abiertas.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'113','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('168','1','0','TODAS LAS CAUSAS','Otros Riesgos Accidentales','|6|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os materiales en la edificaci&oacute;n, mobiliario o joyas, cuando se destruyan a consecuencia de cualquier otra causa accidental diferente de las detalladas en las garant&iacute;as.<br />
Convenciones especiales para esta garant&iacute;a<br />
&middot; Accidente es un hecho que se produce de forma s&uacute;bita y espont&aacute;nea por causa ajena a la voluntad del asegurado como tal.<br />
&middot; La garant&iacute;a Todo Riesgo no tiene vigor alguno sobre los objetos de valor art&iacute;stico. Dichos objetos s&oacute;lo podr&aacute;n tener cobertura si se contrata la garant&iacute;a Todo riesgo arte.<br />
&middot; Esta garant&iacute;a cubre especialmente las siguientes circunstancias: Asentamiento, hundimiento, desprendimiento, corrimiento o ablandamiento del terreno.<br />
&middot; Se extiende la garant&iacute;a a bienes que no siendo de su propiedad o de alg&uacute;n miembro de su familia, est&aacute;n bajo su cuidado o tiene en dep&oacute;sito, si se produce alg&uacute;n suceso cubierto en la p&oacute;liza.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Ara&ntilde;azos, raspaduras, desconchones, rayados y en general cualquier deterioro superficial de los bienes asegurados, salvo que se deriven de otros da&ntilde;os de mayor entidad amparados por el contrato.<br />
&middot; Aver&iacute;as de tipo mec&aacute;nico, el&eacute;ctrico o electr&oacute;nico.<br />
&middot; Da&ntilde;os derivados de cualquier clase de contaminaci&oacute;n.<br />
&middot; Da&ntilde;os producidos por termitas, gusanos, polillas o cualquier plaga de insectos.<br />
&middot; Expropiaci&oacute;n, confiscaci&oacute;n, requisa o da&ntilde;os en los bienes por imperativo de cualquier gobierno o autoridad, de hecho o de derecho.</p>

<p>Los beneficios o prestaciones, l&iacute;mites y exclusiones correspondientes a las garant&iacute;as descritas en la Tabla Resumen, ser&aacute;n de total aplicaci&oacute;n en los supuestos previstos en ellas. La garant&iacute;a Todo Riesgo no podr&aacute; ser invocada para modificar dichas garant&iacute;as, sus l&iacute;mites o exclusiones.</p>

<p><strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'145','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('169','1','0','TODAS LAS CAUSAS','P. Beneficios por fallo de suministros','|8|',null,'<p>Garantiza la Perdida de Beneficios por el fallo en el suministro de proveedores. Las p&eacute;rdidas que por paralizaci&oacute;n de la actividad del negocio puedan producirse a consecuencia de que ocurra un siniestro en los locales de los proveedores del asegurado ubicados en Espa&ntilde;a, siempre y cuando dicho siniestro se deba a una de las garant&iacute;as espec&iacute;ficamente contratadas.</p>',to_date('30/11/21','DD/MM/RR'),'183','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('170','1','0','TODAS LAS CAUSAS','Otros servicios','|6|7|8|10|',null,'<p>Dentro del apartado de Otros Servicios, le ofrecemos asesoramiento sobre la salud de las plantas de su jard&iacute;n, &aacute;rboles y arbustos as&iacute; como el mantenimiento de su piscina. </p>
<p>Servicio de consulta y ayuda para solucionar incidencias que afecten a equipos inform&aacute;ticos que se encuentren en la vivienda asegurada.</p>
<p>Cubrimos la rotura accidental de art&iacute;culos deportivos dentro de la vivienda asegurada.<br />
Cubrimos las siguientes prestaciones siempre que se deriven de un hecho accidental ocurrido durante un viaje de sus vacaciones o a consecuencia de practicar una actividad deportiva con car&aacute;cter amateur: Repatriaci&oacute;n o Transportes de heridos enfermos o fallecidos, gastos de curaci&oacute;n en el extranjero, Indemnizaci&oacute;n por retraso de equipaje y regreso anticipado en caso de hospitalizaci&oacute;n o defunci&oacute;n de un familiar.</p>
<p><strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'131','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('171','1','0','TODAS LAS CAUSAS','RC Contaminaci�n','|7|',null,'<p>Queda garantizada la responsabilidad civil del asegurado por: los da&ntilde;os y perjuicios causados a terceros por contaminaci&oacute;n, y los da&ntilde;os causados a los recursos naturales por contaminaci&oacute;n.</p>',to_date('30/11/21','DD/MM/RR'),'194','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('172','1','0','TODAS LAS CAUSAS','RC Empleados dom�sticos','|6|',null,'<p>Queda cubierta la responsabilidad civil extracontractual que sea exigible legalmente al Asegurado por los da&ntilde;os, exclusivamente corporales, sufridos por el personal dom&eacute;stico a su servicio, en el ejercicio de sus funciones, siempre y cuando dicho personal est&eacute; dado de alta en la Seguridad Social.</p>',to_date('30/11/21','DD/MM/RR'),'196','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('14','2','2','FEN�MENOS EXTERNOS O DE LA NATURALEZA','Otros Riesgos Accidentales','|6|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> los da&ntilde;os materiales que sufra la edificaci&oacute;n, mobiliario o joyas, cuando se destruyan a consecuencia de cualquier otra causa accidental diferente de las detalladas en las garant&iacute;as.<br />
Convenciones especiales para esta garant&iacute;a<br />
&middot; Accidente es un hecho que se produce de forma s&uacute;bita y espont&aacute;nea por causa ajena a la voluntad del asegurado como tal.<br />
&middot; La garant&iacute;a Todo Riesgo no tiene vigor alguno sobre los objetos de valor art&iacute;stico. Dichos objetos s&oacute;lo podr&aacute;n tener cobertura si se contrata la garant&iacute;a Todo riesgo arte.<br />
&middot; Esta garant&iacute;a cubre especialmente las siguientes circunstancias: Asentamiento, hundimiento, desprendimiento, corrimiento o ablandamiento del terreno.<br />
&middot; Se extiende la garant&iacute;a a bienes que no siendo de su propiedad o de alg&uacute;n miembro de su familia, est&aacute;n bajo su cuidado o tiene en dep&oacute;sito, si se produce alg&uacute;n suceso cubierto en la p&oacute;liza.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Ara&ntilde;azos, raspaduras, desconchones, rayados y en general cualquier deterioro superficial de los bienes asegurados, salvo que se deriven de otros da&ntilde;os de mayor entidad amparados por el contrato.<br />
&middot; Aver&iacute;as de tipo mec&aacute;nico, el&eacute;ctrico o electr&oacute;nico.<br />
&middot; Da&ntilde;os derivados de cualquier clase de contaminaci&oacute;n.<br />
&middot; Da&ntilde;os producidos por termitas, gusanos, polillas o cualquier plaga de insectos.<br />
&middot; Expropiaci&oacute;n, confiscaci&oacute;n, requisa o da&ntilde;os en los bienes por imperativo de cualquier gobierno o autoridad, de hecho o de derecho.<br />

<p>La garant&iacute;a Todo Riesgo no podr&aacute; ser invocada para modificar las garant&iacute;as,  l&iacute;mites o exclusiones de otras garant&iacute;as.</p><br />

<p><strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'145',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('16','2','2','FEN�MENOS EXTERNOS O DE LA NATURALEZA','Actos de Vandalismo','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa si existen</strong> los da&ntilde;os materiales a los bienes asegurados cuando se produzcan actos de vandalismo o malintencionados cometidos individual o colectivamente por otras personas.<br />
<strong>No est&aacute;n cubiertos :</strong><br />
&middot; Los da&ntilde;os causados por los inquilinos o por otros ocupantes de la vivienda.<br />
&middot; Las pintadas, rayadas, inscripciones y pegado de carteles.<br />
&middot; Los actos de vandalismo que no se hayan denunciado ante la autoridad competente.<br />
&middot; La rotura de cristales o materiales sustitutivos del cristal, lunas espejos, m&aacute;rmoles y elementos de loza sanitaria salvo cuando est&eacute; contratada la garant&iacute;a de roturas.<br />
&middot; Los da&ntilde;os producidos por robo y expoliaci&oacute;n, salvo cuando est&eacute; contratada la garant&iacute;a de robo.<br />
. Los actos de vandalismo cuando los bienes asegurados no se encuentren en la vivienda asegurada<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'108',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('17','2','2','FEN�MENOS EXTERNOS O DE LA NATURALEZA','Ca�da de �rboles-Antenas-Farolas','|6|7|8|',null,'<p><strong>Puede declarar siniestro por esta causa en caso de producirse</strong> gastos de limpieza y saneamiento, as&iacute; como los de reemplazo por otros de la misma especie, cuando los &aacute;rboles y arbustos de su parcela sufran da&ntilde;os por:<br />
� Incendio, explosi&oacute;n y ca&iacute;da de un rayo.<br />
� Los efectos del viento, ya sea por su intensidad como por la acci&oacute;n de objetos arrastrados por &eacute;l.<br />
� Asentamientos, hundimientos, desprendimientos, corrimientos o ablandamientos del terreno, por causas accidentales.<br />
� Choque de veh&iacute;culos terrestres, o de los bienes por ellos transportados siempre que no sean de su propiedad.<br />
� Ca&iacute;da de cualquier objeto procedente del exterior, siempre que no sean de su propiedad.<br />
� Ondas s&oacute;nicas.<br />
� Actos vand&aacute;licos.<br />
<strong>No est&aacute;n cubiertos</strong>:<br />
� Los da&ntilde;os producidos o agravados por falta de mantenimiento.<br />
� Los da&ntilde;os producidos por plagas y/o enfermedades.<br />
� Las plantaciones que no est&eacute;n  en el propio terreno de la parcela, por ejemplo en macetas y jardineras.<br />
� Las plantaciones efectuadas con alg&uacute;n fin comercial.<br />
� Las citadas por el ep&iacute;grafe de exclusiones de car&aacute;cter general que no hayan sido espec&iacute;ficamente incluidas en la cobertura arriba descrita.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'182',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('55','2','14','DA�OS A TERCEROS','Responsabilidad civil','|6|7|8|10|',null,'<p>Responsabilidad civil El &aacute;mbito geogr&aacute;fico de cobertura, es de aplicaci&oacute;n en todo el mundo a excepci&oacute;n de Estados Unidos de Am&eacute;rica y Canad&aacute;.<br/>
Puede declarar siniestro con esta causa en caso de:<br/>
</br>
<strong>Responsabilidad civil familiar</strong> , AXA cubre la obligaci&oacute;n de indemnizar los da&ntilde;os y perjuicios causados a terceros, cuando el asegurado o los miembros de su familia que convivan en la vivienda asegurada, sean civilmente responsables en el &aacute;mbito de su vida familiar privada.<br/>
<strong>Responsabilidad civil patronal</strong>  aquella exigida al asegurado por sus trabajadores, como civilmente responsable por los da&ntilde;os que a causa de un accidente laboral, sufra el personal contratado.<br/>
<strong>Responsabilidad civil inmueble</strong> por los da&ntilde;os personales o materiales causados a terceros, cuando tengan su origen en la propiedad de la Edificaci&oacute;n asegurada. <br/>
<strong>Responsabilidad civil locativa</strong> por da&ntilde;os que sufran los inmuebles ocupados en r&eacute;gimen de alquiler y en los que se desarrolla la actividad asegurada por la presente p&oacute;liza, a consecuencia de siniestros cubiertos por la garant&iacute;a de incendio, explosi&oacute;n y da&ntilde;os producidos por el agua.<br/>
<strong>Responsabilidad civil bienes confiados</strong> por el extrav&iacute;o, cambio o deterioro de prendas, bolsos y paraguas entregados, contra recibo o resguardo, en el guardarropas, siempre y cuando est&eacute; vigilado permanentemente y sea solamente accesible al personal encargado del mismo.<br/>
<strong>Responsabilidad civil Actividad/Explotaci&oacute;n extracontractual</strong> que pueda derivarse para el asegurado por el ejercicio de la actividad declarada.<br/>
<strong>Responsabilidad civil de productos y/o post-trabajos</strong> que pudiera incurrir el asegurado por los da&ntilde;os personales o materiales causados a terceros por los productos que hubiese fabricado, entregado o suministrado, o por los trabajos o servicios que hubiese prestado, debidos a deficiencias en la producci&oacute;n, instrucciones para el uso, almacenamiento, entrega, informaci&oacute;n y embalaje. <br/>
</br>
No est&aacute;n cubiertas las reclamaciones derivadas de:<br/>
&middot; El uso, tenencia, transporte o almacenamiento de armas y/o explosivos de cualquier clase.<br/>
&middot; Da&ntilde;os a bienes de terceros que est&eacute;n en su poder.<br/>
&middot; Obligaciones contractuales.<br/>
&middot; Responsabilidades profesionales.<br/>
&middot; Da&ntilde;os que deban ser objeto de cobertura por un seguro obligatorio; quedar&aacute; tambi&eacute;n excluido el exceso de lo legal.<br/>
&middot; Incumplimiento de disposiciones oficiales, tales como  multas o sanciones ni de las consecuencias de su impago.<br/>
&middot; Perjuicios no consecutivos, como las p&eacute;rdidas econ&oacute;micas que no sean consecuencia directa de un da&ntilde;o personal o material,  as&iacute; como aquellas p&eacute;rdidas econ&oacute;micas que sean consecuencia de un da&ntilde;o personal o material no amparado por la p&oacute;liza.<br/>
&middot; Da&ntilde;os que tengan su origen en la pr&aacute;ctica deportiva, cuando el asegurado o los miembros de su familia dispongan de ficha federativa.<br/>
&middot; El uso y circulaci&oacute;n de veh&iacute;culos a motor, y/o de los elementos remolcados o incorporados a los mismos.<br/>
&middot; Derivadas de la contaminaci&oacute;n del suelo, las aguas o la atm&oacute;sfera.<br/>
&middot; Reclamaciones que el propietario-arrendador haga al inquilino-asegurado, diferentes de las derivadas de incendio, explosi&oacute;n y da&ntilde;os por agua.<br/>
* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.',to_date('29/11/16','DD/MM/RR'),'122',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('56','2','15','RECLAMACI�N DE DA�OS A TERCEROS','Reclamaci�n de da�os','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa y</strong> AXA se har&aacute; cargo de la reclamaci&oacute;n de da&ntilde;os y/o perjuicios que otras personas (que no teniendo ning&uacute;n contrato con usted), le hayan causado, asu edificaci&oacute;n, mobiliario o  a su persona. Cubrimos expresamente reclamaci&oacute;n de da&ntilde;os corporales en caso de conducci&oacute;n de bicicletas, atropello y ca&iacute;da accidental atribuible a un tercero.<br />
Adem&aacute;s, queda cubierto:<br />
&middot; Reclamaci&oacute;n contractual por obras en el inmueble derivada de incumplimientos de contratos de prestaci&oacute;n de servicios de reparaci&oacute;n, mantenimiento o reforma que hayan suscrito en relaci&oacute;n con la Edificaci&oacute;n y/o enseres asegurados, siempre que se haya abonado la factura y salvo que se trate de contratos de suministro de agua, luz, gas, tel&&eacute;acute;fono o Internet.<br />
&middot; Reclamaci&oacute;n contractual por cosas muebles: derivada de incumplimientos del vendedor, en contratos de compraventa que afecten a los Enseres asegurados.<br />
&middot; Reclamaciones por riesgos extraordinarios.<br />
Gestionamos la reclamaci&oacute;n en caso de incumplimiento por parte del Consorcio de Compensaci&oacute;n de Seguros que impida que el asegurado pueda hacer efectivos los derechos que se derivan de la cl&aacute;usula de cobertura de riesgos extraordinarios que se incluye en la p&oacute;liza.<br />
&middot; Reclamaciones frente a otras aseguradoras: En caso de incumplimiento de otra Aseguradora por p&oacute;lizas de seguro en vigor en relaci&oacute;n con la vivienda asegurada, contratadas por el asegurado, o de las que cliente fuera beneficiario, AXA realizar&aacute; la reclamaci&oacute;n para hacer valer sus derechos.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'133',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('58','2','0','RESTO DE CAUSAS','RESTO DE CAUSAS','|0|',null,null,to_date('29/11/16','DD/MM/RR'),'0',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('1','3','1','AUTOS','Colisi�n con Otro Veh�culo','|2|',null,'<p>Siniestro en el que ha estado implicado otro veh&iacute;culo en el accidente adem&aacute;s del veh&iacute;culo asegurado.</p>',to_date('17/11/16','DD/MM/RR'),'201',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('2','3','2','AUTOS','Colisi�n con M�s 1 Veh�culo','|2|',null,'<p>Siniestro en el que ha estado implicado m&aacute;s de un veh&iacute;culo en el accidente adem&aacute;s del veh&iacute;culo asegurado.</p>',to_date('17/11/16','DD/MM/RR'),'202',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('3','3','3','AUTOS','Robo Total','|2|',null,'<p>Siniestro debido a la sustracci&oacute;n del veh&iacute;culo completo.</p>',to_date('17/11/16','DD/MM/RR'),'204',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('4','3','4','AUTOS','Da�os por Robo/Robo de Piezas','|2|',null,'<p>Siniestro de da&ntilde;os&#160; ocurrido por robo o tentativa de robo.</p>',to_date('17/11/16','DD/MM/RR'),'206',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('59','1','60','FEN�MENOS ATMOSF�RICOS-TERRESTRES','Pedrisco-Nieve','|6|7|8|10|',null,'<p><strong>Qu; est; cubierto:</strong><br />
Da;os materiales a los bienes asegurados cuando se destruyan a consecuencia de los fen;menos externos de pedrisco o nieve, de intensidad tal que afecte a varios edificios de buena construcci;n en las proximidades de la vivienda asegurada. Se incluyen los da;os producidos por objetos arrastrados o proyectados por el viento o la lluvia.<br />
; Si la cantidad de lluvia es superior a 40l/m2 y hora, o la velocidad del viento es superior a 84 Km/h., no ser; necesario el requisito que varios edificios se encuentren afectados.<br />
; Inundaci;n debida a desbordamientos de cauces o cursos de agua construidos por el hombre y cuya cobertura no corresponda al Consorcio de Compensaci;n de seguros.<br />
<strong>Qu; no est; cubierto:</strong><br />
; Da;os a los enseres del hogar que est;n depositados al aire libre, aun cuando se hallen protegidos por materiales flexibles (lonas, pl;sticos, construcciones hinchables o similares) o contenidos en el interior de construcciones abiertas.<br />
; Da;os producidos por nieve, agua, arena o el polvo que entre por puertas, ventanas u otras aberturas que est;n sin cerrar o con cierre defectuoso.<br />
; Da;os producidos por heladas, frio o hielo<br />
; Da;os producidos por olas o mareas, incluso cuando estos fen;menos hayan sido causados por el viento.<br />
; Da;os producidos por desbordamiento o rotura de presas y diques de contenci;n<br />
<strong>* Lo aqu; recogido responde a unas l;neas generales de contrataci;n, para el siniestro en concreto se aplicar;n las condiciones generales y particulares de la p;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'106','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('62','2','7','OTROS SERVICIOS DE ASISTENCIA','Apertura de puerta','|6|7|8|10|',null,'<p>Tiene a su disposici&oacute;n nuestra red de reparadores para los siguientes servicios de contenci&oacute;n de da&ntilde;os durante las 24 horas del d&iacute;a todos los d&iacute;as de la semana:</p>
<p><strong>Que cubre:</strong><br />
El env&iacute;o de un cerrajero para la apertura de puerta si por una contingencia, incluida la p&eacute;rdida de llaves, no puede entrar a la vivienda asegurada y no hay otra soluci&oacute;n.</p>
<p>Los gastos del env&iacute;o del profesional y la mano de obra ser&aacute;n a cargo de AXA. El coste de la renovaci&oacute;n de los materiales da&ntilde;ados ser&aacute; a su cargo, excepto cuando los da&ntilde;os tengan su origen en cualquiera de los riesgos cubiertos por la p&oacute;liza, en cuyo caso, AXA asume el coste de dichos materiales</p>
<p><strong>No est&aacute;n cubiertas:</strong> Reparaciones no efectuadas por la red de reparadores de AXA.</p>
<p><strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'187',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('63','2','7','OTROS SERVICIOS DE ASISTENCIA','Env�o profesionales','|6|7|8|10|',null,'<p><strong>Env&iacute;o de profesionales.</strong></p>
<p>Si el asegurado necesita realizar una reparaci&oacute;n, obras de reforma o mejoras en la vivienda asegurada, AXA pone a su disposici&oacute;n una amplia red de reparadores.<br />
Los gastos de desplazamiento del profesional y el presupuesto oportuno ser&aacute;n a cargo de AXA.</p>
<p>El coste de la renovaci&oacute;n de los materiales da&ntilde;ados, excepto cuando los da&ntilde;os tengan su origen en cualquiera de los riesgos cubiertos por la p&oacute;liza, ser&aacute;n a cargo del cliente.</p>
<p><strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'192',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('33','2','5','ROTURAS','Rotura Metacrilato','|6|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> la rotura de muebles, mamparas o estanter&iacute;as de cristal, metacrilato u otros pl&aacute;sticos de similares, incluidos los gastos de transporte, colocaci&oacute;n y montaje.
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Simples ara&ntilde;azos, raspaduras, desconchados o deterioros superficiales.<br />
&middot; Marcos, molduras y muebles de los que formen parte.<br />
&middot; Valor de los decorados art&iacute;sticos.<br />
&middot; L&aacute;mparas y bombillas de todas clases, cristaler&iacute;as, aparatos de visi&oacute;n y sonido, lentes, objetos de uso  personal y elementos decorativos no  adosados a la edificaci&oacute;n o enseres del hogar de forma fija como:  figuras de cristal o m&aacute;rmol, portarretratos.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'174',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('34','2','5','ROTURAS','Rotura placas solares','|6|7|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> la rotura de cristal de placa solar, incluidos los gastos de transporte, colocaci&oacute;n y montaje.<br />
<strong>No est&aacute;n cubierto:</strong><br />
&middot; Simples ara&ntilde;azos, raspaduras, desconchados o deterioros superficiales.<br />
&middot; Marcos, molduras y muebles de los que formen parte.<br />
&middot; Valor de los decorados art�sticos.<br />
&middot; L&aacute;mparas y bombillas de todas clases, cristaler�as, aparatos de visi&oacute;n y sonido, lentes, objetos de uso personal y elementos decorativos no  adosados a la edificaci&oacute;n o enseres del hogar de forma fija como: figuras de cristal o m&aacute;rmol, portarretratos.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'169',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('5','3','5','AUTOS','Da�os Aparcamiento','|2|',null,'<p>Siniestro de da&ntilde;os sufridos por el veh&iacute;culo asegurado, mientras se encontraba en reposo, sin contrario identificado, o aquellos derivados de maniobras de estacionamiento, as&iacute; como en los que no existe un contrario identificado ni perjudicados.</p>',to_date('17/11/16','DD/MM/RR'),'207',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('35','2','5','ROTURAS','Rotura vitroceramica','|6|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> la rotura de cristal de placa vitrocer&aacute;mica o de inducci&oacute;n, incluidos los gastos de transporte, colocaci&oacute;n y montaje.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Simples ara&ntilde;azos, raspaduras, desconchados o deterioros superficiales<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'168',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('36','2','6','CHOQUES - CA�DAS','Choque o Impacto de Veh�culos','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> los da&ntilde;os materiales a los bienes asegurados cuando se produzca alguna de las siguientes circunstancias:<br />
&middot; Choque de veh&iacute;culos terrestres o de los bienes por ellos transportados.<br />
&middot; Ca&iacute;da de cualquier objeto procedente del exterior.<br />
&middot; Impacto de animales.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Los da&ntilde;os a los enseres  depositados al aire libre, aun cuando se hallen protegidos por materiales flexibles o contenidos en el interior de construcciones abiertas, patios, jardines, porches o terrazas.<br />
&middot; Los da&ntilde;os causados por veh&iacute;culos, animales u objetos que sean propiedad del asegurado o est&eacute;n bajo su control, de los miembros de su familia o de personas que dependande &eacute;l.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'111',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('37','2','6','CHOQUES - CA�DAS','Caida Aeronaves y/o Astronaves','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa en caso de</strong> choque o ca&iacute;da de un aparato a&eacute;reo o espacial o de objetos que caigan de los mismos, siempre y cuando no sean de su propiedad ni de una persona de la que Usted sea civilmente responsable.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'112',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('38','2','6','CHOQUES - CA�DAS','Caida Arboles-Antenas-Farolas','|6|7|',null,'<p><strong>Puede declarar siniestro por esta causa en caso de producirse</strong> gastos de limpieza y saneamiento, as&iacute; como los de reemplazo por otros de la misma especie, cuando los &aacute;rboles y arbustos de su parcela sufran da&ntilde;os por:<br />
� Incendio, explosi&oacute;n y ca&iacute;da de un rayo.<br />
� Los efectos del viento, ya sea por su intensidad como por la acci&oacute;n de objetos arrastrados por &eacute;l.<br />
� Asentamientos, hundimientos, desprendimientos, corrimientos o ablandamientos del terreno, por causas accidentales.<br />
� Choque de veh&iacute;culos terrestres, o de los bienes por ellos transportados siempre que no sean de su propiedad.<br />
� Ca&iacute;da de cualquier objeto procedente del exterior, siempre que no sean de su propiedad.<br />
� Ondas s&oacute;nicas.<br />
� Actos vand&aacute;licos.<br />
<strong>No est&aacute;n cubiertos</strong>:<br />
� Los da&ntilde;os producidos o agravados por falta de mantenimiento.<br />
� Los da&ntilde;os producidos por plagas y/o enfermedades.<br />
� Las plantaciones que no est&eacute;n  en el propio terreno de la parcela, por ejemplo en macetas y jardineras.<br />
� Las plantaciones efectuadas con alg&uacute;n fin comercial.<br />
� Las citadas por el ep&iacute;grafe de exclusiones de car&aacute;cter general que no hayan sido espec&iacute;ficamente incluidas en la cobertura arriba descrita.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'182',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('39','2','7','OTROS SERVICIOS DE ASISTENCIA','Bricopartner','|6|',null,'<p>AXA pone a disposici&oacute;n su disposici&oacute;n nuestra red de profesionales, para llevar a cabo un servicio de bricolaje en la vivienda asegurada,  que incluye los   gastos de desplazamiento de 2 visitas por anualidad de seguro de 2 horas de mano de obra gratis cada una  o los gastos de desplazamiento de 1 visita por anualidad de seguro de 4 horas de mano de obra gratis.<br />
Usted deber&aacute; hacerse cargo de los materiales empleados y en su caso, del exceso de tiempo de mano de obra que se pudiera producir.<br />
Dentro de &eacute;ste servicio  se podr&aacute;n llevar a cabo los siguientes trabajos:<br />
&middot; Sellado de juntas deterioradas de su ba&ntilde;era que ocasionen humedades por filtraciones en paredes contiguas.<br />
&middot; Sustituci&oacute;n de grifos y mecanismos de cisterna.<br />
&middot; Colocaci&oacute;n y sustituci&oacute;n de l&aacute;mparas y apliques de techo y pared.<br />
&middot; Montaje de muebles kit y estanter�as.<br />
&middot; Fijaci&oacute;n de elementos a paredes, tales como cuadros o espejos.<br />
&middot; Colocaci&oacute;n de accesorios de ba&ntilde;o y cocina.<br />
&middot; Instalaci&oacute;n de cortinas, visillos, estores.<br />
&middot; Sustituci&oacute;n de enchufes o interruptores de luz por otros diferentes (sin cambios de ubicaci&oacute;n)<br />
&middot; Puesta en marcha, conectividades y configuraci&oacute;n del equipamiento tecnol&oacute;gico, TDT, DVD, C&aacute;mara Digital, Home Cinema, Video Digital, Ordenadores, TV y V�deo, Consolas.<br />
El servicio ser&aacute; prestado por la red de profesionales de AXA de lunes a viernes en horario de 9 a 22 horas.<br />
<strong>* Lo aqu� recogido responde a unas l�neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'177',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('41','2','8','DA�OS EL�CTRICOS','Caida de Rayo','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro por</strong> los da&ntilde;os materiales que sufran los bienes asegurados  cuando se destruyan a consecuencia del impacto directo del rayo.
Adem&aacute;s quedan cubiertos, si usted lo ha contratado expresamente, los da&ntilde;os ocasionados a los veh&iacute;culos a motor, remolques, caravanas y embarcaciones de recreo cuando se encuentren estacionados dentro del garaje del riesgo asegurado en el momento de producirse el impacto directo del rayo. 
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'103',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('42','2','8','DA�OS EL�CTRICOS','Da�os el�ctricos','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro por esta causa para</strong> los gastos necesarios de localizaci&oacute;n o reparaci&oacute;n de aver&iacute;as causantes de los da&ntilde;os, en las instalaciones fijas privativas. Los da&ntilde;os materiales sufridos directamente  por la instalaci&oacute;n el&eacute;ctrica, as&iacute; como la propia edificaci&oacute;n y/o los aparatos el&eacute;ctricos y/o electr&oacute;nicos, como consecuencia de sobretensi&oacute;n, un cortocircuito, incluso las producidas por tormenta o rayo.
<strong>No est&aacute;n cubiertos</strong>:<br />
&middot; Reparaciones de aparatos el&eacute;ctricos y/o electr&oacute;nicos que no hayan sido realizadas por nuestros profesionales.
&middot; Las bombillas, l&aacute;mparas, hal&oacute;genos, tubos fluorescentes o similares
&middot; Los aparatos de antig�edad superior a  8 a&ntilde;os.
&middot; Los aparatos de valor inferior a 150 euros.
&middot; Da&ntilde;os y/o p&eacute;rdidas de los que sea legal o contractualmente responsable el fabricante o proveedor del aparato.
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'132',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('43','2','8','DA�OS EL�CTRICOS','Deterioro Bienes Refrigerados','|6|8|',null,'<p><strong>Puede declarar siniestro por esta causa para</strong> la podredumbre de bienes refrigerados o congelados dentro del frigor&iacute;fico o congelador, como consecuencia de falta de suministro el&eacute;ctrico o aver&iacute;a de dichos aparatos
<strong>No est&uacute;n cubiertos:</strong><br />
&middot; Los da&ntilde;os que hayan podido sufrir el frigor&iacute;fico o congelador.
&middot; Da&ntilde;os que puedan causar los bienes al deteriorarse, como mal olor, oxidaci&oacute;n  o limpieza del aparato.
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'116',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('40','2','7','OTROS SERVICIOS DE ASISTENCIA','Otros servicios','|6|7|8|10|',null,'<p>Dentro del apartado de Otros Servicios, le ofrecemos asesoramiento sobre la salud de las plantas de su jard&iacute;n, &aacute;rboles y arbustos as&iacute; como el mantenimiento de su piscina. </p>
<p>Servicio de consulta y ayuda para solucionar incidencias que afecten a equipos inform&aacute;ticos que se encuentren en la vivienda asegurada.</p>
<p>Cubrimos la rotura accidental de art&iacute;culos deportivos dentro de la vivienda asegurada.<br />
Cubrimos las siguientes prestaciones siempre que se deriven de un hecho accidental ocurrido durante un viaje de sus vacaciones o a consecuencia de practicar una actividad deportiva con car&aacute;cter amateur: Repatriaci&oacute;n o Transportes de heridos enfermos o fallecidos, gastos de curaci&oacute;n en el extranjero, Indemnizaci&oacute;n por retraso de equipaje y regreso anticipado en caso de hospitalizaci&oacute;n o defunci&oacute;n de un familiar.</p>
<p><strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'131',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('44','2','8','DA�OS EL�CTRICOS','Equipos informaticos','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro por esta causa para los</strong> da&ntilde;os materiales sufridos por ordenadores personales y sus equipos perif&eacute;ricos, en el interior de la edificaci&oacute;n asegurada, a primer riesgo, a consecuencia de:<br />
&middot; Impericia o negligencia.<br />
&middot; Impactos y colisiones accidentales.<br />
&middot; Derrame de l&iacute;quidos o introducci&oacute;n de cuerpos extra&ntilde;os, accidentalmente.<br />
&middot; Ca&iacute;das, excepto en equipos y elementos port&aacute;tiles.<br />
<strong>No est&aacute; cubierto:</strong><br />
&middot; P&eacute;rdidas o da&ntilde;os a equipos alquilados, si es responsable el propietario, ya sea legalmente o seg&uacute;n <br />
convenio de alquiler y/o mantenimiento.<br />
&middot; Elementos cuya antig&uuml;edad sea superior a 10 a&ntilde;os.<br />
&middot; Electrodom&eacute;sticos.<br />
&middot; Ca&iacute;das sufridas por equipos y elementos port&aacute;tiles.<br />
&middot; Defectos est&eacute;ticos, como raspaduras de superficies pintadas, pulidas o barnizadas.<br />
&middot; Cualquier gasto ocasionado con objeto de eliminar fallos operacionales, a menos que dichos fallos sean causados por p&eacute;rdida o da&ntilde;o indemnizable ocurrido a bienes asegurados.<br />
&middot; Cualquier gasto derivado del mantenimiento de los bienes asegurados. Tal exclusi&oacute;n se aplica a las <br />
partes recambiadas en el curso de dichas operaciones de mantenimiento.<br />
&middot; Las p&eacute;rdidas o da&ntilde;os causados directa o indirectamente por variaci&oacute;n o interrupci&oacute;n en el <br />
aprovisionamiento de corriente el&eacute;ctrica de la red p&uacute;blica.<br />
&middot; Defectos y vicios, as&iacute; como el desgaste o deterioro paulatino derivado del uso habitual.<br />
&middot; Ensayos y pruebas en cuyo transcurso sea sometido el bien asegurado a un desgaste superior al normal.<br />
&middot; Da&ntilde;os de los que sea responsable, legal o contractualmente, el fabricante o proveedor.<br />
&middot; Elementos susceptibles de desgaste por el uso habitual.<br />
&middot; El software y los programas inform&aacute;ticos en general, incluso los sistemas electr&oacute;nicos de protecci&oacute;n de paquetes de software (llaves de seguridad).<br />
&middot; Da&ntilde;os y gastos cubiertos por contrato de asistencia t&eacute;cnica o mantenimiento.<br />
&middot; Las roturas que se produzcan como consecuencia de la realizaci&oacute;n de obras, de la manipulaci&oacute;n y/o del transporte.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'179',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('45','2','8','DA�OS EL�CTRICOS','Aver�a Maquinaria-EquipoElect.','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta casusa  por</strong> los da&ntilde;os materiales directos hasta el l&iacute;mite indicado en la p&oacute;liza, que sufra la maquinaria, ordenadores y/o equipos electr&oacute;nicos como consecuencia de una causa accidental diferente al resto de las coberturas del contrato.<br />
AXA cubre los bienes asegurados desde el momento en que finalizado el montaje,las pruebas  operacionales, est&aacute;n preparados para comenzar la explotaci&oacute;n normal, permaneciendo cubiertos tanto en funcionamiento como parados, durante su desmontaje y montaje subsiguiente con objeto de proceder a su limpieza, revisi&oacute;n o mantenimiento.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; No se podr&aacute;  invocar esta cobertura como complemento a las prestaciones de dichas coberturas, ni como sustituci&oacute;n de sus l&iacute;mites o exclusiones.<br />
&middot; Los da&ntilde;os debidos al uso o desgaste normal o paulatino, as&iacute; como los sufridos por parte de las mquinas y equipos que necesiten por su propio funcionamiento un reemplazo frecuente y los producidos por erosi&oacute;n, corrosi&oacute;n, oxidaci&oacute;n, cavitaci&oacute;n, herrumbre o incrustaciones.<br />
&middot; Los da&ntilde;os sufridos por las m&aacute;quinas y equipos de antig�edad superior a 7 a&ntilde;os.<br />
&middot; Los simples da&ntilde;os y defectos est&eacute;ticos, los que afectan a los elementos que deben ser renovados frecuentemente, los lubricantes y refrigerantes y los defectos y/o vicios ya existentes al contratar el seguro.<br />
&middot; Los da&ntilde;os por exposici&oacute;n de la maquinaria, ordenadores y/o equipos a condiciones anormales o sobrecargas intencionadas, o durante experimentos, ensayos o pruebas en los que se exijan esfuerzos superiores al normal y los causados por fallos o interrupciones en el aprovisionamiento de la energ&iacute;a avisados con antelaci&oacute;n.<br />
&middot; Los da&ntilde;os o p&eacute;rdidas de los que sea legal o contractualmente responsable el fabricante o proveedor de las maquinas y/o equipos.<br />
&middot; Los perjuicios y p&eacute;rdidas indirectas de cualquier clase.<br />
&middot; Las ca&iacute;das de equipos y elementos port&aacute;tiles.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.&#8195;</strong></p>',to_date('29/11/16','DD/MM/RR'),'123',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('46','2','9','INCENDIO','Incendio','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> los da&ntilde;os materiales que sufran los bienes asegurados cuando se destruyan a causa de incendio y/o explosi&oacute;n.<br />
&middot; Los da&ntilde;os a veh&iacute;culos a motor, remolques, caravanas y embarcaciones de recreo, si est&aacute;n dentro del garaje  particular en el momento del siniestro si se han incluido expresamente en las condiciones particulares de la p&oacute;liza<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot;  Los da&ntilde;os en los bienes asegurados que no sean debidos a incendio, por ejemplo, los da&ntilde;os producidos por chispas, chispazos, cigarrillos, braseros o elementos de calor de los que no se derive incendio.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'101',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('47','2','9','INCENDIO','Humo','|6|7|8|10|',null,'<p><strong>uede declarar siniestro por esta causa por</strong> los da�os materiales a los bienes asegurados cuando se produzca unas fuga,  escape repentino o anormal  en las conducciones de extracci�n de humo (chimeneas, extractores, etc) tanto si se han originado en el interior de la vivienda como en el exterior de la misma.<br />
<strong>Qu� no est� cubierto:</strong><br />
&middot; Los da�os causados por la acci�n continuada del humo.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'110',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('48','2','9','INCENDIO','Explosion','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa por los</strong> da�os materiales que sufran los bienes asegurados cuando se destruyan a consecuencia de incendio y/o explosi�n.<br />
&middot; Los da�os ocasionados a los veh�culos a motor, remolques, caravanas y embarcaciones de recreo cuando se encuentren estacionados dentro del garaje de la vivienda asegurada en el momento de producirse el incendio.<br />
<strong>No est&aacute; cubierto:</strong><br />
&middot; Los da�os en los bienes asegurados que no sean debidos a incendio, por ejemplo, los da�os provocados por chispas, chispazos, cigarrillos, braseros o elementos de calor, de los que no se derive incendio.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'102',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('49','2','10','CO-PARTICIPACION DA�OS COMUNIDAD','Coparticipaci�n Comunidad','|6|8|10|',null,'<p>La coparticipaci&oacute;n es el porcentaje con el que el asegurado participa en copropiedad junto a otras Comunidades en el uso y disfrute de instalaciones comunes, pertenecientes a dichas Comunidades.<br />
Este porcentaje de coparticipaci&oacute;n (que se refleja en las escrituras de propiedad)  formar&aacute; parte del capital asegurado para los diferentes tipos de siniestros.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'130',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('50','2','11','EMPLEADOS - TARJETAS','Infidelidad de Empleados','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> el robo y expoliaci�n que afecte a la infidelidad de empleados como por ejemplo falta de mercanc�a, recaudaci�n. etc, con sospechas fundadas de que el culpable es un empleado.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'121',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('52','2','12','ACCIDENTES','Accidentes','|6|8|10|',null,'<p><b>Qu&eacute; est&aacute; cubierto:</b><br />
Si el asegurado o cualquier miembro de su familia sufre un accidente en la vivienda asegurada, AXA se har&aacute; cargo de las siguientes prestaciones:<br />
a) Gastos de curaci&oacute;n<br />
Gastos m&eacute;dicos y farmac&eacute;uticos derivados de las lesiones personales que pueda sufrir el asegurado o cualquier miembro de su familia:<br />
&middot; Sin l&iacute;mite econ&oacute;mico en los centros concertados con AXA y durante un periodo m&aacute;ximo de 3 a&ntilde;os, siguientes a la fecha de ocurrencia del siniestro.<br />
b) Indemnizaci&oacute;n para el caso de fallecimiento<br />
AXA pagar&aacute; los beneficiarios la suma asegurada indicada en la Tabla Resumen del Condicionado General de la p&oacute;liza.<br />
c) Indemnizaci&oacute;n para caso de invalidez permanente <br />
d) Anticipo de capital en caso de fallecimiento para atender a los gastos derivados del fallecimiento del Asegurado en caso de accidente.<br />
e) Prestaci&oacute;n extraordinaria para menores de edad <br />
f) Asesoramiento v&iacute;a telef&oacute;nica con un m&eacute;dico las 24 h. del d&iacute;a los 365 d&iacute;as del a&ntilde;o<br />
g) Los gastos de asistencia psicol&oacute;gica del asegurado para superar el stress post traum&aacute;tico sufrido como consecuencia del accidente.<br />
El m&aacute;ximo de siniestros por anualidad de seguro para esta cobertura ser&aacute; de 5.<br />
<b>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</b><br />
</p>',to_date('29/11/16','DD/MM/RR'),'134',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('53','2','12','ACCIDENTES','Accidentes por calor','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os causados en la edificaci&oacute;n y/o enseres asegurados por la acci&oacute;n s&uacute;bita del calor o del contacto directo del fuego o de una sustancia incandescente aun cuando no se produzca incendio<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Da&ntilde;os causados por &quot;accidente de fumador&quot;<br />
&middot; Joyas y objetos de valor art&iacute;stico.<br />
&middot; Gafas y art&iacute;culos &oacute;pticos en general, incluso a&eacute;reos o n&aacute;uticos.<br />
&middot; Aparatos electr&oacute;nicos.<br />
&middot; Da&ntilde;os causados por la acci&oacute;n progresiva de la temperatura y de las diferentes condiciones atmosf&eacute;ricas.<br />
&middot; Fallos en los dispositivos de regulaci&oacute;n<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'148',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('54','2','13','INHABITABILIDAD - TRASLADO','Traslado por decisi�n de la autoridad','|6|',null,'<p><strong>Puede declarar siniestro con esta causa y AXA se har&aacute; cargo</strong> de los gastos derivados de inhabitabilidad de la vivienda asegurada, a consecuencia de una orden administrativa o judicial y siempre que esta situaci&oacute;n no se deba a un expediente administrativo de declaraci&oacute;n de ruina. Axa les abona un alojamiento provisional similar si el asegurado no puede hacer uso de su vivienda a consecuencia de un  siniestro cubierto por la p&oacute;liza y los gastos de traslado temporal de  mobiliario y objetos personales del asegurado: hotel, mudanza, guardamuebles, con los l&iacute;mites que se detallan en la p&oacute;liza.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'176',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('13','4','10','SANCIONES','Circular sin cintur�n de seguridad u otros sistemas de sujeci�n homologado / menor no sujeto','|2|',null,'<p>Circular sin llevar el cintur&oacute;n abrochado / sin sujeci&oacute;n legalmente establecida / con menor no sujeto</p>',to_date('06/04/17','DD/MM/RR'),'17',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('51','2','11','EMPLEADOS - TARJETAS','Uso fraudulento de tarjetas','|6|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa,  incluida en</strong> la garant&iacute;a de Robo y Expoliaci&oacute;n.  AXA cubre el uso fraudulento de tarjetas de cr&eacute;dito, hasta el l&iacute;mite establecido en p&oacute;liza.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; El hurto de dinero en efectivo.<br />
&middot; El robo o hurto que afecte a enseres que se encuentren en dependencias que no sean de su uso exclusivo.<br />
&middot; P&eacute;rdidas o extrav&iacute;os<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'180',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('14','4','11','SANCIONES','Incumplimiento de la obligaci�n de identificar al conductor','|2|',null,'<p>No realizar la identificaci&oacute;n del conductor habiendo sido requerido para ello en tiempo y forma oportunos...</p>',to_date('06/04/17','DD/MM/RR'),'11',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('26','4','18','SANCIONES','Carnet de conducir','|2|','No llevar permiso de conducir','<p>Circular con un permiso de conducir que no se encuentra vigente, o no aportarlo cuando se le solicita... </p>',to_date('06/04/17','DD/MM/RR'),'21',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('27','4','18','SANCIONES','Carnet de conducir','|2|','Retirada del permiso de conducir por p�rdida total de puntos','<p>Circular con un permiso de conducir que no se encuentra vigente, o no aportarlo cuando se le solicita... </p>',to_date('06/04/17','DD/MM/RR'),'21',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('28','4','19','SANCIONES','Circular por una zona restringida o reservada a determinados usuarios','|2|',null,'<p>Circular sin autorizaci&oacute;n por zona de residentes </p>',to_date('06/04/17','DD/MM/RR'),'3',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('29','4','20','SANCIONES','Otros','|2|',null,'<p>Supuesto no englobado en los casos anteriores</p>',to_date('06/04/17','DD/MM/RR'),'18',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('9','3','9','AUTOS','Colisi�n Objeto / Animal','|2|',null,'<p>Siniestro ocasionado por la colisi&oacute;n con un contrario no auto (Ej: Un perro cruza la carretera al paso del veh&iacute;culo asegurado colisionando, o-&#160;Se desprende un trozo de fachada de una vivienda).</p>',to_date('17/11/16','DD/MM/RR'),'243',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('10','3','10','AUTOS','S�lo Lunas. Da�os o Lunas','|2|',null,'<p>Siniestro en el que solo se ven afectadas las lunas de tu veh&iacute;culo, ya sea para una reparaci&oacute;n o sustituci&oacute;n completa.</p>',to_date('17/11/16','DD/MM/RR'),'248',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('11','3','11','AUTOS','Da�os Atmosf�ricos','|2|',null,'<p>Siniestro producido por eventos meteorol&oacute;gicos</p>',to_date('17/11/16','DD/MM/RR'),'273',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('57','2','16','OBJETOS DE ARTE','Todo Riesgo Objetos de arte','|6|7|8|',null,'<p>Cubrimos los objetos de valor art&iacute;stico, que se encuentren declarados en la p&oacute;liza, de robo, atraco, expoliaci&oacute;n o hurto, p&eacute;rdida, incendio o da&ntilde;os accidentales o causados por mala intenci&oacute;n de terceros.</p>',to_date('29/11/16','DD/MM/RR'),'184',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('6','3','6','AUTOS','Atropello','|2|',null,'<p>Siniestro en el que ha sido atropellado un peat&oacute;n.</p>',to_date('17/11/16','DD/MM/RR'),'208',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('7','3','7','AUTOS','Incendio','|2|',null,'<p>Siniestro de da&ntilde;os sufridos por el veh&iacute;culo como&#160;consecuencia de un incendio, explosi&oacute;n o ca&iacute;da de rayo.</p>',to_date('17/11/16','DD/MM/RR'),'210',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('8','3','8','AUTOS','Salida V�a','|2|',null,'<p>Siniestro debido a una salida de v&iacute;a por la p&eacute;rdida del control del veh&iacute;culo asegurado en v&iacute;as de circulaci&oacute;n autorizadas ocasionando da&ntilde;os al propio veh&iacute;culo o a terceros.</p>',to_date('17/11/16','DD/MM/RR'),'216',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('59','2','2','FEN�MENOS EXTERNOS O DE LA NATURALEZA','Pedrisco-Nieve','|6|7|8|10|',null,'<p><strong>Qu; est; cubierto:</strong><br />
Da;os materiales a los bienes asegurados cuando se destruyan a consecuencia de los fen;menos externos de pedrisco o nieve, de intensidad tal que afecte a varios edificios de buena construcci;n en las proximidades de la vivienda asegurada. Se incluyen los da;os producidos por objetos arrastrados o proyectados por el viento o la lluvia.<br />
; Si la cantidad de lluvia es superior a 40l/m2 y hora, o la velocidad del viento es superior a 84 Km/h., no ser; necesario el requisito que varios edificios se encuentren afectados.<br />
; Inundaci;n debida a desbordamientos de cauces o cursos de agua construidos por el hombre y cuya cobertura no corresponda al Consorcio de Compensaci;n de seguros.<br />
<strong>Qu; no est; cubierto:</strong><br />
; Da;os a los enseres del hogar que est;n depositados al aire libre, aun cuando se hallen protegidos por materiales flexibles (lonas, pl;sticos, construcciones hinchables o similares) o contenidos en el interior de construcciones abiertas.<br />
; Da;os producidos por nieve, agua, arena o el polvo que entre por puertas, ventanas u otras aberturas que est;n sin cerrar o con cierre defectuoso.<br />
; Da;os producidos por heladas, frio o hielo<br />
; Da;os producidos por olas o mareas, incluso cuando estos fen;menos hayan sido causados por el viento.<br />
; Da;os producidos por desbordamiento o rotura de presas y diques de contenci;n<br />
<strong>* Lo aqu; recogido responde a unas l;neas generales de contrataci;n, para el siniestro en concreto se aplicar;n las condiciones generales y particulares de la p;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'106',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('12','3','12','AUTOS','Actos Vand�licos','|2|',null,'<p>Da&ntilde;os ocasionados al veh&iacute;culo con la intenci&oacute;n de deteriorar, o incluso destruir el coche sin ninguna finalidad de lucro</p>',to_date('01/12/16','DD/MM/RR'),'278',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('13','3','13','AUTOS','Da�os Cineg�ticos','|2|',null,'<p>Siniestro ocasionado por la colisi&oacute;n por atropello de un animal cineg&eacute;tico y animales dom&eacute;sticos de explotaciones ganaderas cubierto si la p&oacute;liza tiene contratado el KIT �Da&ntilde;os por colisi&oacute;n por atropello contra especies cineg&eacute;ticas� y siempre y cuando haya atestado policial.</p>',to_date('28/11/16','DD/MM/RR'),'272',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('14','3','14','AUTOS','Pedrisco Granizo  ','|2|',null,'<p>Siniestro producido por pedrisco o granizo.</p>',to_date('28/11/16','DD/MM/RR'),'212',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('130','1','0','TODAS LAS CAUSAS','Restablecimiento de luz','|6|7|8|10|',null,'<p>Tiene a su disposici&oacute;n nuestra red de reparadores para los siguientes servicios de contenci&oacute;n de da&ntilde;os durante las 24 horas del d&iacute;a todos los d&iacute;as de la semana:</p>
<p><strong>Que cubre:</strong><br />
El env&iacute;o de un electricista, para que si es posible reanude el servicio, si una causa<br />
accidental deja sin luz la vivienda asegurada.</p>
<p>Los gastos del env&iacute;o del profesional y la mano de obra ser&aacute;n a cargo de AXA. El coste de la renovaci&oacute;n de los materiales da&ntilde;ados ser&aacute; a su cargo, excepto cuando los da&ntilde;os tengan su origen en cualquiera de los riesgos cubiertos por la p&oacute;liza, en cuyo caso, AXA asume el coste de dichos materiales</p>
<p><strong>No est&aacute;n cubiertas:</strong> Reparaciones no efectuadas por la red de reparadores de AXA.</p>
<p><strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'187','							Recuerda que tienen que ir reparadores de la Compa��a para esta causa.
																																																														 
												 
												 
												 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('100','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Conflicto  colindantes','|6|7|8|10|','PJ','<p>Defensa de los intereses del cliente cuando se encuentre involucrado en alg&uacute;n conflicto en relaci&oacute;n con la Edificaci&oacute;n asegurada.Frente a sus inmediatos vecinos por cuestiones de servidumbres de paso, luces, vistas, distancias, lindes, medianer&iacute;as y plantaciones.<br /> 
- Frente a la comunidad de propietarios siempre que estuviese al corriente del pago de las cuotas legalmente acordadas.</p>',to_date('30/11/21','DD/MM/RR'),'0',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('22','2','3','AVER�AS  - MERCANC�AS - DERRAMES','Derrame Inst.fijas Extinci�n','|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa siempre que se hayan producido</strong> da&ntilde;os materiales en la edificaci&oacute;n o enseres, nos hacenmos cargo de los gastos necesarios de localizaci&oacute;n o reparaci&oacute;n de aver&iacute;as causantes de los da&ntilde;os, en las instalaciones fijas privativas.<br />
&middot; Los da&ntilde;os materiales directos a los bienes asegurados a consecuencia de derrame accidental o filtraciones de agua proveniente de instalaciones fijas o aparatos conectados a la red de agua.<br />
&middot; Da&ntilde;os que tengan su origen en redes de saneamiento subterr&aacute;neas, tales como fosas s&eacute;pticas, arquetas, cloacas, alcantarillados y similares.<br />
&middot; Da&ntilde;os por agua que se produzcan a causa de heladas.<br />
<strong>No est&aacute;n cubiertos: </strong><br />
&middot; Da&ntilde;os debidos a corrosi&oacute;n generalizada o desgastes notorios de las instalaciones de la edificaci&oacute;n.<br />
&middot; Los gastos de desatasco.<br />
&middot; Los gastos de reparaci&oacute;n de aparatos o instalaciones de agua u otros l&iacute;quidos distintos a las propias tuber&iacute;as o conducciones de agua u otros l&iacute;quidos tales como: electrodom&eacute;sticos, grifer&iacute;as, o llaves de paso, aparatos sanitarios, calderas, calentadores, acumuladores, radiadores, arquetas, fosas s&eacute;pticas e instalaciones subterr&aacute;neas.<br />
&middot; Los gastos de reparaci&oacute;n de tejados o fachadas, aunque se hayan producido da&ntilde;os por agua garantizados por la p&oacute;liza.<br />
&middot; Gastos necesarios para corregir instalaciones defectuosas o mal dise&ntilde;adas.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'114',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('20','1','1','DA�OS AGUA-OTROS L�QUIDOS','Derrame Mercancias L�quidas','|8|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> los da&ntilde;os y o p&eacute;rdidas de las mercanc&iacute;as l&iacute;quida, hasta el l&iacute;mite indicado en p&oacute;liza, a consecuencia de: destrucci&oacute;n, rotura, revent&oacute;n o agrietamiento de car&aacute;cter accidental de los dep&oacute;sitos que las contienen.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Los defectos de construcci&oacute;n fabricaci&oacute;n o instalaci&oacute;n de los dep&oacute;sitos, as&iacute; como los debidos a vetustez, desgaste, oxidaci&oacute;n o corrosi&oacute;n de los mismos.<br />
&middot; Las p&eacute;rdidas durante su trasvase o llenado; as&iacute; como los debidos a fallos en los aparatos y l&iacute;neas de conducci&oacute;n, llenado o trasvase.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'129','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('60','1','7','SERVICIOS DE ASISTENCIA','Restablecimiento de luz','|6|7|8|10|',null,'<p>Tiene a su disposici&oacute;n nuestra red de reparadores para los siguientes servicios de contenci&oacute;n de da&ntilde;os durante las 24 horas del d&iacute;a todos los d&iacute;as de la semana:</p>
<p><strong>Que cubre:</strong><br />
El env&iacute;o de un electricista, para que si es posible reanude el servicio, si una causa<br />
accidental deja sin luz la vivienda asegurada.</p>
<p>Los gastos del env&iacute;o del profesional y la mano de obra ser&aacute;n a cargo de AXA. El coste de la renovaci&oacute;n de los materiales da&ntilde;ados ser&aacute; a su cargo, excepto cuando los da&ntilde;os tengan su origen en cualquiera de los riesgos cubiertos por la p&oacute;liza, en cuyo caso, AXA asume el coste de dichos materiales</p>
<p><strong>No est&aacute;n cubiertas:</strong> Reparaciones no efectuadas por la red de reparadores de AXA.</p>
<p><strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'187','							Recuerda que tienen que ir reparadores de la Compa��a para esta causa.
																																																														 
												 
												 
												 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('131','1','0','TODAS LAS CAUSAS','Restablecimiento de agua','|6|7|8|10|',null,'<p>El asegurado tiene a su disposici&oacute;n la red de reparadores de AXA para los siguientes servicios de contenci&oacute;n de da&ntilde;os durante las 24 horas del d&iacute;a todos los d&iacute;as de la semana:</p>
<p><strong>Que cubre:</strong><br />
El env&iacute;o de un fontanero a la vivienda asegurada para, si es posible, reanudar el servicio en caso de rotura de instalaciones fijas de fontaner&iacute;a.</p>
<p>Los gastos del env&iacute;o del profesional y la mano de obra ser&aacute;n a cargo de AXA. El coste de la renovaci&oacute;n de los materiales da&ntilde;ados ser&aacute; a su cargo, excepto cuando los da&ntilde;os tengan su origen en cualquiera de los riesgos cubiertos por la p&oacute;liza, en cuyo caso, AXA asume el coste de dichos materiales</p>
<p><strong>No est&aacute;n cubiertas:</strong> Reparaciones no efectuadas por la red de reparadores de AXA.</p>
<p><strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'187','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('61','1','7','SERVICIOS DE ASISTENCIA','Restablecimiento de agua','|6|7|8|10|',null,'<p>El asegurado tiene a su disposici&oacute;n la red de reparadores de AXA para los siguientes servicios de contenci&oacute;n de da&ntilde;os durante las 24 horas del d&iacute;a todos los d&iacute;as de la semana:</p>
<p><strong>Que cubre:</strong><br />
El env&iacute;o de un fontanero a la vivienda asegurada para, si es posible, reanudar el servicio en caso de rotura de instalaciones fijas de fontaner&iacute;a.</p>
<p>Los gastos del env&iacute;o del profesional y la mano de obra ser&aacute;n a cargo de AXA. El coste de la renovaci&oacute;n de los materiales da&ntilde;ados ser&aacute; a su cargo, excepto cuando los da&ntilde;os tengan su origen en cualquiera de los riesgos cubiertos por la p&oacute;liza, en cuyo caso, AXA asume el coste de dichos materiales</p>
<p><strong>No est&aacute;n cubiertas:</strong> Reparaciones no efectuadas por la red de reparadores de AXA.</p>
<p><strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'187','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('62','1','7','SERVICIOS DE ASISTENCIA','Apertura de puerta','|6|7|8|10|',null,'<p>Tiene a su disposici&oacute;n nuestra red de reparadores para los siguientes servicios de contenci&oacute;n de da&ntilde;os durante las 24 horas del d&iacute;a todos los d&iacute;as de la semana:</p>
<p><strong>Que cubre:</strong><br />
El env&iacute;o de un cerrajero para la apertura de puerta si por una contingencia, incluida la p&eacute;rdida de llaves, no puede entrar a la vivienda asegurada y no hay otra soluci&oacute;n.</p>
<p>Los gastos del env&iacute;o del profesional y la mano de obra ser&aacute;n a cargo de AXA. El coste de la renovaci&oacute;n de los materiales da&ntilde;ados ser&aacute; a su cargo, excepto cuando los da&ntilde;os tengan su origen en cualquiera de los riesgos cubiertos por la p&oacute;liza, en cuyo caso, AXA asume el coste de dichos materiales</p>
<p><strong>No est&aacute;n cubiertas:</strong> Reparaciones no efectuadas por la red de reparadores de AXA.</p>
<p><strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'187','	Recuerda que tienen que ir reparadores de la Compa��a para esta garant�a.																			Recuerda que tienen que ir reparadores de la Compa��a para esta garant�a
																																										 
												 
												 
												 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('63','1','7','SERVICIOS DE ASISTENCIA','Env�o profesionales','|6|7|8|10|',null,'<p>Si el asegurado necesita realizar una reparaci&oacute;n, obras de reforma o mejoras en la vivienda asegurada, AXA pone a su disposici&oacute;n una amplia red de reparadores.<br />
Los gastos de desplazamiento del profesional y el presupuesto oportuno ser&aacute;n a cargo de AXA.</p>
<p>El coste de la renovaci&oacute;n de los materiales da&ntilde;ados, excepto cuando los da&ntilde;os tengan su origen en cualquiera de los riesgos cubiertos por la p&oacute;liza, ser&aacute;n a cargo del cliente.</p>
<p><strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'192','							Recuerda que este servicio lo tiene que pagar el cliente.
																																																														 
												 
												 
												 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('61','2','7','OTROS SERVICIOS DE ASISTENCIA','Restablecimiento de agua','|6|7|8|10|',null,'<p>El asegurado tiene a su disposici&oacute;n la red de reparadores de AXA para los siguientes servicios de contenci&oacute;n de da&ntilde;os durante las 24 horas del d&iacute;a todos los d&iacute;as de la semana:</p>
<p><strong>Que cubre:</strong><br />
El env&iacute;o de un fontanero a la vivienda asegurada para, si es posible, reanudar el servicio en caso de rotura de instalaciones fijas de fontaner&iacute;a.</p>
<p>Los gastos del env&iacute;o del profesional y la mano de obra ser&aacute;n a cargo de AXA. El coste de la renovaci&oacute;n de los materiales da&ntilde;ados ser&aacute; a su cargo, excepto cuando los da&ntilde;os tengan su origen en cualquiera de los riesgos cubiertos por la p&oacute;liza, en cuyo caso, AXA asume el coste de dichos materiales</p>
<p><strong>No est&aacute;n cubiertas:</strong> Reparaciones no efectuadas por la red de reparadores de AXA.</p>
<p><strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'187',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('45','1','62','DA�OS EL�CTRICOS','Averia de maquinaria o Equipos electr�nicos','|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os materiales directos a primer riesgo hasta el l&iacute;mite indicado en la p&oacute;liza, que sufra la maquinaria, ordenadores y/o equipos electr&oacute;nicos durante su normal utilizaci&oacute;n, como consecuencia de una causa accidental diferente al resto de las coberturas del contrato.<br />
AXA cubre los bienes asegurados desde el momento en que finalizado el montaje y realizadas las pruebas operacionales, est&aacute;n preparados para comenzar la explotaci&oacute;n normal, permaneciendo cubiertos tanto en funcionamiento como parados, durante su desmontaje y montaje subsiguiente con objeto de proceder a su limpieza, revisi&oacute;n o mantenimiento.<br />
<strong>No est&aacute;n cubiertos</strong>:<br />
&middot; Los que encuentren cobertura dentro de las garant&iacute;as en la p&oacute;liza. No se podr&aacute; invocar esta cobertura como complemento a las prestaciones de dichas coberturas, ni como sustituci&oacute;n de sus l&iacute;mites o exclusiones.<br />
&middot; Los da&ntilde;os debidos al uso o desgaste normal o paulatino, as&iacute; como los sufridos por parte de las m&aacute;quinas y equipos que necesiten por su propio funcionamiento un reemplazo frecuente y los producidos por erosi&oacute;n, corrosi&oacute;n, oxidaci&oacute;n, cavitaci&oacute;n, herrumbre o incrustaciones.<br />
&middot; Los da&ntilde;os sufridos por las m&aacute;quinas y equipos de antig&uuml;edad superior a 7 a&ntilde;os.<br />
&middot; Los simples da&ntilde;os y defectos est&eacute;ticos, los que afectan a los elementos que deben ser renovados frecuentemente, los lubricantes y refrigerantes y los defectos y/o vicios ya existentes al contratar el seguro.<br />
&middot; Los da&ntilde;os por exposici&oacute;n de la maquinaria, ordenadores y/o equipos a condiciones anormales o sobrecargas intencionadas, o durante experimentos, ensayos o pruebas en los que se exijan esfuerzos superiores al normal y los causados por fallos o interrupciones en el aprovisionamiento de la energ&iacute;a avisados con antelaci&oacute;n.<br />
&middot; Los da&ntilde;os o p&eacute;rdidas de los que sea legal o contractualmente responsable el fabricante o proveedor de las maquinas y/o equipos.<br />
&middot; Los perjuicios y p&eacute;rdidas indirectas de cualquier clase.<br />
&middot; Las ca&iacute;das de equipos y elementos port&aacute;tiles.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.&#8195;</strong></p>',to_date('30/11/21','DD/MM/RR'),'123','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('46','1','9','INCENDIO','Incendio','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
&middot; Los da&ntilde;os materiales que sufran los bienes asegurados cuando se destruyan a causa de incendio y/o explosi&oacute;n.<br />
&middot; Los da&ntilde;os ocasionados a los veh&iacute;culos a motor, remolques, caravanas y embarcaciones de recreo cuando se encuentren estacionados dentro del garage de la vivienda asegurada en el momento de producirse el incendio.<br />
<strong>Qu&eacute; no est&aacute; cubierto: </strong><br />
&middot; Los da&ntilde;os en los bienes asegurados que no sean debidos a incendio, por ejemplo, los da&ntilde;os producidos por chispas, chispazos, cigarrillos, braseros o elementos de calor de los que no se derive incendio.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'101','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('23','2','4','ATRACO - ROBO','Atraco dentro','|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa en caso de</strong><br /> de robo y expoliaci&oacute;n producido con fuerza en las cosas para acceder a ellas o con violencia o intimidaci&oacute;n a las personas, y que afecte a: mobiliario, las mercanc&iacute;as o los da&ntilde;os materiales y desperfectos causados a los bienes asegurados durante el robo.<br />
<strong>Hasta los l&iacute;mites indicados, la garant&iacute;a se extiende a:</strong><br />
&middot; El robo y expoliaci&oacute;n de las mercanc&iacute;as que se encuentran en escaparates independientes del negocio asegurado.<br />
&middot; El robo y expoliaci&oacute;n del dinero en efectivo o documentos bancarios acreditativos de dinero.<br />
&middot; La expoliaci&oacute;n a clientes, empleados y visitantes, cometido en el interior del negocio asegurado, incluidos los gastos de asistencia sanitaria urgente por expoliaci&oacute;n.<br />
&middot; Los gastos de reposici&oacute;n de llaves y cerraduras, por otras de similares prestaciones y caracter&iacute;sticas, si deben ser sustituidas a consecuencia de un robo como medida de precauci&oacute;n para evitar el f&aacute;cil acceso al establecimiento.<br />
&middot; La infidelidad de empleados.<br />
&middot; La expoliaci&oacute;n a cobradores o transportadores de fondos.<br />
&middot; Los gastos de puesta en orden de archivos.<br />
&middot; Los gastos de limpieza y acondicionamiento del negocio.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'119',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('24','2','4','ATRACO - ROBO','Atraco fuera','|6|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa en caso de</strong> robo en v&iacute;a p&uacute;blica cometido con violencia o intimidaci&oacute;n hacia usted, miembros de su familia que convivan con usted o empleados. Quedan cubiertos los enseres y dinero en efectivo, hasta el l&iacute;mite indicado en la p&oacute;liza<br />
<strong>No est&aacute; cubierto:</strong><br />
&middot; El Hurto de dinero en efectivo, es decir, la sustracci&oacute;n al descuido.<br />
&middot; El robo y/o hurto de los objetos de valor art&iacute;stico.<br />
&middot; El robo o hurto que afecte a enseres que se encuentren en dependencias que no sean de su uso exclusivo como  escaleras, patios o garajes comunitarios.<br />
&middot; El robo o hurto que afecte a joyas que se encuentren  al aire libre, en patios o jardines, o en el interior de construcciones abiertas.<br />
&middot; P&eacute;rdidas o extrav&iacute;os.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'120',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('25','2','4','ATRACO - ROBO','Robo','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> el robo y expoliaci&oacute;n producido con fuerza en las cosas para acceder a ellas o con violencia o intimidaci&oacute;n a las personas, y que afecte a:<br />
&middot; El mobiliario<br />
&middot; Las joyas o alhajas hasta el l&iacute;mite indicado en p&oacute;liza.<br />
&middot; Dinero en efectivo, hasta el l&iacute;mite indicado en p&oacute;liza.<br />
&middot; Los da&ntilde;os materiales y desperfectos causados a los bienes asegurados durante el robo.<br />
&middot; El robo de los elementos de la edificaci&oacute;n como  puertas, ventanas, antenas.<br />
&middot; Los gastos de reposici&oacute;n de llaves y cerraduras, por otras de similares prestaciones y caracter&iacute;sticas, si deben ser sustituidas a consecuencia de un robo como medida de precauci&oacute;n para evitar el f&aacute;cil acceso a la vivienda, hasta el l&iacute;mite indicado en p&oacute;liza. <br />
&middot; El uso fraudulento de tarjetas de cr&eacute;dito, hasta el l&iacute;mite indicado en p&oacute;liza.<br />
&middot; Hurto, o sustracci&oacute;n sin fuerza en las cosas para acceder al lugar donde se encuentran, ni violencia o intimidaci&oacute;n en las personas, hasta el l&iacute;mite indicado en el apartado Tabla Resumen y que afecte a los enseres asegurados.<br />
&middot; El robo fuera cometido con violencia o intimidaci&oacute;n hacia el asegurado o miembros de su familia de:<br />
&middot; Enseres, hasta el l&iacute;mite indicado en p&oacute;liza.<br />
&middot; Dinero en efectivo, hasta el l&iacute;mite indicado en p&oacute;liza.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; El Hurto de dinero en efectivo.<br />
&middot; El robo y/o hurto de los objetos de valor art&iacute;stico.<br />
&middot; El robo o hurto que afecte a enseres que se encuentren en dependencias que no sean de su uso exclusivo, como portales, garajes, patios o recintos comunitarios.<br />
&middot; El robo o hurto que afecte a joyas que se encuentren  al aire libre, en patios o jardines, o en el interior de  construcciones abiertas.<br />
&middot; P&eacute;rdidas o extrav&iacute;os<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'118',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('26','2','4','ATRACO - ROBO','Actos de Vandalismo','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa si existen</strong> los da&ntilde;os materiales a los bienes asegurados cuando se produzcan actos de vandalismo o malintencionados cometidos individual o colectivamente por otras personas.<br />
<strong>No est&aacute;n cubiertos :</strong><br />
&middot; Los da&ntilde;os causados por los inquilinos o por otros ocupantes de la vivienda.<br />
&middot; Las pintadas, rayadas, inscripciones y pegado de carteles.<br />
&middot; Los actos de vandalismo que no se hayan denunciado ante la autoridad competente.<br />
&middot; La rotura de cristales o materiales sustitutivos del cristal, lunas espejos, m&aacute;rmoles y elementos de loza sanitaria salvo cuando est&eacute; contratada la garant&iacute;a de roturas.<br />
&middot; Los da&ntilde;os producidos por robo y expoliaci&oacute;n, salvo cuando est&eacute; contratada la garant&iacute;a de robo.<br />
. Los actos de vandalismo cuando los bienes asegurados no se encuentren en la vivienda asegurada<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'108',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('27','2','4','ATRACO - ROBO','Infidelidad de Empleados','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> el robo y expoliaci�n que afecte a la infidelidad de empleados como por ejemplo falta de mercanc�a, recaudaci�n. etc, con sospechas fundadas de que el culpable es un empleado.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'121',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('28','2','4','ATRACO - ROBO','Uso fraudulento de tarjetas','|6|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa,  incluida en</strong> la garant&iacute;a de Robo y Expoliaci&oacute;n.  AXA cubre el uso fraudulento de tarjetas de cr&eacute;dito, hasta el l&iacute;mite establecido en p&oacute;liza.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; El hurto de dinero en efectivo.<br />
&middot; El robo o hurto que afecte a enseres que se encuentren en dependencias que no sean de su uso exclusivo.<br />
&middot; P&eacute;rdidas o extrav&iacute;os<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'180',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('29','2','5','ROTURAS','Cristales-Espejos','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro por esta causa en caso de</strong> la rotura, incluidos los gastos de transporte, colocaci&oacute;n y montaje de:<br />
&middot; Cristales y espejos fijados a la edificaci&oacute;n o a los enseres.<br />
&middot; Cristales planos destinados a cubrir muebles de forma permanente.<br />
&middot; Encimeras de m&aacute;rmol, granito u otras piedras naturales o artificiales.<br />
&middot; Elementos sanitarios de cualquier material.<br />
&middot; Cristal de placa vitrocer&aacute;mica o de inducci&oacute;n.<br />
&middot; Cristal de placa solar.<br />
&middot; Acuarios o peceras de cristal o cualquier otro material.<br />
&middot; Muebles, mamparas o estanter&iacute;as de cristal, metacrilato u otros pl&aacute;sticos de similares caracter&iacute;sticas<br />
<strong>No est&aacute;n cubiertos</strong><br /> 
&middot; Simples ara&ntilde;azos, raspaduras, desconchados o deterioros superficiales.<br />
&middot; Marcos, molduras y muebles de los que formen parte.<br />
&middot; Valor de los decorados art&iacute;sticos, objetos de uso personal y elementos decorativos no  adosados a la edificaci&oacute;n o al mobiliario de forma fija como: figuras de cristal o m&aacute;rmol, portarretratos.<br />
&middot; L&aacute;mparas y bombillas de todas clases, cristaler&iacute;as, aparatos de visi&oacute;n y sonido, lentes.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'125',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('30','2','5','ROTURAS','Loza-Marmoles','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> la rotura, incluidos los gastos de transporte, colocaci&oacute;n y montaje de:<br />
&middot; Encimeras de m&aacute;rmol, granito u otras piedras naturales o artificiales.<br />
&middot; Elementos sanitarios: pilas, lavabos, fregaderos, inodoros, ba&ntilde;eras, platos de ducha y bid&eacute;s de cualquier material.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Simples ara&ntilde;azos, raspaduras, desconchados o deterioros superficiales. <br />
&middot; Marcos, molduras y muebles de los que formen parte. <br />
&middot; Valor de los decorados art&iacute;sticos.<br />
&middot; L&aacute;mparas y bombillas de todas clases, cristaler&iacute;as, aparatos de visi&oacute;n y sonido, lentes, objetos de uso personal y elementos decorativos no adosados a la edificaci&oacute;n o enseres del hogar de forma fija como: figuras de cristal o m&aacute;rmol, portarretratos.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'127',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('31','2','5','ROTURAS','Rotulos-Letreros','|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> la rotura de letreros y r&oacute;tulos de cristal, metacrilato u otros pl&aacute;sticos de similares caracter&iacute;sticas, que formen parte del acondicionamiento del local  hasta el l&iacute;mite del capital contratado, incluidos los gastos de transporte, colocaci&oacute;n y montaje.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Los ara&ntilde;azos, raspaduras, desconchados o deterioros superficiales.<br />
&middot; Marcos, molduras y muebles de los que formen parte.<br />
&middot; Valor de los decorados art&iacute;sticos.<br />
&middot; L&aacute;mparas, bombillas de todas clases, cristaler&iacute;as, aparatos de visi&oacute;n y sonido, lentes, objetos de uso personal.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'126',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('32','2','5','ROTURAS','Rotura Acuario','|6|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> la rotura de acuarios o peceras de cristal o cualquier otro material, siempre que su capacidad sea superior a 30 litros, incluidos los gastos de transporte, colocaci&oacute;n y montaje. <br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Simples ara&ntilde;azos, raspaduras, desconchados o deterioros superficiales. <br />
&middot; Marcos, molduras y muebles de los que formen parte. <br />
&middot; Valor de los decorados art&iacute;sticos<br />
&middot; L&aacute;mparas y bombillas de todas clases, cristaler&iacute;as, aparatos de visi&oacute;n y sonido, lentes, objetos de uso personal y elementos decorativos no adosados a la edificaci&oacute;n o enseres del hogar de forma fija como: figuras de cristal o m&aacute;rmol, portarretratos.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'175',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('3','2','1','AGUA','Aver�a sin da�os -da�os agua-','|6|',null,'<p><strong>Puede declarar siniestro con esta causa en caso de</strong> gastos de fontaner&iacute;a (hasta el l&iacute;mite indicado en la p&oacute;liza) para la localizaci&oacute;n y reparaci&oacute;n de fugas accidentales de agua u otros l�quidos, aun cuando no se hayan producido los da&ntilde;os por el derrame del agua. Cubrimos la reparaci&oacute;n y los da&ntilde;os directos ocasionados por: 
- El derrame accidental o filtraciones de agua proveniente de instalaciones fijas (incluso por omisi&oacute;n o desajuste del cierre de grifos, llaves de paso o cualquier tipo de v&aacute;lvula), o aparatos conectados a la red de agua.
- La rotura de redes de saneamiento subterr&aacute;neas, tales como fosas s&eacute;pticas, arquetas, cloacas, alcantarillados y similares.
- Los da&ntilde;os ocasionados a causa de la  rotura de acuarios y/o peceras.
- Los da&ntilde;os ocasionados por heladas.
- Los gastos necesarios de localizaci&oacute;n o reparaci&oacute;n de aver�as causantes de los da&ntilde;os, en las instalaciones fijas privativas.
No est&aacute;n cubiertos:
&middot; Los da&ntilde;os debidos a corrosi&oacute;n generalizada o desgastes notorios de las instalaciones de la edificaci&oacute;n.
&middot; Los gastos de desatasco
&middot; Los gastos de reparaci&oacute;n de aparatos o instalaciones de agua u otros l�quidos distintos a las propias tuber�as o conducciones de agua u otros l�quidos tales como: electrodom&eacute;sticos, grifer�as, o llaves de paso, aparatos sanitarios, calderas, calentadores, acumuladores, radiadores, arquetas, fosas s&eacute;pticas e instalaciones subterr&aacute;neas.
&middot; Los gastos de reparaci&oacute;n de tejados o fachadas, aunque se hayan producido da&ntilde;os por agua garantizados por la p&oacute;liza.
&middot; Gastos necesarios para corregir instalaciones defectuosas o mal dise&ntilde;adas.
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'173',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('4','2','1','AGUA','Inundaci�n-Desbordamiento','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> da&ntilde;os materiales a los bienes asegurados cuando se destruyan a consecuencia de fen&oacute;menos externos como una inundaci&oacute;n debida a desbordamientos de cauces o cursos de agua construidos por el hombre y cuya cobertura no corresponda al Consorcio de Compensaci&oacute;n de seguros.
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Da&ntilde;os a los enseres del hogar que est&eacute;n depositados al aire libre, aun cuando se hallen protegidos por materiales flexibles (lonas, pl&aacute;sticos, construcciones hinchables o similares) o contenidos en el interior de construcciones abiertas tales como terrazas, jardines, patios o porches.
&middot; Da&ntilde;os producidos por nieve, agua, arena o el polvo que entre por puertas, ventanas u otras aberturas que est&eacute;n sin cerrar o con cierre defectuoso.
&middot; Da&ntilde;os producidos por heladas, frio o hielo.
&middot; Da&ntilde;os producidos por olas o mareas, incluso cuando estos fen&oacute;menos hayan sido causados por el viento.
&middot; Da&ntilde;os producidos por desbordamiento o rotura de presas y diques de contenci&oacute;n.
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'107',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('5','2','1','AGUA','Derrame Inst.fijas Extinci�n','|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa siempre que se hayan producido</strong> da&ntilde;os materiales en la edificaci&oacute;n o enseres, nos hacenmos cargo de los gastos necesarios de localizaci&oacute;n o reparaci&oacute;n de aver&iacute;as causantes de los da&ntilde;os, en las instalaciones fijas privativas.<br />
&middot; Los da&ntilde;os materiales directos a los bienes asegurados a consecuencia de derrame accidental o filtraciones de agua proveniente de instalaciones fijas o aparatos conectados a la red de agua.<br />
&middot; Da&ntilde;os que tengan su origen en redes de saneamiento subterr&aacute;neas, tales como fosas s&eacute;pticas, arquetas, cloacas, alcantarillados y similares.<br />
&middot; Da&ntilde;os por agua que se produzcan a causa de heladas.<br />
<strong>No est&aacute;n cubiertos: </strong><br />
&middot; Da&ntilde;os debidos a corrosi&oacute;n generalizada o desgastes notorios de las instalaciones de la edificaci&oacute;n.<br />
&middot; Los gastos de desatasco.<br />
&middot; Los gastos de reparaci&oacute;n de aparatos o instalaciones de agua u otros l&iacute;quidos distintos a las propias tuber&iacute;as o conducciones de agua u otros l&iacute;quidos tales como: electrodom&eacute;sticos, grifer&iacute;as, o llaves de paso, aparatos sanitarios, calderas, calentadores, acumuladores, radiadores, arquetas, fosas s&eacute;pticas e instalaciones subterr&aacute;neas.<br />
&middot; Los gastos de reparaci&oacute;n de tejados o fachadas, aunque se hayan producido da&ntilde;os por agua garantizados por la p&oacute;liza.<br />
&middot; Gastos necesarios para corregir instalaciones defectuosas o mal dise&ntilde;adas.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'114',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('6','2','2','FEN�MENOS EXTERNOS O DE LA NATURALEZA','Lluvia','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> da&ntilde;os materiales a los bienes asegurados a consecuencia de los siguientes fen&oacute;menos externos:<br />
&middot; Lluvia, viento, pedrisco o nieve de intensidad tal que afecte a varios edificios de buena construcci&oacute;n en las proximidades al riesgo asegurado. Se incluyen los da&ntilde;os producidos por objetos arrastrados o proyectados por el viento o la lluvia.<br />
&middot; Si la cantidad de lluvia es superior a 40l/m2 y hora, o la velocidad del viento es superior a 84 Km/h., no ser&aacute; necesario el requisito que varios edificios se encuentren afectados.<br />
&middot; Inundaci&oacute;n debida a desbordamientos de cauces o cursos de agua construidos por el hombre y cuya cobertura no corresponda al Consorcio de Compensaci&oacute;n de seguros.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Da&ntilde;os a los bienes que est&eacute;n depositados al aire libre, a&uacute;n cuando se hallen protegidos por materiales flexibles (lonas, pl&aacute;sticos, construcciones hinchables o similares) o contenidos en el interior de construcciones abiertas, tales como terrazas, jardines, patios o porches.<br />
&middot; Da&ntilde;os producidos por nieve, agua, arena o el polvo que entre por puertas, ventanas u otras aberturas que est&eacute;n sin cerrar o con cierre defectuoso.<br />
&middot; Da&ntilde;os producidos por heladas, frio o hielo<br />
&middot; Da&ntilde;os producidos por olas o mareas, incluso cuando estos fen&oacute;menos hayan sido causados por el viento.<br />
&middot; Da&ntilde;os producidos por desbordamiento o rotura de presas y diques de contenci&oacute;n.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'104',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('7','2','2','FEN�MENOS EXTERNOS O DE LA NATURALEZA','Caida de Rayo','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro por</strong> los da&ntilde;os materiales que sufran los bienes asegurados  cuando se destruyan a consecuencia del impacto directo del rayo.
Adem&aacute;s quedan cubiertos, si usted lo ha contratado expresamente, los da&ntilde;os ocasionados a los veh&iacute;culos a motor, remolques, caravanas y embarcaciones de recreo cuando se encuentren estacionados dentro del garaje del riesgo asegurado en el momento de producirse el impacto directo del rayo. 
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'103',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('8','2','2','FEN�MENOS EXTERNOS O DE LA NATURALEZA','Derrame Mercancias L�quidas','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa por los</strong> da�os materiales a los bienes asegurados cuando se destruyan a consecuencia de los  fen�menos externos de pedrisco o nieve,  de intensidad tal que afecte a varios edificios<br />
&middot; Inundaci�n debida a desbordamientos de cauces o cursos de agua construidos por el hombre y cuya cobertura no corresponda al Consorcio de Compensaci�n de seguros.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Da�os a los bienes que est�n depositados al aire libre, aun cuando se hallen protegidos por materiales flexibles (lonas, pl�sticos, construcciones hinchables o similares) o contenidos en el interior de construcciones abiertas.,patios, jardines, porches o terrazas.<br />
&middot; Da�os producidos por nieve, agua, arena o el polvo que entre por puertas, ventanas u otras aberturas que est�n sin cerrar o con cierre defectuoso.<br />
&middot; Da�os producidos por heladas, frio o hielo<br />
&middot; Da�os producidos por olas o mareas, incluso cuando estos fen�menos hayan sido causados por el viento.<br />
&middot; Da�os producidos por desbordamiento o rotura de presas y diques de contenci�n<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'106',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('9','2','2','FEN�MENOS EXTERNOS O DE LA NATURALEZA','Viento','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> los da&ntildeos materiales a los bienes asegurados cuando se destruyan a consecuencia del viento de intensidad tal que afecte a varios edificios de buena construcci&oacute;n de las proximidades. Se incluyen los da&ntildeos producidos por objetos arrastrados o proyectados por el viento o la lluvia:<br />
&middot; Si la cantidad de lluvia es superior a 40l/m2 y hora, o la velocidad del viento es superior a 84 Km/h., no ser&aacute; necesario el requisito que varios edificios se encuentren afectados.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Los da&ntildeos a los bienes que est&eacute;n depositados al aire libre, aun cuando se hallen protegidos por materiales flexibles o contenidos en el interior de construcciones abiertas.<br />
&middot; Los da&ntildeos producidos por nieve, agua, arena o el polvo que entre por puertas, ventanas u otras aberturas que est&eacute;n sin cerrar o con cierre defectuoso.<br />
&middot; Los da&ntildeos producidos por heladas, frio o hielo.<br />
&middot; Los da&ntildeos producidos por olas o mareas, incluso cuando estos fen&oacute;menos hayan sido causados por el viento.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'105',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('10','2','2','FEN�MENOS EXTERNOS O DE LA NATURALEZA','Inundaci�n-Desbordamiento','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> da&ntilde;os materiales a los bienes asegurados cuando se destruyan a consecuencia de fen&oacute;menos externos como una inundaci&oacute;n debida a desbordamientos de cauces o cursos de agua construidos por el hombre y cuya cobertura no corresponda al Consorcio de Compensaci&oacute;n de seguros.
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Da&ntilde;os a los enseres del hogar que est&eacute;n depositados al aire libre, aun cuando se hallen protegidos por materiales flexibles (lonas, pl&aacute;sticos, construcciones hinchables o similares) o contenidos en el interior de construcciones abiertas tales como terrazas, jardines, patios o porches.
&middot; Da&ntilde;os producidos por nieve, agua, arena o el polvo que entre por puertas, ventanas u otras aberturas que est&eacute;n sin cerrar o con cierre defectuoso.
&middot; Da&ntilde;os producidos por heladas, frio o hielo.
&middot; Da&ntilde;os producidos por olas o mareas, incluso cuando estos fen&oacute;menos hayan sido causados por el viento.
&middot; Da&ntilde;os producidos por desbordamiento o rotura de presas y diques de contenci&oacute;n.
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'107',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('11','2','2','FEN�MENOS EXTERNOS O DE LA NATURALEZA','Choque o Impacto de Veh�culos','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> los da&ntilde;os materiales a los bienes asegurados cuando se produzca alguna de las siguientes circunstancias:<br />
&middot; Choque de veh&iacute;culos terrestres o de los bienes por ellos transportados.<br />
&middot; Ca&iacute;da de cualquier objeto procedente del exterior.<br />
&middot; Impacto de animales.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Los da&ntilde;os a los enseres  depositados al aire libre, aun cuando se hallen protegidos por materiales flexibles o contenidos en el interior de construcciones abiertas, patios, jardines, porches o terrazas.<br />
&middot; Los da&ntilde;os causados por veh&iacute;culos, animales u objetos que sean propiedad del asegurado o est&eacute;n bajo su control, de los miembros de su familia o de personas que dependande &eacute;l.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'111',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('12','2','2','FEN�MENOS EXTERNOS O DE LA NATURALEZA','Acciones Tumultuarias','|6|7|8|10|',null,'<p><strong>No est&aacute;n cubiertos: </strong><br />
Los da&ntilde;os causados por actuaciones tumultuarias producidas en el curso de reuniones y manifestaciones llevadas a cabo conforme a lo dispuesto en la Ley Org&aacute;nica 9/1983, de 15 de julio, reguladora del derecho de reuni&oacute;n, as&iacute; como durante el transcurso de huelgas legales, salvo que las citadas actuaciones pudieran ser calificadas como acontecimientos extraordinarios conforme al art&iacute;culo 1 del reglamento del seguro de riesgos extraordinarios.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'109',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('13','2','2','FEN�MENOS EXTERNOS O DE LA NATURALEZA','Ondas S�nicas','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> los da&ntilde;os materiales a los bienes asegurados cuando se destruyan a consecuencia de detonaciones s&oacute;nicas.<br />
<strong>No est&aacute;n cubiertos:<strong><br />
Los da&ntilde;os a los bienes asegurados depositados al aire libre, aun cuando se hallen protegidos por materiales flexibles (lonas, pl&aacute;sticos, construcciones hinchables o similares) o contenidos en el interior de construcci&oacute;nes abiertas, tales como terrazas, jardines, patios o porches.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'113',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('15','2','2','FEN�MENOS EXTERNOS O DE LA NATURALEZA','Corrimiento de terreno','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa</strong> los da&ntilde;os materiales en la edificaci&oacute;n, mobiliario o joyas, cuando se destruyan a consecuencia de cualquier otra causa accidental diferente de las detalladas en las garant&iacute;as que se indican en la Tabla Resumen de garant&iacute;as y capitales asegurados.
<strong>No est&aacute; cubierto: </strong><br />
 Hundimiento y corrimiento de tierras, Desprendimiento de rocas y aludes, salvo que est&eacute; contratada la garant&iacute;a Todo Riesgo. 
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong>',to_date('29/11/16','DD/MM/RR'),'178',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('8','1','60','FEN�MENOS ATMOSF�RICOS-TERRESTRES','Pedrisco-Nieve','|0|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Da&ntilde;os materiales a los bienes asegurados cuando se destruyan a consecuencia de los fen&oacute;menos externos de pedrisco o nieve, de intensidad tal que afecte a varios edificios de buena construcci&oacute;n en las proximidades de la vivienda asegurada. Se incluyen los da&ntilde;os producidos por objetos arrastrados o proyectados por el viento o la lluvia.<br />
&middot; Si la cantidad de lluvia es superior a 40l/m2 y hora, o la velocidad del viento es superior a 84 Km/h., no ser&aacute; necesario el requisito que varios edificios se encuentren afectados.<br />
&middot; Inundaci&oacute;n debida a desbordamientos de cauces o cursos de agua construidos por el hombre y cuya cobertura no corresponda al Consorcio de Compensaci&oacute;n de seguros.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Da&ntilde;os a los enseres del hogar que est&eacute;n depositados al aire libre, aun cuando se hallen protegidos por materiales flexibles (lonas, pl&aacute;sticos, construcciones hinchables o similares) o contenidos en el interior de construcciones abiertas.<br />
&middot; Da&ntilde;os producidos por nieve, agua, arena o el polvo que entre por puertas, ventanas u otras aberturas que est&eacute;n sin cerrar o con cierre defectuoso.<br />
&middot; Da&ntilde;os producidos por heladas, frio o hielo<br />
&middot; Da&ntilde;os producidos por olas o mareas, incluso cuando estos fen&oacute;menos hayan sido causados por el viento.<br />
&middot; Da&ntilde;os producidos por desbordamiento o rotura de presas y diques de contenci&oacute;n<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'106','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('10','1','60','FEN�MENOS ATMOSF�RICOS-TERRESTRES','Inundaci�n-Desbordamiento','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Da&ntilde;os materiales a los bienes asegurados cuando se destruyan a consecuencia de fen&oacute;menos externos como la inundaci&oacute;n debida a desbordamientos de cauces o cursos de agua construidos por el hombre y cuya cobertura no corresponda al Consorcio de Compensaci&oacute;n de seguros.<br />
<strong>Qu&eacute; no est&aacute;n cubiertos:</strong><br />
&middot; Da&ntilde;os a los enseres del hogar que est&eacute;n depositados al aire libre, aun cuando se hallen protegidos por materiales flexibles (lonas, pl&aacute;sticos, construcciones hinchables o similares) o contenidos en el interior de construcciones abiertas.<br />
&middot; Da&ntilde;os producidos por nieve, agua, arena o el polvo que entre por puertas, ventanas u otras aberturas que est&eacute;n sin cerrar o con cierre defectuoso.<br />
&middot; Da&ntilde;os producidos por heladas, frio o hielo<br />
&middot; Da&ntilde;os producidos por olas o mareas, incluso cuando estos fen&oacute;menos hayan sido causados por el viento.<br />
&middot; Da&ntilde;os producidos por desbordamiento o rotura de presas y diques de contenci&oacute;n.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'107','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('11','1','2','FEN�MENOS EXTERNOS','Choque o Impacto de Veh�culos','|0|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os materiales a los bienes asegurados cuando se produzca alguna de las siguientes circunstancias:<br />
&middot; Choque de veh&iacute;culos terrestres o de los bienes por ellos transportados.<br />
&middot; Ca&iacute;da de cualquier objeto procedente del exterior, siempre que no sean de su propiedad.<br />
&middot; Impacto de animales, siempre que no sean de su propiedad.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Los da&ntilde;os a los enseres del hogar depositados al aire libre, aun cuando se hallen protegidos por materiales flexibles o contenidos en el interior de construcciones abiertas.<br />
&middot; Los da&ntilde;os causados por veh&iacute;culos, animales u objetos que sean de su propiedad o est&eacute;n bajo su control o de los miembros de su familia o de personas que dependan o convivan con el Tomador o Asegurado.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'111','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('12','1','4','ATRACO-ROBO-OTROS HECHOS DELICTIVOS','Acciones Tumultuarias','|6|7|8|10|',null,'<p><strong>No est&aacute;n cubiertos: </strong><br />
Los da&ntilde;os causados por actuaciones tumultuarias producidas en el curso de reuniones y manifestaciones llevadas a cabo conforme a lo dispuesto en la Ley Org&aacute;nica 9/1983, de 15 de julio, reguladora del derecho de reuni&oacute;n, as&iacute; como durante el transcurso de huelgas legales, salvo que las citadas actuaciones pudieran ser calificadas como acontecimientos extraordinarios conforme al art&iacute;culo 1 del reglamento del seguro de riesgos extraordinarios.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'109','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('13','1','60','FEN�MENOS ATMOSF�RICOS-TERRESTRES','Ondas S�nicas','|6|7|8|10|',null,'<p><strong>Impacto de objetos y Detonaciones s&oacute;nicas (Comunidades)<br />
  Qu&eacute; est&aacute; cubierto:</strong><br />
La acci&oacute;n directa de las ondas s&oacute;nicas producidas por aparatos a&eacute;reos o espaciales cuando franqueen la barrera del sonido.</p>

<p><strong>Detonaciones s&oacute;nicas (Comercio y Hogar)</strong><br />
  <strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os materiales a los bienes asegurados cuando se destruyan a consecuencia de detonaciones s&oacute;nicas.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
Los da&ntilde;os a los bienes asegurados depositados al aire libre, aun cuando se hallen protegidos por materiales flexibles (lonas, pl&aacute;sticos, construcciones hinchables o similares) o contenidos en el interior de construcciones abiertas.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'113','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('14','1','64','OTROS RIESGOS ACCIDENTALES','Otros Riesgos Accidentales','|6|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os materiales en la edificaci&oacute;n, mobiliario o joyas, cuando se destruyan a consecuencia de cualquier otra causa accidental diferente de las detalladas en las garant&iacute;as.<br />
Convenciones especiales para esta garant&iacute;a<br />
&middot; Accidente es un hecho que se produce de forma s&uacute;bita y espont&aacute;nea por causa ajena a la voluntad del asegurado como tal.<br />
&middot; La garant&iacute;a Todo Riesgo no tiene vigor alguno sobre los objetos de valor art&iacute;stico. Dichos objetos s&oacute;lo podr&aacute;n tener cobertura si se contrata la garant&iacute;a Todo riesgo arte.<br />
&middot; Esta garant&iacute;a cubre especialmente las siguientes circunstancias: Asentamiento, hundimiento, desprendimiento, corrimiento o ablandamiento del terreno.<br />
&middot; Se extiende la garant&iacute;a a bienes que no siendo de su propiedad o de alg&uacute;n miembro de su familia, est&aacute;n bajo su cuidado o tiene en dep&oacute;sito, si se produce alg&uacute;n suceso cubierto en la p&oacute;liza.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Ara&ntilde;azos, raspaduras, desconchones, rayados y en general cualquier deterioro superficial de los bienes asegurados, salvo que se deriven de otros da&ntilde;os de mayor entidad amparados por el contrato.<br />
&middot; Aver&iacute;as de tipo mec&aacute;nico, el&eacute;ctrico o electr&oacute;nico.<br />
&middot; Da&ntilde;os derivados de cualquier clase de contaminaci&oacute;n.<br />
&middot; Da&ntilde;os producidos por termitas, gusanos, polillas o cualquier plaga de insectos.<br />
&middot; Expropiaci&oacute;n, confiscaci&oacute;n, requisa o da&ntilde;os en los bienes por imperativo de cualquier gobierno o autoridad, de hecho o de derecho.</p>

<p>Los beneficios o prestaciones, l&iacute;mites y exclusiones correspondientes a las garant&iacute;as descritas en la Tabla Resumen, ser&aacute;n de total aplicaci&oacute;n en los supuestos previstos en ellas. La garant&iacute;a Todo Riesgo no podr&aacute; ser invocada para modificar dichas garant&iacute;as, sus l&iacute;mites o exclusiones.</p>

<p><strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'145','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('15','1','60','FEN�MENOS ATMOSF�RICOS-TERRESTRES','Corrimiento de terreno','|6|7|8|10|',null,'<p><strong>Cu&aacute;ndo est&aacute; cubierto:</strong><br />
Dentro de la garant&iacute;a de Todo Riesgo se cubren especialmente las siguientes circunstancias: Asentamiento, hundimiento, desprendimiento, corrimiento o ablandamiento del terreno.<br />
<strong>No est&aacute; cubierto: </strong><br />
Hundimiento y corrimiento de tierras, desprendimiento de rocas y aludes, salvo que est&eacute; contratada la garant&iacute;a Todo Riesgo<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'178','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('16','1','2','FEN�MENOS EXTERNOS','Actos de Vandalismo','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os materiales a los bienes asegurados cuando se produzcan actos de vandalismo o malintencionados cometidos individual o colectivamente por otras personas.<br />
<strong>No est&aacute;n cubiertos :</strong><br />
&middot; Los da&ntilde;os causados por los inquilinos o por otros ocupantes de la vivienda.<br />
&middot; Las pintadas, rayadas, inscripciones y pegado de carteles.<br />
&middot; Los actos de vandalismo que no se hayan denunciado ante la autoridad competente.<br />
&middot; La rotura de cristales o materiales sustitutivos del cristal, lunas espejos, m&aacute;rmoles y elementos de loza sanitaria salvo cuando est&eacute; contratada la garant&iacute;a de roturas.<br />
&middot; Los da&ntilde;os producidos por robo y expoliaci&oacute;n, salvo cuando est&eacute; contratada la garant&iacute;a de robo.<br />
. Los actos de vandalismo cuando los bienes asegurados no se encuentren en la vivienda asegurada<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'108','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('30','1','5','ROTURAS','Rotura de loza y marmoles','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
La rotura, incluidos los gastos de transporte, colocaci&oacute;n y montaje de:<br />
&middot; Encimeras de m&aacute;rmol, granito u otras piedras naturales o artificiales.<br />
&middot; Elementos sanitarios: pilas, lavabos, fregaderos, inodoros, ba&ntilde;eras, platos de ducha y bid&eacute;s de cualquier material.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Simples ara&ntilde;azos, raspaduras, desconchados o deterioros superficiales. <br />
&middot; Marcos, molduras y muebles de los que formen parte. <br />
&middot; Valor de los decorados art&iacute;sticos.<br />
&middot; L&aacute;mparas y bombillas de todas clases, cristaler&iacute;as, aparatos de visi&oacute;n y sonido, lentes, objetos de uso personal y elementos decorativos no adosados a la edificaci&oacute;n o enseres del hogar de forma fija como: figuras de cristal o m&aacute;rmol, portarretratos.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'127','						Recuerda abrir tantos siniestros como roturas existan ,siempre que estas no sean producidas por el mismo origen.
																																																															 
												 
												 
												 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('31','1','5','ROTURAS','Rotura de r�tulos o letreros','|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
La rotura de letreros y r&oacute;tulos de cristal, metacrilato u otros pl&aacute;sticos de similares caracter&iacute;sticas, que formen parte del acondicionamiento del local hasta el l&iacute;mite del capital contratado, incluidos los gastos de transporte, colocaci&oacute;n y montaje.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Los ara&ntilde;azos, raspaduras, desconchados o deterioros superficiales.<br />
&middot; Marcos, molduras y muebles de los que formen parte.<br />
&middot; Valor de los decorados art&iacute;sticos.<br />
&middot; L&aacute;mparas, bombillas de todas clases, cristaler&iacute;as, aparatos de visi&oacute;n y sonido, lentes, objetos de uso personal.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'126','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('33','1','5','ROTURAS','Rotura Metacrilato','|6|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
La rotura de muebles, mamparas o estanter&iacute;as de cristal, metacrilato u otros pl&aacute;sticos de similares, incluidos los gastos de transporte, colocaci&oacute;n y montaje.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Simples ara&ntilde;azos, raspaduras, desconchados o deterioros superficiales. <br />
&middot; Marcos, molduras y muebles de los que formen parte. <br />
&middot; Valor de los decorados art&iacute;sticos.<br />
&middot; L&aacute;mparas y bombillas de todas clases, cristaler&iacute;as, aparatos de visi&oacute;n y sonido, lentes, objetos de uso personal y elementos decorativos no adosados a la edificaci&oacute;n o enseres del hogar de forma fija como: figuras de cristal o m&aacute;rmol, portarretratos.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'174','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('17','1','60','FEN�MENOS ATMOSF�RICOS-TERRESTRES','Caida Arboles-Antenas-Farolas','|0|',null,'<p><strong>Qu&eacute; est&aacute; cubierto</strong>:<br />
Los gastos de limpieza y saneamiento, as&iacute; como los de reemplazo por otros de la misma especie, cuando los &aacute;rboles y arbustos de su parcela sufran da&ntilde;os por:<br />
&middot; Incendio, explosi&oacute;n y ca&iacute;da de un rayo.<br />
&middot; Los efectos del viento, ya sea por su intensidad como por la acci&oacute;n de objetos arrastrados por &eacute;l.<br />
&middot; Asentamientos, hundimientos, desprendimientos, corrimientos o ablandamientos del terreno, por causas accidentales.<br />
&middot; Choque de veh&iacute;culos terrestres, o de los bienes por ellos transportados siempre que no sean de su propiedad.<br />
&middot; Ca&iacute;da de cualquier objeto procedente del exterior, siempre que no sean de su propiedad.<br />
&middot; Ondas s&oacute;nicas.<br />
&middot; Actos vand&aacute;licos.<br />
<strong>No est&aacute;n cubiertos</strong>:<br />
&middot; Los da&ntilde;os producidos o agravados por falta de mantenimiento.<br />
&middot; Los da&ntilde;os producidos por plagas y/o enfermedades.<br />
&middot; Las plantaciones que no est&eacute;n radicadas en el propio terreno de la parcela, por ejemplo en macetas y jardineras.<br />
&middot; Las plantaciones efectuadas con alg&uacute;n fin comercial.<br />
&middot; Las citadas por el ep&iacute;grafe de exclusiones de car&aacute;cter general que no hayan sido espec&iacute;ficamente incluidas en la cobertura arriba descrita.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'182','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('34','1','5','ROTURAS','Rotura placas solares','|6|7|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
La rotura de cristal de placa solar, incluidos los gastos de transporte, colocaci&oacute;n y montaje.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Simples ara&ntilde;azos, raspaduras, desconchados o deterioros superficiales. <br />
&middot; Marcos, molduras y muebles de los que formen parte. <br />
&middot; Valor de los decorados art&iacute;sticos<br />
&middot; L&aacute;mparas y bombillas de todas clases, cristaler&iacute;as, aparatos de visi&oacute;n y sonido, lentes, objetos de uso personal y elementos decorativos no adosados a la edificaci&oacute;n o enseres del hogar de forma fija como: figuras de cristal o m&aacute;rmol, portarretratos.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'169','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('36','1','61','CHOQUE O IMPACTO DE VEH�CULOS','Choque o Impacto de Veh�culos','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os materiales a los bienes asegurados cuando se produzca alguna de las siguientes circunstancias:<br />
&middot; Choque de veh&iacute;culos terrestres o de los bienes por ellos transportados.<br />
&middot; Ca&iacute;da de cualquier objeto procedente del exterior, siempre que no sean de su propiedad.<br />
&middot; Impacto de animales, siempre que no sean de su propiedad.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Los da&ntilde;os a los enseres del hogar depositados al aire libre, aun cuando se hallen protegidos por materiales flexibles o contenidos en el interior de construcciones abiertas.<br />
&middot; Los da&ntilde;os causados por veh&iacute;culos, animales u objetos que sean de su propiedad o est&eacute;n bajo su control o de los miembros de su familia o de personas que dependan o convivan con el Tomador o Asegurado.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'111','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('37','1','60','FEN�MENOS ATMOSF�RICOS-TERRESTRES','Caida Aeronaves y/o Astronaves','|0|',null,'<p>Qu&eacute; est&aacute; cubierto:<br />
El choque o ca&iacute;da de un aparato a&eacute;reo o espacial o de objetos que caigan de los mismos, siempre y cuando no sean de su propiedad ni de una persona de la que Usted sea civilmente responsable.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'112','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('38','1','6','CHOQUES - CA�DAS','Caida Arboles-Antenas-Farolas','|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los gastos de limpieza y saneamiento, as&iacute; como los de reemplazo por otros de la misma especie, cuando los &aacute;rboles y arbustos de su parcela sufran da&ntilde;os por:<br />
&middot; Incendio, explosi&oacute;n y ca&iacute;da de un rayo.<br />
&middot; Los efectos del viento, ya sea por su intensidad como por la acci&oacute;n de objetos arrastrados por &eacute;l.<br />
&middot; Asentamientos, hundimientos, desprendimientos, corrimientos o ablandamientos del terreno, por causas accidentales.<br />
&middot; Choque de veh&iacute;culos terrestres, o de los bienes por ellos transportados siempre que no sean de su propiedad.<br />
&middot; Ca&iacute;da de cualquier objeto procedente del exterior, siempre que no sean de su propiedad.<br />
&middot; Ondas s&oacute;nicas.<br />
&middot; Actos vand&aacute;licos.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Los da&ntilde;os producidos o agravados por falta de mantenimiento.<br />
&middot; Los da&ntilde;os producidos por plagas y/o enfermedades.<br />
&middot; Las plantaciones que no est&eacute;n radicadas en el propio terreno de la parcela, por ejemplo en macetas y jardineras.<br />
&middot; Las plantaciones efectuadas con alg&uacute;n fin comercial.<br />
&middot; Las citadas por el ep&iacute;grafe de exclusiones de car&aacute;cter general que no hayan sido espec&iacute;ficamente incluidas en la cobertura arriba descrita.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'182','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('32','1','5','ROTURAS','Rotura Acuario','|6|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
La rotura de acuarios o peceras de cristal o cualquier otro material, siempre que su capacidad sea superior a 30 litros, incluidos los gastos de transporte, colocaci&oacute;n y montaje. <br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Simples ara&ntilde;azos, raspaduras, desconchados o deterioros superficiales. <br />
&middot; Marcos, molduras y muebles de los que formen parte. <br />
&middot; Valor de los decorados art&iacute;sticos<br />
&middot; L&aacute;mparas y bombillas de todas clases, cristaler&iacute;as, aparatos de visi&oacute;n y sonido, lentes, objetos de uso personal y elementos decorativos no adosados a la edificaci&oacute;n o enseres del hogar de forma fija como: figuras de cristal o m&aacute;rmol, portarretratos.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'175','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('47','1','9','INCENDIO','Humo','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os materiales a los bienes asegurados cuando se produzca un escape repentino en conducciones de extracci&oacute;n de humo (chimeneas, extractores, etc) tanto si se han originado en el interior de la vivienda como en el exterior de la misma.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Los da&ntilde;os causados por la acci&oacute;n continuada del humo.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'110','																																																								Recuerda que los da�os por  humo derivados de un incendio se gestionan por la causa Incendio. 			 
												 
												 
												 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('49','1','10','COPARTICIPACI�N COMUNIDAD','Coparticipaci�n Comunidad','|6|8|10|',null,'<p>La coparticipaci&oacute;n es el porcentaje en el que el asegurado participa en copropiedad junto a otras Comunidades en el uso y disfrute de instalaciones comunes, pertenecientes a dichas Comunidades.<br />
Este porcentaje de coparticipaci&oacute;n formar&aacute; parte del capital asegurado para los diferentes tipos de siniestros.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'130','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('50','1','11','EMPLEADOS - TARJETAS','Infidelidad de Empleados','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
&middot; El robo y expoliaci&oacute;n producido con fuerza en las cosas para acceder a ellas o con violencia o intimidaci&oacute;n a las personas, y que afecte a: La infidelidad de empleados.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'121','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('51','1','11','EMPLEADOS - TARJETAS','Uso fraudulento de tarjetas','|6|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Dentro de la garant&iacute;a de Robo y Expoliaci&oacute;n de la vivienda, AXA cubre el uso fraudulento de tarjetas de cr&eacute;dito, hasta el l&iacute;mite incluido en p&oacute;liza. <br />
<strong>Que no est&aacute; cubierto:</strong><br />
&middot; El hurto de dinero en efectivo.<br />
. El robo o hurto que afecte a enseres que se encuentren en dependencias que no sean de su uso exclusivo.<br />
&middot; P&eacute;rdidas o extrav&iacute;os<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'180','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('52','1','12','ACCIDENTES','Accidentes personales','|6|7|8|10|',null,'<p><b>Qu&eacute; est&aacute; cubierto:</b><br />
Si el asegurado o cualquier miembro de su familia sufre un accidente en la vivienda asegurada, AXA se har&aacute; cargo de las siguientes prestaciones:<br />
a) Gastos de curaci&oacute;n<br />
Gastos m&eacute;dicos y farmac&eacute;uticos derivados de las lesiones personales que pueda sufrir el asegurado o cualquier miembro de su familia:<br />
&middot; Sin l&iacute;mite econ&oacute;mico en los centros concertados con AXA y durante un periodo m&aacute;ximo de 3 a&ntilde;os, siguientes a la fecha de ocurrencia del siniestro.<br />
b) Indemnizaci&oacute;n para el caso de fallecimiento<br />
AXA pagar&aacute; los beneficiarios la suma asegurada indicada en la Tabla Resumen del Condicionado General de la p&oacute;liza.<br />
c) Indemnizaci&oacute;n para caso de invalidez permanente <br />
d) Anticipo de capital en caso de fallecimiento para atender a los gastos derivados del fallecimiento del Asegurado en caso de accidente.<br />
e) Prestaci&oacute;n extraordinaria para menores de edad <br />
f) Asesoramiento v&iacute;a telef&oacute;nica con un m&eacute;dico las 24 h. del d&iacute;a los 365 d&iacute;as del a&ntilde;o<br />
g) Los gastos de asistencia psicol&oacute;gica del asegurado para superar el stress post traum&aacute;tico sufrido como consecuencia del accidente.<br />
El m&aacute;ximo de siniestros por anualidad de seguro para esta cobertura ser&aacute; de 5.<br />
<b>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</b><br />
</p>',to_date('30/11/21','DD/MM/RR'),'134','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('53','1','12','ACCIDENTES','Accidentes domesticos o por calor','|6|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os causados en la edificaci&oacute;n y/o enseres asegurados por la acci&oacute;n s&uacute;bita del calor o del contacto directo del fuego o de una sustancia incandescente aun cuando no se produzca incendio<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Da&ntilde;os causados por &quot;accidente de fumador&quot;<br />
&middot; Joyas y objetos de valor art&iacute;stico.<br />
&middot; Gafas y art&iacute;culos &oacute;pticos en general, incluso a&eacute;reos o n&aacute;uticos.<br />
&middot; Aparatos electr&oacute;nicos.<br />
&middot; Da&ntilde;os causados por la acci&oacute;n progresiva de la temperatura y de las diferentes condiciones atmosf&eacute;ricas.<br />
&middot; Fallos en los dispositivos de regulaci&oacute;n<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'148','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('54','1','13','TRASLADO POR DECISI�N DE LA AUTORIDAD','Traslado por decisi�n de la autoridad','|6|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
AXA se hace cargo de los gastos derivados de inhabitabilidad a consecuencia de una orden administrativa o judicial y siempre que esta situaci&oacute;n no se deba a un expediente administrativo de declaraci&oacute;n de ruina. Abona un alojamiento provisional similar si el asegurado no puede hacer uso de su vivienda a consecuencia del siniestro cubierto por la p&oacute;liza y los gastos de traslado temporal de mobiliario y objetos personales del asegurado: hotel, mudanza, guardamuebles, con los l&iacute;mites que se detallan en la p&oacute;liza.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'176','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('55','1','14','RESPONSABILIDAD CIVIL','Responsabilidad civil','|6|7|8|10|',null,'<p>El &aacute;mbito geogr&aacute;fico de cobertura, es de aplicaci&oacute;n en todo el mundo a excepci&oacute;n de Estados Unidos de Am&eacute;rica y Canad&aacute;.<br />
  <strong>Qu&eacute; est&aacute; cubierto:<br />
Responsabilidad civil como propietario del inmueble</strong><br />
Si el asegurado es el propietario de la edificaci&oacute;n asegurada y por esta causa el cliente o los miembros de su familia fueran civilmente responsables, AXA cubre la obligaci&oacute;n de indemnizar los da&ntilde;os y perjuicios causados a terceros.<br />
<strong>Responsabilidad civil familiar</strong><br />
AXA cubre la obligaci&oacute;n de indemnizar los da&ntilde;os y perjuicios causados a terceros, cuando el asegurado o los miembros de su familia sean civilmente responsables en el &aacute;mbito de su vida familiar privada.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
Las reclamaciones derivadas de:<br />
&middot; El uso, tenencia, transporte o almacenamiento de armas y/o explosivos de cualquier clase.<br />
&middot; Da&ntilde;os a bienes de terceros que est&eacute;n en su poder.<br />
&middot; Obligaciones contractuales.<br />
&middot; Responsabilidades profesionales.<br />
&middot; Da&ntilde;os que deban ser objeto de cobertura por un seguro obligatorio; quedar&aacute; tambi&eacute;n excluido el exceso de lo legal.<br />
&middot; Incumplimiento de disposiciones oficiales. En ning&uacute;n caso la Entidad Aseguradora se hace cargo de multas o sanciones ni de las consecuencias de su impago.<br />
&middot; Perjuicios no consecutivos, entendi&eacute;ndose por tales, las p&eacute;rdidas econ&oacute;micas que no sean consecuencia directa de un da&ntilde;o personal o material, as&iacute; como aquellas p&eacute;rdidas econ&oacute;micas que sean consecuencia de un da&ntilde;o personal o material no amparado por la p&oacute;liza.<br />
&middot; Da&ntilde;os que tengan su origen en la pr&aacute;ctica deportiva, cuando el asegurado o los miembros de su familia dispongan de ficha federativa.<br />
&middot; El uso y circulaci&oacute;n de veh&iacute;culos a motor, y/o de los elementos remolcados o incorporados a los mismos.<br />
&middot; Derivadas de la contaminaci&oacute;n del suelo, las aguas o la atm&oacute;sfera.<br />
&middot; Reclamaciones que el propietario-arrendador haga al inquilino-asegurado, diferentes de las derivadas de incendio, explosi&oacute;n y da&ntilde;os por agua<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&neas generales de contrataci�n, para el siniestro en concreto se aplicar�n las condiciones generales y particulares de la p�liza contratada por el asegurado.</strong>',to_date('30/11/21','DD/MM/RR'),'122','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('56','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Reclamaci�n Protecci�n Jur�dica','|6|7|8|10|',null,'<p>AXA se har&aacute; cargo de la reclamaci&oacute;n de da&ntilde;os y/o perjuicios que otras personas que no teniendo ning&uacute;n contrato con el asegurado, le hayan causado, a la Edificaci&oacute;n y/o Enseres asegurados y a su persona, expresamente reclamaci&oacute;n de da&ntilde;os corporales en caso de conducci&oacute;n de bicicletas, atropello y ca&iacute;da accidental atribuible a un tercero.<br />
&middot; Reclamaci&oacute;n contractual por obras en el inmueble: AXA se har&aacute; cargo de la reclamaci&oacute;n derivada de incumplimientos de contratos de prestaci&oacute;n de servicios de reparaci&oacute;n, mantenimiento o reforma que hayan suscrito en relaci&oacute;n con la Edificaci&oacute;n y/o enseres asegurados, siempre que se haya abonado la factura y salvo que se trate de contratos de suministro de agua, luz, gas, tel&eacute;fono o Internet.<br />
&middot; Reclamaci&oacute;n contractual por cosas muebles: AXA se har&aacute; cargo de la reclamaci&oacute;n derivada de incumplimientos del vendedor, en contratos de compraventa que afecten a los Enseres asegurados.<br />
&middot; Reclamaciones por riesgos extraordinarios: AXA gestionar&aacute; la reclamaci&oacute;n en caso de incumplimiento por parte del Consorcio de Compensaci&oacute;n de Seguros que impida que el asegurado pueda hacer efectivos los derechos que se derivan de la cl&aacute;usula de cobertura de riesgos extraordinarios que se incluye en la p&oacute;liza.<br />
. Reclamaciones frente a otras aseguradoras: En caso de incumplimiento de otra Aseguradora por p&oacute;lizas de seguro en vigor en relaci&oacute;n con la vivienda asegurada, contratadas por el asegurado, o de las que cliente fuera beneficiario, AXA realizar&aacute; la reclamaci&oacute;n para hacer valer sus derechos.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'133','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('18','2','3','AVER�AS  - MERCANC�AS - DERRAMES','Aver�a sin da�os -da�os agua-','|6|',null,'<p><strong>Puede declarar siniestro con esta causa en caso de</strong> gastos de fontaner&iacute;a (hasta el l&iacute;mite indicado en la p&oacute;liza) para la localizaci&oacute;n y reparaci&oacute;n de fugas accidentales de agua u otros l�quidos, aun cuando no se hayan producido los da&ntilde;os por el derrame del agua. Cubrimos la reparaci&oacute;n y los da&ntilde;os directos ocasionados por: 
- El derrame accidental o filtraciones de agua proveniente de instalaciones fijas (incluso por omisi&oacute;n o desajuste del cierre de grifos, llaves de paso o cualquier tipo de v&aacute;lvula), o aparatos conectados a la red de agua.
- La rotura de redes de saneamiento subterr&aacute;neas, tales como fosas s&eacute;pticas, arquetas, cloacas, alcantarillados y similares.
- Los da&ntilde;os ocasionados a causa de la  rotura de acuarios y/o peceras.
- Los da&ntilde;os ocasionados por heladas.
- Los gastos necesarios de localizaci&oacute;n o reparaci&oacute;n de aver�as causantes de los da&ntilde;os, en las instalaciones fijas privativas.
No est&aacute;n cubiertos:
&middot; Los da&ntilde;os debidos a corrosi&oacute;n generalizada o desgastes notorios de las instalaciones de la edificaci&oacute;n.
&middot; Los gastos de desatasco
&middot; Los gastos de reparaci&oacute;n de aparatos o instalaciones de agua u otros l�quidos distintos a las propias tuber�as o conducciones de agua u otros l�quidos tales como: electrodom&eacute;sticos, grifer�as, o llaves de paso, aparatos sanitarios, calderas, calentadores, acumuladores, radiadores, arquetas, fosas s&eacute;pticas e instalaciones subterr&aacute;neas.
&middot; Los gastos de reparaci&oacute;n de tejados o fachadas, aunque se hayan producido da&ntilde;os por agua garantizados por la p&oacute;liza.
&middot; Gastos necesarios para corregir instalaciones defectuosas o mal dise&ntilde;adas.
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'173',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('19','2','3','AVER�AS  - MERCANC�AS - DERRAMES','Aver�a Maquinaria-EquipoElect.','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta casusa  por</strong> los da&ntilde;os materiales directos hasta el l&iacute;mite indicado en la p&oacute;liza, que sufra la maquinaria, ordenadores y/o equipos electr&oacute;nicos como consecuencia de una causa accidental diferente al resto de las coberturas del contrato.<br />
AXA cubre los bienes asegurados desde el momento en que finalizado el montaje,las pruebas  operacionales, est&aacute;n preparados para comenzar la explotaci&oacute;n normal, permaneciendo cubiertos tanto en funcionamiento como parados, durante su desmontaje y montaje subsiguiente con objeto de proceder a su limpieza, revisi&oacute;n o mantenimiento.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; No se podr&aacute;  invocar esta cobertura como complemento a las prestaciones de dichas coberturas, ni como sustituci&oacute;n de sus l&iacute;mites o exclusiones.<br />
&middot; Los da&ntilde;os debidos al uso o desgaste normal o paulatino, as&iacute; como los sufridos por parte de las mquinas y equipos que necesiten por su propio funcionamiento un reemplazo frecuente y los producidos por erosi&oacute;n, corrosi&oacute;n, oxidaci&oacute;n, cavitaci&oacute;n, herrumbre o incrustaciones.<br />
&middot; Los da&ntilde;os sufridos por las m&aacute;quinas y equipos de antig�edad superior a 7 a&ntilde;os.<br />
&middot; Los simples da&ntilde;os y defectos est&eacute;ticos, los que afectan a los elementos que deben ser renovados frecuentemente, los lubricantes y refrigerantes y los defectos y/o vicios ya existentes al contratar el seguro.<br />
&middot; Los da&ntilde;os por exposici&oacute;n de la maquinaria, ordenadores y/o equipos a condiciones anormales o sobrecargas intencionadas, o durante experimentos, ensayos o pruebas en los que se exijan esfuerzos superiores al normal y los causados por fallos o interrupciones en el aprovisionamiento de la energ&iacute;a avisados con antelaci&oacute;n.<br />
&middot; Los da&ntilde;os o p&eacute;rdidas de los que sea legal o contractualmente responsable el fabricante o proveedor de las maquinas y/o equipos.<br />
&middot; Los perjuicios y p&eacute;rdidas indirectas de cualquier clase.<br />
&middot; Las ca&iacute;das de equipos y elementos port&aacute;tiles.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.&#8195;</strong></p>',to_date('29/11/16','DD/MM/RR'),'123',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('20','2','3','AVER�AS  - MERCANC�AS - DERRAMES','Derrame Mercancias L�quidas','|8|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> los da&ntilde;os y o p&eacute;rdidas de las mercanc&iacute;as l&iacute;quida, hasta el l&iacute;mite indicado en p&oacute;liza, a consecuencia de: destrucci&oacute;n, rotura, revent&oacute;n o agrietamiento de car&aacute;cter accidental de los dep&oacute;sitos que las contienen.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Los defectos de construcci&oacute;n fabricaci&oacute;n o instalaci&oacute;n de los dep&oacute;sitos, as&iacute; como los debidos a vetustez, desgaste, oxidaci&oacute;n o corrosi&oacute;n de los mismos.<br />
&middot; Las p&eacute;rdidas durante su trasvase o llenado; as&iacute; como los debidos a fallos en los aparatos y l&iacute;neas de conducci&oacute;n, llenado o trasvase.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'129',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('21','2','3','AVER�AS  - MERCANC�AS - DERRAMES','Da�os Mercancia Transportada','|8|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> el choque de un veh&iacute;culo terrestre identificado o de las mercanc&iacute;as por el mismo transportadas, cuyo conductor o propietario no sea el asegurado, ni ning&uacute;n copropietario y/o inquilino, ni una persona que sea civilmente responsable de ellos.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'124',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('18','1','1','DA�OS AGUA-OTROS L�QUIDOS','Aver�a sin da�os -da�os agua-','|6|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Hasta el l&iacute;mite indicado en la p&oacute;liza los gastos de fontaner&iacute;a necesarios para la localizaci&oacute;n y reparaci&oacute;n de fugas accidentales de agua u otros l&iacute;quidos, aun cuando no se hayan producido los da&ntilde;os por: <br />
- Ser directos a los bienes asegurados a consecuencia de derrame accidental o filtraciones de agua proveniente de instalaciones fijas (incluso por omisi&oacute;n o desajuste del cierre de grifos, llaves de paso o cualquier tipo de v&aacute;lvula), o aparatos conectados a la red de agua.<br />
- Tener su origen en redes de saneamiento subterr&aacute;neas, tales como fosas s&eacute;pticas, arquetas, cloacas, alcantarillados y similares.<br />
- Tener su origen en acuarios y/o peceras.<br />
- Ser producidos a causa de heladas.<br />
- Los gastos necesarios de localizaci&oacute;n o reparaci&oacute;n de aver&iacute;as causantes de los da&ntilde;os, en las instalaciones fijas privativas.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Da&ntilde;os debidos a corrosi&oacute;n generalizada o desgastes notorios de las instalaciones de la edificaci&oacute;n.<br />
&middot; Los gastos de desatasco<br />
&middot; Los gastos de reparaci&oacute;n de aparatos o instalaciones de agua u otros l&iacute;quidos distintos a las propias tuber&iacute;as o conducciones de agua u otros l&iacute;quidos tales como: electrodom&eacute;sticos, grifer&iacute;as, o llaves de paso, aparatos sanitarios, calderas, calentadores, acumuladores, radiadores, arquetas, fosas s&eacute;pticas e instalaciones subterr&aacute;neas.<br />
&middot; Los gastos de reparaci&oacute;n de tejados o fachadas, aunque se hayan producido da&ntilde;os por agua garantizados por la p&oacute;liza.<br />
&middot; Gastos necesarios para corregir instalaciones defectuosas o mal dise&ntilde;adas.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'173','        Recuerda que si se producen da�os la causa correcta de apertura es Da�os agua. Adem�s te informamos que esta garant�a tiene limite si no se ocasionan da�os.
																																														 
												 
												 
												 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('19','1','57','AVER�A DE MAQUINARIA','Averia de maquinaria o Equipos electr�nicos','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os materiales directos a primer riesgo hasta el l&iacute;mite indicado en la p&oacute;liza, que sufra la maquinaria, ordenadores y/o equipos electr&oacute;nicos durante su normal utilizaci&oacute;n, como consecuencia de una causa accidental diferente al resto de las coberturas del contrato.<br />
AXA cubre los bienes asegurados desde el momento en que finalizado el montaje y realizadas las pruebas operacionales, est&aacute;n preparados para comenzar la explotaci&oacute;n normal, permaneciendo cubiertos tanto en funcionamiento como parados, durante su desmontaje y montaje subsiguiente con objeto de proceder a su limpieza, revisi&oacute;n o mantenimiento.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Los que encuentren cobertura dentro de las garant&iacute;as en la p&oacute;liza. No se podr&aacute; invocar esta cobertura como complemento a las prestaciones de dichas coberturas, ni como sustituci&oacute;n de sus l&iacute;mites o exclusiones.<br />
&middot; Los da&ntilde;os debidos al uso o desgaste normal o paulatino, as&iacute; como los sufridos por parte de las m&aacute;quinas y equipos que necesiten por su propio funcionamiento un reemplazo frecuente y los producidos por erosi&oacute;n, corrosi&oacute;n, oxidaci&oacute;n, cavitaci&oacute;n, herrumbre o incrustaciones.<br />
&middot; Los da&ntilde;os sufridos por las m&aacute;quinas y equipos de antig&uuml;edad superior a 7 a&ntilde;os.<br />
&middot; Los simples da&ntilde;os y defectos est&eacute;ticos, los que afectan a los elementos que deben ser renovados frecuentemente, los lubricantes y refrigerantes y los defectos y/o vicios ya existentes al contratar el seguro.<br />
&middot; Los da&ntilde;os por exposici&oacute;n de la maquinaria, ordenadores y/o equipos a condiciones anormales o sobrecargas intencionadas, o durante experimentos, ensayos o pruebas en los que se exijan esfuerzos superiores al normal y los causados por fallos o interrupciones en el aprovisionamiento de la energ&iacute;a avisados con antelaci&oacute;n.<br />
&middot; Los da&ntilde;os o p&eacute;rdidas de los que sea legal o contractualmente responsable el fabricante o proveedor de las maquinas y/o equipos.<br />
&middot; Los perjuicios y p&eacute;rdidas indirectas de cualquier clase.<br />
&middot; Las ca&iacute;das de equipos y elementos port&aacute;tiles.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.&#8195;<br />
</strong></p>',to_date('30/11/21','DD/MM/RR'),'123','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('27','1','4','ATRACO-ROBO-OTROS HECHOS DELICTIVOS','Infidelidad de Empleados','|0|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
&middot; El robo y expoliaci&oacute;n producido con fuerza en las cosas para acceder a ellas o con violencia o intimidaci&oacute;n a las personas, y que afecte a: La infidelidad de empleados.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'121','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('21','1','63','DA�OS MERCANCIA TRANSPORTADA','Da�os Mercancia Transportada','|8|',null,'<p><strong>Qu&eacute; est&aacute; cubierto</strong><br />
El choque de un veh&iacute;culo terrestre identificado o de las mercanc&iacute;as por el mismo transportadas, cuyo conductor o propietario no sea el asegurado, ni ning&uacute;n copropietario y/o inquilino, ni una persona que sea civilmente responsable de ellos.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'124','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('22','1','3','AVER�AS  - MERCANC�AS - DERRAMES','Derrame Inst.fijas Extinci�n','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
&middot; Los da&ntilde;os materiales directos a los bienes asegurados a consecuencia de derrame accidental o filtraciones de agua proveniente de instalaciones fijas o aparatos conectados a la red de agua.<br />
&middot; Da&ntilde;os que tengan su origen en redes de saneamiento subterr&aacute;neas, tales como fosas s&eacute;pticas, arquetas, cloacas, alcantarillados y similares.<br />
&middot; Da&ntilde;os por agua que se produzcan a causa de heladas.<br />
&middot; Los gastos necesarios de localizaci&oacute;n o reparaci&oacute;n de aver&iacute;as causantes de los da&ntilde;os, en las instalaciones fijas privativas.<br />
<strong>Qu&eacute; no est&aacute;n cubiertos:</strong> <br />
&middot; Da&ntilde;os debidos a corrosi&oacute;n generalizada o desgastes notorios de las instalaciones de la edificaci&oacute;n. <br />
&middot; Los gastos de desatasco.<br />
&middot; Los gastos de reparaci&oacute;n de aparatos o instalaciones de agua u otros l&iacute;quidos distintos a las propias tuber&iacute;as o conducciones de agua u otros l&iacute;quidos tales como: electrodom&eacute;sticos, grifer&iacute;as, o llaves de paso, aparatos sanitarios, calderas, calentadores, acumuladores, radiadores, arquetas, fosas s&eacute;pticas e instalaciones subterr&aacute;neas. <br />
&middot; Los gastos de reparaci&oacute;n de tejados o fachadas, aunque se hayan producido da&ntilde;os por agua garantizados por la p&oacute;liza.<br />
&middot; Gastos necesarios para corregir instalaciones defectuosas o mal dise&ntilde;adas.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong>
</p>',to_date('30/11/21','DD/MM/RR'),'114','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('23','1','4','ATRACO-ROBO-OTROS HECHOS DELICTIVOS','Atraco en comercio','|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
&middot; El robo y expoliaci&oacute;n producido con fuerza en las cosas para acceder a ellas o con violencia o intimidaci&oacute;n a las personas, y que afecte a: mobiliario, las mercanc&iacute;as o los da&ntilde;os materiales y desperfectos causados a los bienes asegurados durante el robo.<br />
<strong>Hasta los l&iacute;mites indicados, la garant&iacute;a se extiende a:</strong><br />
. El robo y expoliaci&oacute;n de las mercanc&iacute;as que se encuentran en escaparates independientes del negocio asegurado.<br />
&middot; El robo y expoliaci&oacute;n del dinero en efectivo o documentos bancarios acreditativos de dinero.<br />
&middot; La expoliaci&oacute;n a clientes, empleados y visitantes, cometido en el interior del negocio asegurado, incluidos los gastos de asistencia sanitaria urgente por expoliaci&oacute;n.<br />
&middot; Los gastos de reposici&oacute;n de llaves y cerraduras, por otras de similares prestaciones y caracter&iacute;sticas, si deben ser sustituidas a consecuencia de un robo como medida de precauci&oacute;n para evitar el f&aacute;cil acceso al establecimiento.<br />
&middot; La infidelidad de empleados.<br />
&middot; La expoliaci&oacute;n a cobradores o transportadores de fondos.<br />
&middot; Los gastos de puesta en orden de archivos.<br />
&middot; Los gastos de limpieza y acondicionamiento del negocio.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'119','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('24','1','4','ATRACO-ROBO-OTROS HECHOS DELICTIVOS','Atraco en v�a publica','|6|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
El robo fuera de la vivienda cometido con violencia o intimidaci&oacute;n hacia el asegurado o miembros de su familia de: enseres y dinero en efectivo, hasta el l&iacute;mite indicado en la p&oacute;liza<br />
<strong>No est&aacute; cubierto:</strong><br />
&middot; El Hurto de dinero en efectivo.<br />
&middot; El robo y/o hurto de los objetos de valor art&iacute;stico.<br />
&middot; El robo o hurto que afecte a enseres que se encuentren en dependencias que no sean de su uso exclusivo.<br />
&middot; El robo o hurto que afecte a joyas que se encuentren al aire libre, en patios o jardines, o en el interior de construcciones abiertas.<br />
&middot; P&eacute;rdidas o extrav&iacute;os<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'120','							Recuerda que tiene que haber amenaza o violencia hacia la persona.
																																																									 
												 
												 
												 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('25','1','4','ATRACO-ROBO-OTROS HECHOS DELICTIVOS','Robo','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
El robo y expoliaci&oacute;n producido con fuerza en las cosas para acceder a ellas o con violencia o intimidaci&oacute;n a las personas, y que afecte a:<br />
&middot; El mobiliario<br />
&middot; Las joyas o alhajas hasta el l&iacute;mite indicado en p&oacute;liza. <br />
&middot; Dinero en efectivo, hasta el l&iacute;mite indicado en p&oacute;liza.<br />
. Los da&ntilde;os materiales y desperfectos causados a los bienes asegurados durante el robo.<br />
. El robo de los elementos de la edificaci&oacute;n<br />
. Los gastos de reposici&oacute;n de llaves y cerraduras, por otras de similares prestaciones y caracter&iacute;sticas, si deben ser sustituidas a consecuencia de un robo como medida de precauci&oacute;n para evitar el f&aacute;cil acceso a la vivienda, hasta el l&iacute;mite indicado en p&oacute;liza. <br />
. El uso fraudulento de tarjetas de cr&eacute;dito, hasta el l&iacute;mite indicado en p&oacute;liza.<br />
. Hurto, o sustracci&oacute;n sin fuerza en las cosas para acceder al lugar donde se encuentran, ni violencia o intimidaci&oacute;n en las personas, hasta el l&iacute;mite indicado en el apartado Tabla Resumen y que afecte a los enseres asegurados.<br />
. El robo fuera de la vivienda cometido con violencia o intimidaci&oacute;n hacia el asegurado o miembros de su familia de:<br />
&middot; Enseres, hasta el l&iacute;mite indicado en p&oacute;liza.<br />
&middot; Dinero en efectivo, hasta el l&iacute;mite indicado en p&oacute;liza.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; El Hurto de dinero en efectivo.<br />
&middot; El robo y/o hurto de los objetos de valor art&iacute;stico.<br />
. El robo o hurto que afecte a enseres que se encuentren en dependencias que no sean de su uso exclusivo.<br />
&middot; El robo o hurto que afecte a joyas que se encuentren al aire libre, en patios o jardines, o en el interior de construcciones abiertas.<br />
&middot; P&eacute;rdidas o extrav&iacute;os<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'118','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('26','1','4','ATRACO-ROBO-OTROS HECHOS DELICTIVOS','Actos de Vandalismo','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os materiales a los bienes asegurados cuando se produzcan actos de vandalismo o malintencionados cometidos individual o colectivamente por otras personas.<br />
<strong>No est&aacute;n cubiertos :</strong><br />
&middot; Los da&ntilde;os causados por los inquilinos o por otros ocupantes de la vivienda.<br />
&middot; Las pintadas, rayadas, inscripciones y pegado de carteles.<br />
&middot; Los actos de vandalismo que no se hayan denunciado ante la autoridad competente.<br />
&middot; La rotura de cristales o materiales sustitutivos del cristal, lunas espejos, m&aacute;rmoles y elementos de loza sanitaria salvo cuando est&eacute; contratada la garant&iacute;a de roturas.<br />
&middot; Los da&ntilde;os producidos por robo y expoliaci&oacute;n, salvo cuando est&eacute; contratada la garant&iacute;a de robo.<br />
. Los actos de vandalismo cuando los bienes asegurados no se encuentren en la vivienda asegurada<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'108','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('28','1','4','ATRACO-ROBO-OTROS HECHOS DELICTIVOS','Uso fraudulento de tarjetas','|6|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Dentro de la garant&iacute;a de Robo y Expoliaci&oacute;n de la vivienda, AXA cubre el uso fraudulento de tarjetas de cr&eacute;dito, hasta el l&iacute;mite incluido en p&oacute;liza. <br />
<strong>Que no est&aacute; cubierto:</strong><br />
&middot; El hurto de dinero en efectivo.<br />
. El robo o hurto que afecte a enseres que se encuentren en dependencias que no sean de su uso exclusivo.<br />
&middot; P&eacute;rdidas o extrav&iacute;os<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'180','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('29','1','5','ROTURAS','Rotura de cristales y espejos','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
La rotura, incluidos los gastos de transporte, colocaci&oacute;n y montaje de:<br />
&middot; Cristales y espejos fijados a la edificaci&oacute;n o a los enseres.<br />
&middot; Cristales planos destinados a cubrir muebles de forma permanente.<br />
&middot; Encimeras de m&aacute;rmol, granito u otras piedras naturales o artificiales.<br />
&middot; Elementos sanitarios de cualquier material.<br />
&middot; Cristal de placa vitrocer&aacute;mica o de inducci&oacute;n.<br />
&middot; Cristal de placa solar.<br />
&middot; Acuarios o peceras de cristal o cualquier otro material.<br />
&middot; Muebles, mamparas o estanter&iacute;as de cristal, metacrilato u otros pl&aacute;sticos de similares caracter&iacute;sticas<br />
<strong>No est&aacute;n cubiertos</strong><br />
&middot; Simples ara&ntilde;azos, raspaduras, desconchados o deterioros superficiales. <br />
&middot; Marcos, molduras y muebles de los que formen parte. <br />
&middot; Valor de los decorados art&iacute;sticos<br />
&middot; L&aacute;mparas y bombillas de todas clases, cristaler&iacute;as, aparatos de visi&oacute;n y sonido, lentes, objetos de uso personal y elementos decorativos no adosados a la edificaci&oacute;n o enseres del hogar de forma fija como: figuras de cristal o m&aacute;rmol, portarretratos<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'125','							Recuerda abrir tantos siniestros como roturas existan ,siempre que estas no sean producidas por el mismo origen.
																																																												 
												 
												 
												 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('2','2','1','AGUA','Lluvia','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> da&ntilde;os materiales a los bienes asegurados a consecuencia de los siguientes fen&oacute;menos externos:<br />
&middot; Lluvia, viento, pedrisco o nieve de intensidad tal que afecte a varios edificios de buena construcci&oacute;n en las proximidades al riesgo asegurado. Se incluyen los da&ntilde;os producidos por objetos arrastrados o proyectados por el viento o la lluvia.<br />
&middot; Si la cantidad de lluvia es superior a 40l/m2 y hora, o la velocidad del viento es superior a 84 Km/h., no ser&aacute; necesario el requisito que varios edificios se encuentren afectados.<br />
&middot; Inundaci&oacute;n debida a desbordamientos de cauces o cursos de agua construidos por el hombre y cuya cobertura no corresponda al Consorcio de Compensaci&oacute;n de seguros.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Da&ntilde;os a los bienes que est&eacute;n depositados al aire libre, a&uacute;n cuando se hallen protegidos por materiales flexibles (lonas, pl&aacute;sticos, construcciones hinchables o similares) o contenidos en el interior de construcciones abiertas, tales como terrazas, jardines, patios o porches.<br />
&middot; Da&ntilde;os producidos por nieve, agua, arena o el polvo que entre por puertas, ventanas u otras aberturas que est&eacute;n sin cerrar o con cierre defectuoso.<br />
&middot; Da&ntilde;os producidos por heladas, frio o hielo<br />
&middot; Da&ntilde;os producidos por olas o mareas, incluso cuando estos fen&oacute;menos hayan sido causados por el viento.<br />
&middot; Da&ntilde;os producidos por desbordamiento o rotura de presas y diques de contenci&oacute;n.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'104',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('57','1','16','TODO RIESGO OBJETOS DE ARTE','Todo Riesgo Objetos de arte','|6|7|8|',null,'<p>Cubrimos los objetos de valor art&iacute;stico, que se encuentren declarados en la p&oacute;liza, de robo, atraco, expoliaci&oacute;n o hurto, p&eacute;rdida, incendio o da&ntilde;os accidentales o causados por mala intenci&oacute;n de terceros.</p>',to_date('30/11/21','DD/MM/RR'),'184','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('133','1','0','TODAS LAS CAUSAS','Aver�a sin da�os -da�os agua-','|6|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Hasta el l&iacute;mite indicado en la p&oacute;liza los gastos de fontaner&iacute;a necesarios para la localizaci&oacute;n y reparaci&oacute;n de fugas accidentales de agua u otros l&iacute;quidos, aun cuando no se hayan producido los da&ntilde;os por: <br />
- Ser directos a los bienes asegurados a consecuencia de derrame accidental o filtraciones de agua proveniente de instalaciones fijas (incluso por omisi&oacute;n o desajuste del cierre de grifos, llaves de paso o cualquier tipo de v&aacute;lvula), o aparatos conectados a la red de agua.<br />
- Tener su origen en redes de saneamiento subterr&aacute;neas, tales como fosas s&eacute;pticas, arquetas, cloacas, alcantarillados y similares.<br />
- Tener su origen en acuarios y/o peceras.<br />
- Ser producidos a causa de heladas.<br />
- Los gastos necesarios de localizaci&oacute;n o reparaci&oacute;n de aver&iacute;as causantes de los da&ntilde;os, en las instalaciones fijas privativas.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Da&ntilde;os debidos a corrosi&oacute;n generalizada o desgastes notorios de las instalaciones de la edificaci&oacute;n.<br />
&middot; Los gastos de desatasco<br />
&middot; Los gastos de reparaci&oacute;n de aparatos o instalaciones de agua u otros l&iacute;quidos distintos a las propias tuber&iacute;as o conducciones de agua u otros l&iacute;quidos tales como: electrodom&eacute;sticos, grifer&iacute;as, o llaves de paso, aparatos sanitarios, calderas, calentadores, acumuladores, radiadores, arquetas, fosas s&eacute;pticas e instalaciones subterr&aacute;neas.<br />
&middot; Los gastos de reparaci&oacute;n de tejados o fachadas, aunque se hayan producido da&ntilde;os por agua garantizados por la p&oacute;liza.<br />
&middot; Gastos necesarios para corregir instalaciones defectuosas o mal dise&ntilde;adas.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'173','        Recuerda que si se producen da�os la causa correcta de apertura es Da�os agua. Adem�s te informamos que esta garant�a tiene limite si no se ocasionan da�os.
																																														 
												 
												 
												 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('1','2','1','AGUA','Da�os Agua','|6|7|8|10|',null,'<p><strong>Puede declarar siniestro con esta causa por</strong> los da&ntilde;os materiales a consecuencia de derrame accidental o filtraciones de agua provenientes de instalaciones fijas o aparatos conectados a la red de agua.<br />
&middot; Da&ntilde;os que tengan su origen en redes de saneamiento subterr&aacute;neas, tales como fosas s&eacute;pticas, arquetas, cloacas, alcantarillados y similares.<br />
&middot; Da&ntilde;os por agua que se produzcan a causa de heladas.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Da&ntilde;os debidos a corrosi&oacute;n generalizada o desgastes notorios de las instalaciones de la edificaci&oacute;n.<br />
&middot; Los gastos de desatasco.<br />
&middot; Los gastos de reparaci&oacute;n de aparatos o instalaciones de agua u otros l&iacute;quidos distintos a las propias tuber&iacute;as o conducciones de agua u otros l&iacute;quidos tales como: electrodom&eacute;sticos, grifer&iacute;as, o llaves de paso, aparatos sanitarios, calderas, calentadores, acumuladores, radiadores, arquetas, fosas s&eacute;pticas e instalaciones subterr&aacute;neas.<br />
&middot; Los gastos de reparaci&oacute;n de tejados o fachadas, aunque se hayan producido da&ntilde;os por agua garantizados por la p&oacute;liza.<br />
&middot; Gastos necesarios para corregir instalaciones defectuosas o mal dise&ntilde;adas.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'115',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('1','1','1','DA�OS AGUA-OTROS L�QUIDOS','Da�os Agua','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
&middot; Los da&ntilde;os materiales a consecuencia de derrame accidental o filtraciones de agua provenientes de instalaciones fijas o aparatos conectados a la red de agua.<br />
&middot; Da&ntilde;os que tengan su origen en redes de saneamiento subterr&aacute;neas, tales como fosas s&eacute;pticas, arquetas, cloacas, alcantarillados y similares.<br />
&middot; Da&ntilde;os por agua que se produzcan a causa de heladas.<br />
&middot; Los gastos necesarios de localizaci&oacute;n o reparaci&oacute;n de aver&iacute;as causantes de los da&ntilde;os, en las instalaciones fijas privativas.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Da&ntilde;os debidos a corrosi&oacute;n generalizada o desgastes notorios de las instalaciones de la edificaci&oacute;n.<br />
&middot; Los gastos de desatasco.<br />
&middot; Los gastos de reparaci&oacute;n de aparatos o instalaciones de agua u otros l&iacute;quidos distintos a las propias tuber&iacute;as o conducciones de agua u otros l&iacute;quidos tales como: electrodom&eacute;sticos, grifer&iacute;as, o llaves de paso, aparatos sanitarios, calderas, calentadores, acumuladores, radiadores, arquetas, fosas s&eacute;pticas e instalaciones subterr&aacute;neas.<br />
&middot; Los gastos de reparaci&oacute;n de tejados o fachadas, aunque se hayan producido da&ntilde;os por agua garantizados por la p&oacute;liza.<br />
&middot; Gastos necesarios para corregir instalaciones defectuosas o mal dise&ntilde;adas.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'115','																																																								Recuerda que en casos de da�os provocados por las lluvias, debes abrir el siniestro por la causa Lluvia.  				 
												 
												 
												 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('60','2','7','OTROS SERVICIOS DE ASISTENCIA','Restablecimiento de luz','|6|7|8|10|',null,'<p>Tiene a su disposici&oacute;n nuestra red de reparadores para los siguientes servicios de contenci&oacute;n de da&ntilde;os durante las 24 horas del d&iacute;a todos los d&iacute;as de la semana:</p>
<p><strong>Que cubre:</strong><br />
El env&iacute;o de un electricista, para que si es posible reanude el servicio, si una causa<br />
accidental deja sin luz la vivienda asegurada.</p>
<p>Los gastos del env&iacute;o del profesional y la mano de obra ser&aacute;n a cargo de AXA. El coste de la renovaci&oacute;n de los materiales da&ntilde;ados ser&aacute; a su cargo, excepto cuando los da&ntilde;os tengan su origen en cualquiera de los riesgos cubiertos por la p&oacute;liza, en cuyo caso, AXA asume el coste de dichos materiales</p>
<p><strong>No est&aacute;n cubiertas:</strong> Reparaciones no efectuadas por la red de reparadores de AXA.</p>
<p><strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('29/11/16','DD/MM/RR'),'187',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('39','1','59','BRICOPARTNER','Bricopartner','|6|',null,'<p>AXA pone a disposici&oacute;n de sus clientes un servicio de bricolaje en la vivienda asegurada, que incluye:<br />
&middot; Sellado de juntas deterioradas de su ba&ntilde;era que ocasionen humedades por filtraciones en paredes<br />
contiguas.<br />
&middot; Sustituci&oacute;n de grifos y mecanismos de cisterna.<br />
&middot; Colocaci&oacute;n y sustituci&oacute;n de l&aacute;mparas y apliques de techo y pared.<br />
&middot; Montaje de muebles kit y estanter&iacute;as.<br />
&middot; Fijaci&oacute;n de elementos a paredes, tales como cuadros o espejos.<br />
&middot; Colocaci&oacute;n de accesorios de ba&ntilde;o y cocina.<br />
&middot; Instalaci&oacute;n de cortinas, visillos, estores.<br />
&middot; Sustituci&oacute;n de enchufes o interruptores de luz por otros diferentes (sin cambios de ubicaci&oacute;n)<br />
&middot; Puesta en marcha, conectividades y configuraci&oacute;n del equipamiento tecnol&oacute;gico, TDT, DVD, C&aacute;mara Digital, Home Cinema, Video Digital, Ordenadores, TV y V&iacute;deo, Consolas.<br />
&middot; Gastos de desplazamiento de 2 visitas por anualidad de seguro de 2 horas de mano de obra gratis cada una.<br />
&middot; O los gastos de desplazamiento de 1 visita por anualidad de seguro de 4 horas de mano de obra gratis.<br />
&middot; Usted deber&aacute; hacerse cargo de los materiales empleados y en su caso, del exceso de tiempo de mano de obra que se pudiera producir.<br />
&middot; El servicio ser&aacute; prestado por la red de profesionales de AXA de lunes a viernes en horario de 9 a 22 horas.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong><br />
</p>',to_date('30/11/21','DD/MM/RR'),'177','						Recuerda que el asegurado tiene que disponer del material antes de que llegue el reparador . Se pueden utilizar varios servicios siempre que sean de la misma especialidad e impliquen la intervenci�n de un �nico operario. Recuerda que tiene dos servicios por anualidad con un m�ximo de 2 horas cada uno.
																													 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('40','1','7','SERVICIOS DE ASISTENCIA','Otros servicios','|6|7|8|10|',null,'<p>Dentro del apartado de Otros Servicios, le ofrecemos asesoramiento sobre la salud de las plantas de su jard&iacute;n, &aacute;rboles y arbustos as&iacute; como el mantenimiento de su piscina. </p>
<p>Servicio de consulta y ayuda para solucionar incidencias que afecten a equipos inform&aacute;ticos que se encuentren en la vivienda asegurada.</p>
<p>Cubrimos la rotura accidental de art&iacute;culos deportivos dentro de la vivienda asegurada.<br />
Cubrimos las siguientes prestaciones siempre que se deriven de un hecho accidental ocurrido durante un viaje de sus vacaciones o a consecuencia de practicar una actividad deportiva con car&aacute;cter amateur: Repatriaci&oacute;n o Transportes de heridos enfermos o fallecidos, gastos de curaci&oacute;n en el extranjero, Indemnizaci&oacute;n por retraso de equipaje y regreso anticipado en caso de hospitalizaci&oacute;n o defunci&oacute;n de un familiar.</p>
<p><strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'131','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('42','1','62','DA�OS EL�CTRICOS','Da�os el�ctricos','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Da&ntilde;os materiales sufridos por la instalaci&oacute;n el&eacute;ctrica, as&iacute; como la propia edificaci&oacute;n y/o los aparatos el&eacute;ctricos y/o electr&oacute;nicos, como consecuencia de sobretensi&oacute;n, un cortocircuito, incluso las producidas por tormenta o rayo.<br />
<strong>No est&aacute;n cubiertos</strong>:<br />
&middot; Reparaciones de aparatos el&eacute;ctricos y/o electr&oacute;nicos que no hayan sido realizadas por nuestros <br />
profesionales.<br />
&middot; Las bombillas, l&aacute;mparas, hal&oacute;genos, tubos fluorescentes o similares<br />
&middot; Los aparatos de antig&uuml;edad superior a 8 a&ntilde;os.<br />
&middot; Los aparatos de valor inferior a 150 euros.<br />
. Da&ntilde;os y/o p&eacute;rdidas de los que sea legal o contractualmente responsable el fabricante o proveedor del aparato.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'132','																									Si los aparatos afectados son de la marca TEKA, recuerda que puedes asignar a TEKA INDUSTRIAL manualmente, para esta causa.
						
																									 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('43','1','65','DETERIORO BIENES REFRIGERADOS','Deterioro Bienes Refrigerados','|6|8|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
La podredumbre de bienes refrigerados o congelados dentro del frigor&iacute;fico o congelador, como consecuencia de falta de suministro el&eacute;ctrico o aver&iacute;a de dichos aparatos<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Da&ntilde;os que hayan podido sufrir el frigor&iacute;fico o congelador.<br />
&middot; Da&ntilde;os que puedan causar los bienes al deteriorarse.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'116','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('44','1','8','EQUIPOS INFORM�TICOS','Equipos informaticos','|6|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Da&ntilde;os materiales sufridos por ordenadores personales y sus equipos perif&eacute;ricos, en el interior de la edificaci&oacute;n asegurada, a primer riesgo, a consecuencia de:<br />
&middot; Impericia o negligencia.<br />
&middot; Impactos y colisiones accidentales.<br />
&middot; Derrame de l&iacute;quidos o introducci&oacute;n de cuerpos extra&ntilde;os, accidentalmente.<br />
&middot; Ca&iacute;das, excepto en equipos y elementos port&aacute;tiles.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; P&eacute;rdidas o da&ntilde;os a equipos alquilados, si es responsable el propietario, ya sea legalmente o seg&uacute;n <br />
convenio de alquiler y/o mantenimiento.<br />
&middot; Elementos cuya antig&uuml;edad sea superior a 10 a&ntilde;os.<br />
&middot; Electrodom&eacute;sticos.<br />
&middot; Ca&iacute;das sufridas por equipos y elementos port&aacute;tiles.<br />
. Defectos est&eacute;ticos, como raspaduras de superficies pintadas, pulidas o barnizadas.<br />
&middot; Cualquier gasto ocasionado con objeto de eliminar fallos operacionales, a menos que dichos fallos sean causados por p&eacute;rdida o da&ntilde;o indemnizable ocurrido a bienes asegurados.<br />
&middot; Cualquier gasto derivado del mantenimiento de los bienes asegurados. Tal exclusi&oacute;n se aplica a las <br />
partes recambiadas en el curso de dichas operaciones de mantenimiento.<br />
&middot; Las p&eacute;rdidas o da&ntilde;os causados directa o indirectamente por variaci&oacute;n o interrupci&oacute;n en el <br />
aprovisionamiento de corriente el&eacute;ctrica de la red p&uacute;blica.<br />
&middot; Defectos y vicios, as&iacute; como el desgaste o deterioro paulatino derivado del uso habitual.<br />
&middot; Ensayos y pruebas en cuyo transcurso sea sometido el bien asegurado a un desgaste superior al normal.<br />
&middot; Da&ntilde;os de los que sea responsable, legal o contractualmente, el fabricante o proveedor.<br />
&middot; Elementos susceptibles de desgaste por el uso habitual.<br />
&middot; El software y los programas inform&aacute;ticos en general, incluso los sistemas electr&oacute;nicos de protecci&oacute;n de paquetes de software (llaves de seguridad).<br />
&middot; Da&ntilde;os y gastos cubiertos por contrato de asistencia t&eacute;cnica o mantenimiento.<br />
&middot; Las roturas que se produzcan como consecuencia de la realizaci&oacute;n de obras, de la manipulaci&oacute;n y/o del transporte.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'179','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('41','1','62','DA�OS EL�CTRICOS','Caida de Rayo','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os materiales que sufran los bienes asegurados, cuando se destruyan a consecuencia del impacto directo del rayo.<br />
Los da&ntilde;os ocasionados a los veh&iacute;culos a motor, remolques, caravanas y embarcaciones de recreo cuando se encuentren estacionados dentro del garaje de la vivienda asegurada en el momento de producirse el impacto directo del rayo.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.<br />
</strong></p>',to_date('30/11/21','DD/MM/RR'),'103','																																										Recuerda solo cubrimos los da�os que causa el impacto directo del rayo, si existen aparatos el�ctricos da�ados debe modificarse la causa a Da�os el�ctricos. 
																													 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('2','1','1','AGUA','Lluvia','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Da&ntilde;os materiales a los bienes asegurados cuando se destruyan a consecuencia de los siguientes fen&oacute;menos externos:<br />
&middot; Lluvia, viento, pedrisco o nieve de intensidad tal que afecte a varios edificios de buena construcci&oacute;n en las proximidades de la vivienda asegurada. Se incluyen los da�os producidos por objetos arrastrados o proyectados por el viento o la lluvia.<br />
&middot; Si la cantidad de lluvia es superior a 40l/m2 y hora, o la velocidad del viento es superior a 84 Km/h., no ser&aacute; necesario el requisito que varios edificios se encuentren afectados.<br />
&middot; Inundaci&oacute;n debida a desbordamientos de cauces o cursos de agua construidos por el hombre y cuya cobertura no corresponda al Consorcio de Compensaci&oacute;n de seguros.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Da�os a los enseres del hogar que est&eacute;n depositados al aire libre, a&uacute;n cuando se hallen protegidos por materiales flexibles (lonas, pl&aacute;sticos, construcciones hinchables o similares) o contenidos en el interior de construcciones abiertas.<br />
&middot; Da�os producidos por nieve, agua, arena o el polvo que entre por puertas, ventanas u otras aberturas que est&eacute;n sin cerrar o con cierre defectuoso.<br />
&middot; Da�os producidos por heladas, frio o hielo<br />
&middot; Da�os producidos por olas o mareas, incluso cuando estos fen&oacute;menos hayan sido causados por el viento.<br />
&middot; Da�os producidos por desbordamiento o rotura de presas y diques de contenci&oacute;n.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'104','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('7','1','60','FEN�MENOS ATMOSF�RICOS-TERRESTRES','Caida de Rayo','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os materiales que sufran los bienes asegurados, cuando se destruyan a consecuencia del impacto directo del rayo.<br />
Los da&ntilde;os ocasionados a los veh&iacute;culos a motor, remolques, caravanas y embarcaciones de recreo cuando se encuentren estacionados dentro del garaje de la vivienda asegurada en el momento de producirse el impacto directo del rayo.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.<br />
</strong></p>',to_date('30/11/21','DD/MM/RR'),'103','																																										Recuerda solo cubrimos los da�os que causa el impacto directo del rayo, si existen aparatos el�ctricos da�ados debe modificarse la causa a Da�os el�ctricos. 
																													 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('58','1','0','TODAS LAS CAUSAS','RESTO DE CAUSAS','|0|',null,null,to_date('30/11/21','DD/MM/RR'),'0','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('4','1','1','AGUA','Inundaci�n-Desbordamiento','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Da&ntilde;os materiales a los bienes asegurados cuando se destruyan a consecuencia de fen&oacute;menos externos como la inundaci&oacute;n debida a desbordamientos de cauces o cursos de agua construidos por el hombre y cuya cobertura no corresponda al Consorcio de Compensaci&oacute;n de seguros.<br />
<strong>Qu&eacute; no est&aacute;n cubiertos:</strong><br />
&middot; Da&ntilde;os a los enseres del hogar que est&eacute;n depositados al aire libre, aun cuando se hallen protegidos por materiales flexibles (lonas, pl&aacute;sticos, construcciones hinchables o similares) o contenidos en el interior de construcciones abiertas.<br />
&middot; Da&ntilde;os producidos por nieve, agua, arena o el polvo que entre por puertas, ventanas u otras aberturas que est&eacute;n sin cerrar o con cierre defectuoso.<br />
&middot; Da&ntilde;os producidos por heladas, frio o hielo<br />
&middot; Da&ntilde;os producidos por olas o mareas, incluso cuando estos fen&oacute;menos hayan sido causados por el viento.<br />
&middot; Da&ntilde;os producidos por desbordamiento o rotura de presas y diques de contenci&oacute;n.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'107','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('5','1','1','DA�OS AGUA-OTROS L�QUIDOS','Fuga de instalaci�n contra incendios','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
&middot; Los da&ntilde;os materiales directos a los bienes asegurados a consecuencia de derrame accidental o filtraciones de agua proveniente de instalaciones fijas o aparatos conectados a la red de agua.<br />
&middot; Da&ntilde;os que tengan su origen en redes de saneamiento subterr&aacute;neas, tales como fosas s&eacute;pticas, arquetas, cloacas, alcantarillados y similares.<br />
&middot; Da&ntilde;os por agua que se produzcan a causa de heladas.<br />
&middot; Los gastos necesarios de localizaci&oacute;n o reparaci&oacute;n de aver&iacute;as causantes de los da&ntilde;os, en las instalaciones fijas privativas.<br />
<strong>Qu&eacute; no est&aacute;n cubiertos: </strong><br />
&middot; Da&ntilde;os debidos a corrosi&oacute;n generalizada o desgastes notorios de las instalaciones de la edificaci&oacute;n. <br />
&middot; Los gastos de desatasco.<br />
&middot; Los gastos de reparaci&oacute;n de aparatos o instalaciones de agua u otros l&iacute;quidos distintos a las propias tuber&iacute;as o conducciones de agua u otros l&iacute;quidos tales como: electrodom&eacute;sticos, grifer&iacute;as, o llaves de paso, aparatos sanitarios, calderas, calentadores, acumuladores, radiadores, arquetas, fosas s&eacute;pticas e instalaciones subterr&aacute;neas. <br />
&middot; Los gastos de reparaci&oacute;n de tejados o fachadas, aunque se hayan producido da&ntilde;os por agua garantizados por la p&oacute;liza.<br />
&middot; Gastos necesarios para corregir instalaciones defectuosas o mal dise&ntilde;adas.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'114','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('6','1','60','FEN�MENOS ATMOSF�RICOS-TERRESTRES','Lluvia','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Da&ntilde;os materiales a los bienes asegurados cuando se destruyan a consecuencia de los siguientes fen&oacute;menos externos:<br />
&middot; Lluvia, viento, pedrisco o nieve de intensidad tal que afecte a varios edificios de buena construcci&oacute;n en las proximidades de la vivienda asegurada. Se incluyen los da�os producidos por objetos arrastrados o proyectados por el viento o la lluvia.<br />
&middot; Si la cantidad de lluvia es superior a 40l/m2 y hora, o la velocidad del viento es superior a 84 Km/h., no ser&aacute; necesario el requisito que varios edificios se encuentren afectados.<br />
&middot; Inundaci&oacute;n debida a desbordamientos de cauces o cursos de agua construidos por el hombre y cuya cobertura no corresponda al Consorcio de Compensaci&oacute;n de seguros.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Da�os a los enseres del hogar que est&eacute;n depositados al aire libre, a&uacute;n cuando se hallen protegidos por materiales flexibles (lonas, pl&aacute;sticos, construcciones hinchables o similares) o contenidos en el interior de construcciones abiertas.<br />
&middot; Da�os producidos por nieve, agua, arena o el polvo que entre por puertas, ventanas u otras aberturas que est&eacute;n sin cerrar o con cierre defectuoso.<br />
&middot; Da�os producidos por heladas, frio o hielo<br />
&middot; Da�os producidos por olas o mareas, incluso cuando estos fen&oacute;menos hayan sido causados por el viento.<br />
&middot; Da�os producidos por desbordamiento o rotura de presas y diques de contenci&oacute;n.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'104','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('9','1','60','FEN�MENOS ATMOSF�RICOS-TERRESTRES','Viento','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os materiales a los bienes asegurados cuando se destruyan a consecuencia del viento de intensidad tal que afecte a varios edificios de buena construcci&oacute;n en las proximidades de la vivienda asegurada. Se incluyen los da&ntilde;os producidos por objetos arrastrados o proyectados por el viento o la lluvia:<br />
&middot; Si la cantidad de lluvia es superior a 40l/m2 y hora, o la velocidad del viento es superior a 84 Km/h., no ser&aacute; necesario el requisito que varios edificios se encuentren afectados.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Los da&ntilde;os a los enseres del hogar que est&eacute;n depositados al aire libre, aun cuando se hallen protegidos por materiales flexibles o contenidos en el interior de construcciones abiertas.<br />
&middot; Los da&ntilde;os producidos por nieve, agua, arena o el polvo que entre por puertas, ventanas u otras aberturas que est&eacute;n sin cerrar o con cierre defectuoso.<br />
&middot; Los da&ntilde;os producidos por heladas, frio o hielo.<br />
&middot; Los da&ntilde;os producidos por olas o mareas, incluso cuando estos fen&oacute;menos hayan sido causados por el viento.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'105','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('143','1','0','TODAS LAS CAUSAS','Accidentes personales','|6|7|8|10|',null,'<p><b>Qu&eacute; est&aacute; cubierto:</b><br />
Si el asegurado o cualquier miembro de su familia sufre un accidente en la vivienda asegurada, AXA se har&aacute; cargo de las siguientes prestaciones:<br />
a) Gastos de curaci&oacute;n<br />
Gastos m&eacute;dicos y farmac&eacute;uticos derivados de las lesiones personales que pueda sufrir el asegurado o cualquier miembro de su familia:<br />
&middot; Sin l&iacute;mite econ&oacute;mico en los centros concertados con AXA y durante un periodo m&aacute;ximo de 3 a&ntilde;os, siguientes a la fecha de ocurrencia del siniestro.<br />
b) Indemnizaci&oacute;n para el caso de fallecimiento<br />
AXA pagar&aacute; los beneficiarios la suma asegurada indicada en la Tabla Resumen del Condicionado General de la p&oacute;liza.<br />
c) Indemnizaci&oacute;n para caso de invalidez permanente <br />
d) Anticipo de capital en caso de fallecimiento para atender a los gastos derivados del fallecimiento del Asegurado en caso de accidente.<br />
e) Prestaci&oacute;n extraordinaria para menores de edad <br />
f) Asesoramiento v&iacute;a telef&oacute;nica con un m&eacute;dico las 24 h. del d&iacute;a los 365 d&iacute;as del a&ntilde;o<br />
g) Los gastos de asistencia psicol&oacute;gica del asegurado para superar el stress post traum&aacute;tico sufrido como consecuencia del accidente.<br />
El m&aacute;ximo de siniestros por anualidad de seguro para esta cobertura ser&aacute; de 5.<br />
<b>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</b><br />
</p>',to_date('30/11/21','DD/MM/RR'),'134','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('144','1','0','TODAS LAS CAUSAS','Accidentes domesticos o por calor','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os causados en la edificaci&oacute;n y/o enseres asegurados por la acci&oacute;n s&uacute;bita del calor o del contacto directo del fuego o de una sustancia incandescente aun cuando no se produzca incendio<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Da&ntilde;os causados por &quot;accidente de fumador&quot;<br />
&middot; Joyas y objetos de valor art&iacute;stico.<br />
&middot; Gafas y art&iacute;culos &oacute;pticos en general, incluso a&eacute;reos o n&aacute;uticos.<br />
&middot; Aparatos electr&oacute;nicos.<br />
&middot; Da&ntilde;os causados por la acci&oacute;n progresiva de la temperatura y de las diferentes condiciones atmosf&eacute;ricas.<br />
&middot; Fallos en los dispositivos de regulaci&oacute;n<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'148','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('145','1','0','TODAS LAS CAUSAS','Acciones Tumultuarias','|6|7|8|10|',null,'<p><strong>No est&aacute;n cubiertos: </strong><br />
Los da&ntilde;os causados por actuaciones tumultuarias producidas en el curso de reuniones y manifestaciones llevadas a cabo conforme a lo dispuesto en la Ley Org&aacute;nica 9/1983, de 15 de julio, reguladora del derecho de reuni&oacute;n, as&iacute; como durante el transcurso de huelgas legales, salvo que las citadas actuaciones pudieran ser calificadas como acontecimientos extraordinarios conforme al art&iacute;culo 1 del reglamento del seguro de riesgos extraordinarios.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'109','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('146','1','0','TODAS LAS CAUSAS','Actos de Vandalismo','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os materiales a los bienes asegurados cuando se produzcan actos de vandalismo o malintencionados cometidos individual o colectivamente por otras personas.<br />
<strong>No est&aacute;n cubiertos :</strong><br />
&middot; Los da&ntilde;os causados por los inquilinos o por otros ocupantes de la vivienda.<br />
&middot; Las pintadas, rayadas, inscripciones y pegado de carteles.<br />
&middot; Los actos de vandalismo que no se hayan denunciado ante la autoridad competente.<br />
&middot; La rotura de cristales o materiales sustitutivos del cristal, lunas espejos, m&aacute;rmoles y elementos de loza sanitaria salvo cuando est&eacute; contratada la garant&iacute;a de roturas.<br />
&middot; Los da&ntilde;os producidos por robo y expoliaci&oacute;n, salvo cuando est&eacute; contratada la garant&iacute;a de robo.<br />
. Los actos de vandalismo cuando los bienes asegurados no se encuentren en la vivienda asegurada<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'108','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('1','4','1','SANCIONES','Adelantamiento en l�nea cont�nua','|2|',null,'<p>Supuestos en los que se realice una maniobra de adelantamiento prohibida, en l&iacute;nea continua &#8230; </p>',to_date('06/04/17','DD/MM/RR'),'1',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('4','4','3','SANCIONES','Sanci�n de tr�fico en v�a ejecutiva','|2|','Diligencia de Embargo','<p>Supuestos en los que se reciba notificaci&oacute;n de multa con un porcentaje de recargo a&ntilde;adido procedente de agencia tributaria, de hacienda, diputaci&oacute;n o ayuntamieno cuando ya ha finalizado el periodo de pago voluntaria y se encuentra en v&iacute;a ejecutiva (ejecuci&oacute;n forzosa)</p>',to_date('06/04/17','DD/MM/RR'),'24',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('5','4','3','SANCIONES','Sanci�n de tr�fico en v�a ejecutiva','|2|','Se�alamiento de Bienes','<p>Supuestos en los que se reciba notificaci&oacute;n de multa con un porcentaje de recargo a&ntilde;adido procedente de agencia tributaria, de hacienda, diputaci&oacute;n o ayuntamieno cuando ya ha finalizado el periodo de pago voluntaria y se encuentra en v&iacute;a ejecutiva (ejecuci&oacute;n forzosa)</p>',to_date('06/04/17','DD/MM/RR'),'24',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('124','1','0','P. BENEFICIOS POR FALLO DE SUMINISTROS','P. Beneficios por fallo de suministros','|8|',null,'<p>Garantiza la Perdida de Beneficios por el fallo en el suministro de proveedores. Las p&eacute;rdidas que por paralizaci&oacute;n de la actividad del negocio puedan producirse a consecuencia de que ocurra un siniestro en los locales de los proveedores del asegurado ubicados en Espa&ntilde;a, siempre y cuando dicho siniestro se deba a una de las garant&iacute;as espec&iacute;ficamente contratadas.</p>',to_date('30/11/21','DD/MM/RR'),'183','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('124','2','0','RESTO DE CAUSAS','P.B. Fallo de suministros','|8|',null,'<p>Garantiza la Perdida de Beneficios por el fallo en el suministro de proveedores. Las p&eacute;rdidas que por paralizaci&oacute;n de la actividad del negocio puedan producirse a consecuencia de que ocurra un siniestro en los locales de los proveedores del asegurado ubicados en Espa&ntilde;a, siempre y cuando dicho siniestro se deba a una de las garant&iacute;as espec&iacute;ficamente contratadas.</p>',to_date('13/09/18','DD/MM/RR'),'183',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('125','1','66','RUINA TOTAL','Ruina total','|6|7|',null,'<p>Se cubren los da&ntilde;os materiales a la edificaci&oacute;n y/o enseres asegurados consecuencia directa de obras realizadas por terceros en fincas o edificios colindantes u obras p&uacute;blicas realizadas en las calles adyacentes o el subsuelo y que determine la ruina total de la vivienda asegurada</p>',to_date('30/11/21','DD/MM/RR'),'191','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('125','2','2','FEN�MENOS EXTERNOS O DE LA NATURALEZA','Ruina Total','|6|7|',null,'<p>Se cubren los da&ntilde;os materiales a la edificaci&oacute;n y/o enseres asegurados consecuencia directa de obras realizadas por terceros en fincas o edificios colindantes u obras p&uacute;blicas realizadas en las calles adyacentes o el subsuelo y que determine la ruina total de la vivienda asegurada</p>',to_date('13/09/18','DD/MM/RR'),'191',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('6','4','3','SANCIONES','Sanci�n de tr�fico en v�a ejecutiva','|2|','Diligencia bancaria','<p>Supuestos en los que se reciba notificaci&oacute;n de multa con un porcentaje de recargo a&ntilde;adido procedente de agencia tributaria, de hacienda, diputaci&oacute;n o ayuntamieno cuando ya ha finalizado el periodo de pago voluntaria y se encuentra en v&iacute;a ejecutiva (ejecuci&oacute;n forzosa)</p>',to_date('06/04/17','DD/MM/RR'),'24',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('126','1','14','RESPONSABILIDAD CIVIL','RC Contaminaci�n','|7|',null,'<p>Queda garantizada la responsabilidad civil del asegurado por: los da&ntilde;os y perjuicios causados a terceros por contaminaci&oacute;n, y los da&ntilde;os causados a los recursos naturales por contaminaci&oacute;n.</p>',to_date('30/11/21','DD/MM/RR'),'194','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('126','2','14','DA�OS A TERCEROS','R.C Contaminaci�n','|7|',null,'<p>Queda garantizada la responsabilidad civil del asegurado por: los da&ntilde;os y perjuicios causados a terceros por contaminaci&oacute;n, y los da&ntilde;os causados a los recursos naturales por contaminaci&oacute;n.</p>',to_date('13/09/18','DD/MM/RR'),'194',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('127','1','7','SERVICIOS DE ASISTENCIA','Hurto o p�rdida de llaves','|6|',null,'<p>En el caso de hurto (sustracci&oacute;n sin fuerza) o p&eacute;rdida de llaves de acceso a la vivienda cubrimos la reposici&oacute;n de llaves y cambio de cerradura. <br />A tener en cuenta: En las p&oacute;lizas flexibles s&oacute;lo queda cubierto por Robo o Atraco y tiene que tener contratada la garant&iacute;a opcional de &ldquo;Reposici&oacute;n de llaves y cerraduras&rdquo;.<br /><br /></p>',to_date('30/11/21','DD/MM/RR'),'195','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('127','2','4','ATRACO - ROBO','Hurto o p�rdida de llaves','|6|',null,'<p>En el caso de hurto (sustracci&oacute;n sin fuerza) o p&eacute;rdida de llaves de acceso a la vivienda cubrimos la reposici&oacute;n de llaves y cambio de cerradura. <br />A tener en cuenta: En las p&oacute;lizas flexibles s&oacute;lo queda cubierto por Robo o Atraco y tiene que tener contratada la garant&iacute;a opcional de &ldquo;Reposici&oacute;n de llaves y cerraduras&rdquo;.<br /><br /></p>',to_date('13/09/18','DD/MM/RR'),'195',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('128','1','14','RESPONSABILIDAD CIVIL','RC Empleados dom�sticos','|6|',null,'<p>Queda cubierta la responsabilidad civil extracontractual que sea exigible legalmente al Asegurado por los da&ntilde;os, exclusivamente corporales, sufridos por el personal dom&eacute;stico a su servicio, en el ejercicio de sus funciones, siempre y cuando dicho personal est&eacute; dado de alta en la Seguridad Social.</p>',to_date('30/11/21','DD/MM/RR'),'196','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('128','2','14','DA�OS A TERCEROS','RC Empleados dom�sticos','|6|',null,'<p>Queda cubierta la responsabilidad civil extracontractual que sea exigible legalmente al Asegurado por los da&ntilde;os, exclusivamente corporales, sufridos por el personal dom&eacute;stico a su servicio, en el ejercicio de sus funciones, siempre y cuando dicho personal est&eacute; dado de alta en la Seguridad Social.</p>',to_date('13/09/18','DD/MM/RR'),'196',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('129','1','7','OTROS SERVICIOS DE ASISTENCIA','Asesoramiento ITE','|0|',null,'Ofrecemos asesoramiento relacionado con Inspecci�n T�cnica de Edificios (ITE) y Eficacia energ�tica. Se puede poner en contacto con el telf. 916290071 para solicitar este servicio.',to_date('30/11/21','DD/MM/RR'),'600','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('129','2','7','OTROS SERVICIOS DE ASISTENCIA','Asesoramiento ITE','|7|',null,'Ofrecemos asesoramiento relacionado con Inspecci�n T�cnica de Edificios (ITE) y Eficacia energ�tica. Se puede poner en contacto con el telf. 916290071 para solicitar este servicio.',to_date('13/09/18','DD/MM/RR'),'600',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('132','1','0','TODAS LAS CAUSAS','Apertura de puerta','|6|7|8|10|',null,'<p>Tiene a su disposici&oacute;n nuestra red de reparadores para los siguientes servicios de contenci&oacute;n de da&ntilde;os durante las 24 horas del d&iacute;a todos los d&iacute;as de la semana:</p>
<p><strong>Que cubre:</strong><br />
El env&iacute;o de un cerrajero para la apertura de puerta si por una contingencia, incluida la p&eacute;rdida de llaves, no puede entrar a la vivienda asegurada y no hay otra soluci&oacute;n.</p>
<p>Los gastos del env&iacute;o del profesional y la mano de obra ser&aacute;n a cargo de AXA. El coste de la renovaci&oacute;n de los materiales da&ntilde;ados ser&aacute; a su cargo, excepto cuando los da&ntilde;os tengan su origen en cualquiera de los riesgos cubiertos por la p&oacute;liza, en cuyo caso, AXA asume el coste de dichos materiales</p>
<p><strong>No est&aacute;n cubiertas:</strong> Reparaciones no efectuadas por la red de reparadores de AXA.</p>
<p><strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'187','	Recuerda que tienen que ir reparadores de la Compa��a para esta garant�a.																			Recuerda que tienen que ir reparadores de la Compa��a para esta garant�a
																																										 
												 
												 
												 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('102','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Defensa Administrativa Municipal','|6|8|10|','PJ','<p>Esta cobertura comprende la defensa del tomador del seguro o asegurado en los procedimientos que se le sigan, por la autoridad municipal, en cuestiones de su competencia tales como ordenanzas sobre aperturas, horarios, higiene, ruidos molestos y otros.</p>',to_date('30/11/21','DD/MM/RR'),'5','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('134','1','0','TODAS LAS CAUSAS','Caida Arboles-Antenas-Farolas','|0|',null,'<p><strong>Qu&eacute; est&aacute; cubierto</strong>:<br />
Los gastos de limpieza y saneamiento, as&iacute; como los de reemplazo por otros de la misma especie, cuando los &aacute;rboles y arbustos de su parcela sufran da&ntilde;os por:<br />
&middot; Incendio, explosi&oacute;n y ca&iacute;da de un rayo.<br />
&middot; Los efectos del viento, ya sea por su intensidad como por la acci&oacute;n de objetos arrastrados por &eacute;l.<br />
&middot; Asentamientos, hundimientos, desprendimientos, corrimientos o ablandamientos del terreno, por causas accidentales.<br />
&middot; Choque de veh&iacute;culos terrestres, o de los bienes por ellos transportados siempre que no sean de su propiedad.<br />
&middot; Ca&iacute;da de cualquier objeto procedente del exterior, siempre que no sean de su propiedad.<br />
&middot; Ondas s&oacute;nicas.<br />
&middot; Actos vand&aacute;licos.<br />
<strong>No est&aacute;n cubiertos</strong>:<br />
&middot; Los da&ntilde;os producidos o agravados por falta de mantenimiento.<br />
&middot; Los da&ntilde;os producidos por plagas y/o enfermedades.<br />
&middot; Las plantaciones que no est&eacute;n radicadas en el propio terreno de la parcela, por ejemplo en macetas y jardineras.<br />
&middot; Las plantaciones efectuadas con alg&uacute;n fin comercial.<br />
&middot; Las citadas por el ep&iacute;grafe de exclusiones de car&aacute;cter general que no hayan sido espec&iacute;ficamente incluidas en la cobertura arriba descrita.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'182','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('135','1','0','TODAS LAS CAUSAS','Caida de Rayo','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os materiales que sufran los bienes asegurados, cuando se destruyan a consecuencia del impacto directo del rayo.<br />
Los da&ntilde;os ocasionados a los veh&iacute;culos a motor, remolques, caravanas y embarcaciones de recreo cuando se encuentren estacionados dentro del garaje de la vivienda asegurada en el momento de producirse el impacto directo del rayo.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.<br />
</strong></p>',to_date('30/11/21','DD/MM/RR'),'103','																																										Recuerda solo cubrimos los da�os que causa el impacto directo del rayo, si existen aparatos el�ctricos da�ados debe modificarse la causa a Da�os el�ctricos. 
																													 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('136','1','0','TODAS LAS CAUSAS','Choque o Impacto de Veh�culos','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os materiales a los bienes asegurados cuando se produzca alguna de las siguientes circunstancias:<br />
&middot; Choque de veh&iacute;culos terrestres o de los bienes por ellos transportados.<br />
&middot; Ca&iacute;da de cualquier objeto procedente del exterior, siempre que no sean de su propiedad.<br />
&middot; Impacto de animales, siempre que no sean de su propiedad.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Los da&ntilde;os a los enseres del hogar depositados al aire libre, aun cuando se hallen protegidos por materiales flexibles o contenidos en el interior de construcciones abiertas.<br />
&middot; Los da&ntilde;os causados por veh&iacute;culos, animales u objetos que sean de su propiedad o est&eacute;n bajo su control o de los miembros de su familia o de personas que dependan o convivan con el Tomador o Asegurado.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'111','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('137','1','0','TODAS LAS CAUSAS','Fuga de instalaci�n contra incendios','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
&middot; Los da&ntilde;os materiales directos a los bienes asegurados a consecuencia de derrame accidental o filtraciones de agua proveniente de instalaciones fijas o aparatos conectados a la red de agua.<br />
&middot; Da&ntilde;os que tengan su origen en redes de saneamiento subterr&aacute;neas, tales como fosas s&eacute;pticas, arquetas, cloacas, alcantarillados y similares.<br />
&middot; Da&ntilde;os por agua que se produzcan a causa de heladas.<br />
&middot; Los gastos necesarios de localizaci&oacute;n o reparaci&oacute;n de aver&iacute;as causantes de los da&ntilde;os, en las instalaciones fijas privativas.<br />
<strong>Qu&eacute; no est&aacute;n cubiertos: </strong><br />
&middot; Da&ntilde;os debidos a corrosi&oacute;n generalizada o desgastes notorios de las instalaciones de la edificaci&oacute;n. <br />
&middot; Los gastos de desatasco.<br />
&middot; Los gastos de reparaci&oacute;n de aparatos o instalaciones de agua u otros l&iacute;quidos distintos a las propias tuber&iacute;as o conducciones de agua u otros l&iacute;quidos tales como: electrodom&eacute;sticos, grifer&iacute;as, o llaves de paso, aparatos sanitarios, calderas, calentadores, acumuladores, radiadores, arquetas, fosas s&eacute;pticas e instalaciones subterr&aacute;neas. <br />
&middot; Los gastos de reparaci&oacute;n de tejados o fachadas, aunque se hayan producido da&ntilde;os por agua garantizados por la p&oacute;liza.<br />
&middot; Gastos necesarios para corregir instalaciones defectuosas o mal dise&ntilde;adas.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'114','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('138','1','0','TODAS LAS CAUSAS','Infidelidad de Empleados','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
&middot; El robo y expoliaci&oacute;n producido con fuerza en las cosas para acceder a ellas o con violencia o intimidaci&oacute;n a las personas, y que afecte a: La infidelidad de empleados.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'121','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('139','1','0','TODAS LAS CAUSAS','Inundaci�n-Desbordamiento','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Da&ntilde;os materiales a los bienes asegurados cuando se destruyan a consecuencia de fen&oacute;menos externos como la inundaci&oacute;n debida a desbordamientos de cauces o cursos de agua construidos por el hombre y cuya cobertura no corresponda al Consorcio de Compensaci&oacute;n de seguros.<br />
<strong>Qu&eacute; no est&aacute;n cubiertos:</strong><br />
&middot; Da&ntilde;os a los enseres del hogar que est&eacute;n depositados al aire libre, aun cuando se hallen protegidos por materiales flexibles (lonas, pl&aacute;sticos, construcciones hinchables o similares) o contenidos en el interior de construcciones abiertas.<br />
&middot; Da&ntilde;os producidos por nieve, agua, arena o el polvo que entre por puertas, ventanas u otras aberturas que est&eacute;n sin cerrar o con cierre defectuoso.<br />
&middot; Da&ntilde;os producidos por heladas, frio o hielo<br />
&middot; Da&ntilde;os producidos por olas o mareas, incluso cuando estos fen&oacute;menos hayan sido causados por el viento.<br />
&middot; Da&ntilde;os producidos por desbordamiento o rotura de presas y diques de contenci&oacute;n.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'107','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('140','1','0','TODAS LAS CAUSAS','Lluvia','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Da&ntilde;os materiales a los bienes asegurados cuando se destruyan a consecuencia de los siguientes fen&oacute;menos externos:<br />
&middot; Lluvia, viento, pedrisco o nieve de intensidad tal que afecte a varios edificios de buena construcci&oacute;n en las proximidades de la vivienda asegurada. Se incluyen los da�os producidos por objetos arrastrados o proyectados por el viento o la lluvia.<br />
&middot; Si la cantidad de lluvia es superior a 40l/m2 y hora, o la velocidad del viento es superior a 84 Km/h., no ser&aacute; necesario el requisito que varios edificios se encuentren afectados.<br />
&middot; Inundaci&oacute;n debida a desbordamientos de cauces o cursos de agua construidos por el hombre y cuya cobertura no corresponda al Consorcio de Compensaci&oacute;n de seguros.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Da�os a los enseres del hogar que est&eacute;n depositados al aire libre, a&uacute;n cuando se hallen protegidos por materiales flexibles (lonas, pl&aacute;sticos, construcciones hinchables o similares) o contenidos en el interior de construcciones abiertas.<br />
&middot; Da�os producidos por nieve, agua, arena o el polvo que entre por puertas, ventanas u otras aberturas que est&eacute;n sin cerrar o con cierre defectuoso.<br />
&middot; Da�os producidos por heladas, frio o hielo<br />
&middot; Da�os producidos por olas o mareas, incluso cuando estos fen&oacute;menos hayan sido causados por el viento.<br />
&middot; Da�os producidos por desbordamiento o rotura de presas y diques de contenci&oacute;n.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'104','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('142','1','0','TODAS LAS CAUSAS','Uso fraudulento de tarjetas','|6|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Dentro de la garant&iacute;a de Robo y Expoliaci&oacute;n de la vivienda, AXA cubre el uso fraudulento de tarjetas de cr&eacute;dito, hasta el l&iacute;mite incluido en p&oacute;liza. <br />
<strong>Que no est&aacute; cubierto:</strong><br />
&middot; El hurto de dinero en efectivo.<br />
. El robo o hurto que afecte a enseres que se encuentren en dependencias que no sean de su uso exclusivo.<br />
&middot; P&eacute;rdidas o extrav&iacute;os<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'180','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('101','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Contrato sobre cosas Muebles','|6|8|10|','PJ','<p>Esta garant&iacute;a comprende la reclamaci&oacute;n en litigios sobre incumplimiento de contratos suscritos por el tomador del seguro o asegurado de compra, arrendamiento y dep&oacute;sito de cosas muebles, a excepci&oacute;n de las relativas a equipos inform&aacute;ticos o de telefon&iacute;a, destinadas directamente al ejercicio de la actividad descrita en la p&oacute;liza y que no sean objeto de la misma.</p>',to_date('30/11/21','DD/MM/RR'),'18','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('103','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Defensa Laboral','|6|7|8|10|','PJ','<p>Se garantiza la Defensa de los Intereses del Asegurado como Demandado en un procedimiento seguido ante la Jurisdicci&oacute;n social, promovido por alguno de sus empleados , asalariados , debidamente inscritos en el R&eacute;gimen de la Seguridad Social</p>',to_date('30/11/21','DD/MM/RR'),'6','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('141','1','0','TODAS LAS CAUSAS','Pedrisco-Nieve','|0|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Da&ntilde;os materiales a los bienes asegurados cuando se destruyan a consecuencia de los fen&oacute;menos externos de pedrisco o nieve, de intensidad tal que afecte a varios edificios de buena construcci&oacute;n en las proximidades de la vivienda asegurada. Se incluyen los da&ntilde;os producidos por objetos arrastrados o proyectados por el viento o la lluvia.<br />
&middot; Si la cantidad de lluvia es superior a 40l/m2 y hora, o la velocidad del viento es superior a 84 Km/h., no ser&aacute; necesario el requisito que varios edificios se encuentren afectados.<br />
&middot; Inundaci&oacute;n debida a desbordamientos de cauces o cursos de agua construidos por el hombre y cuya cobertura no corresponda al Consorcio de Compensaci&oacute;n de seguros.<br />
<strong>Qu&eacute; no est&aacute; cubierto:</strong><br />
&middot; Da&ntilde;os a los enseres del hogar que est&eacute;n depositados al aire libre, aun cuando se hallen protegidos por materiales flexibles (lonas, pl&aacute;sticos, construcciones hinchables o similares) o contenidos en el interior de construcciones abiertas.<br />
&middot; Da&ntilde;os producidos por nieve, agua, arena o el polvo que entre por puertas, ventanas u otras aberturas que est&eacute;n sin cerrar o con cierre defectuoso.<br />
&middot; Da&ntilde;os producidos por heladas, frio o hielo<br />
&middot; Da&ntilde;os producidos por olas o mareas, incluso cuando estos fen&oacute;menos hayan sido causados por el viento.<br />
&middot; Da&ntilde;os producidos por desbordamiento o rotura de presas y diques de contenci&oacute;n<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'106','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('104','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Defensa Penal','|6|7|','PJ','<p>Asumiremos su Defensa, si Usted o los miembros de su familia tienen que defenderse en un procedimiento penal seguido por imprudencia, como consecuencia de hechos ocurridos en el &aacute;mbito de la vida familiar cotidiana o con motivo de residir en la Edificaci&oacute;n asegurada, en aquellos supuestos en los que la defensa no est&aacute; cubierta por la garant&iacute;a de Responsabilidad Civil y con aplicaci&oacute;n de las mismas exclusiones previstas por esta garant&iacute;a.</p>',to_date('30/11/21','DD/MM/RR'),'7','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('105','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Impacto de objetos ','|6|','PJ','<p>Aquellas reclamaciones que no hubieran sido identificadas en las subcausas anteriores.</p>',to_date('30/11/21','DD/MM/RR'),'16','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('106','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Mascotas','|0|','PJ','<p>La reclamaci&oacute;n de da&ntilde;os y/o perjuicios que otras personas que no teniendo ning&uacute;n contrato con Usted, le hayan causado a su Mascota.</p>',to_date('30/11/21','DD/MM/RR'),'19','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('109','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Reclamacion al Consorcio por reh�se','|6|','PJ','<p>Aquellas reclamaciones que no hubieran sido identificadas en las subcausas anteriores.</p>',to_date('30/11/21','DD/MM/RR'),'28','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('110','1','56','RECLAMACI�N DE DA�OS A TERCEROS Protecci�n Jca.','Reclamacion al inquilino','|6|','PJ','<p>La reclamaci&oacute;n amistosa y judicial frente al arrendatario o inquilino de la vivienda asegurada, en los siguientes supuestos:<br /> 
- Impago de la renta de alquiler establecida en el contrato de arrendamiento.<br /> 
- Desahucio.<br /> 
- Reclamaci&oacute;n por da&ntilde;os ocasionados en la vivienda asegurada.</p>',to_date('30/11/21','DD/MM/RR'),'14','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('148','1','0','TODAS LAS CAUSAS','Atraco en v�a publica','|6|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
El robo fuera de la vivienda cometido con violencia o intimidaci&oacute;n hacia el asegurado o miembros de su familia de: enseres y dinero en efectivo, hasta el l&iacute;mite indicado en la p&oacute;liza<br />
<strong>No est&aacute; cubierto:</strong><br />
&middot; El Hurto de dinero en efectivo.<br />
&middot; El robo y/o hurto de los objetos de valor art&iacute;stico.<br />
&middot; El robo o hurto que afecte a enseres que se encuentren en dependencias que no sean de su uso exclusivo.<br />
&middot; El robo o hurto que afecte a joyas que se encuentren al aire libre, en patios o jardines, o en el interior de construcciones abiertas.<br />
&middot; P&eacute;rdidas o extrav&iacute;os<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'120','							Recuerda que tiene que haber amenaza o violencia hacia la persona.
																																																									 
												 
												 
												 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('8','4','5','SANCIONES','Parada o estacionamiento','|2|',null,'<p>Parar o estacionar de forma incorrecta, en doble fila , en lugar prohibido, por tiempo superior al establecido, en vado, en acera, en zona de ORA.</p>',to_date('06/04/17','DD/MM/RR'),'6',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('9','4','6','SANCIONES','Exceso de velocidad','|2|',null,'<p>Conducir con un exceso de velocidad superior al l&iacute;mite legalmente establecido por se&ntilde;al. </p>',to_date('06/04/17','DD/MM/RR'),'7',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('10','4','7','SANCIONES','Hacer uso o manipular dispositivos de telefon�a m�vil','|2|',null,'<p>Conducir manipulando o haciendo uso de dispotivos de telefon&iacute;a m&oacute;vil. </p>',to_date('06/04/17','DD/MM/RR'),'8',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('11','4','8','SANCIONES','ITV','|2|',null,'<p>Conducir sin haber pasado dentro del plazo legalmente establecido la correspondiente inspecci&oacute;n t&eacute;cnica de veh&iacute;culos. </p>',to_date('06/04/17','DD/MM/RR'),'9',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('12','4','9','SANCIONES','Circular sin alumbrado','|2|',null,'<p>Circular sin luces de corto alcance, sin alumbrado cuando las condiciones meteorol&oacute;gicas lo hacen necesario, con foco roto&#8230;. </p>',to_date('06/04/17','DD/MM/RR'),'25',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('17','4','14','SANCIONES','Circular sin respetar la distancia de seguridad','|2|',null,'<p>Circular sin guardar la pertinente distancia de seguridad entre el coche que le preced&iacute;a.</p>',to_date('06/04/17','DD/MM/RR'),'14',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('18','4','15','SANCIONES','No respetar se�alizaci�n','|2|','Stop / Ceda','<p>Circular sin haber respetado se&ntilde;ales existentes de ceda el paso o de parada obligatoria, o zona peatonal, giro prohibido, o sentido contrario.</p>',to_date('06/04/17','DD/MM/RR'),'15',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('19','4','15','SANCIONES','No respetar se�alizaci�n','|2|','Giro Prohibido','<p>Circular sin haber respetado se&ntilde;ales existentes de ceda el paso o de parada obligatoria, o zona peatonal, giro prohibido, o sentido contrario.</p>',to_date('06/04/17','DD/MM/RR'),'15',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('20','4','15','SANCIONES','No respetar se�alizaci�n','|2|','L�nea Continua','<p>Circular sin haber respetado se&ntilde;ales existentes de ceda el paso o de parada obligatoria, o zona peatonal, giro prohibido, o sentido contrario.</p>',to_date('06/04/17','DD/MM/RR'),'15',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('25','4','18','SANCIONES','Carnet de conducir','|2|','Circular con permiso extranjero','<p>Circular con un permiso de conducir que no se encuentra vigente, o no aportarlo cuando se le solicita... </p>',to_date('06/04/17','DD/MM/RR'),'21',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('30','4','15','SANCIONES','No respetar se�alizaci�n','|2|','Zona Peatonal','<p>Circular sin haber respetado se&ntilde;ales existentes de ceda el paso o de parada obligatoria, o zona peatonal, giro prohibido, o sentido contrario.</p>',to_date('06/04/17','DD/MM/RR'),'15',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('147','1','0','TODAS LAS CAUSAS','Atraco en comercio','|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
&middot; El robo y expoliaci&oacute;n producido con fuerza en las cosas para acceder a ellas o con violencia o intimidaci&oacute;n a las personas, y que afecte a: mobiliario, las mercanc&iacute;as o los da&ntilde;os materiales y desperfectos causados a los bienes asegurados durante el robo.<br />
<strong>Hasta los l&iacute;mites indicados, la garant&iacute;a se extiende a:</strong><br />
. El robo y expoliaci&oacute;n de las mercanc&iacute;as que se encuentran en escaparates independientes del negocio asegurado.<br />
&middot; El robo y expoliaci&oacute;n del dinero en efectivo o documentos bancarios acreditativos de dinero.<br />
&middot; La expoliaci&oacute;n a clientes, empleados y visitantes, cometido en el interior del negocio asegurado, incluidos los gastos de asistencia sanitaria urgente por expoliaci&oacute;n.<br />
&middot; Los gastos de reposici&oacute;n de llaves y cerraduras, por otras de similares prestaciones y caracter&iacute;sticas, si deben ser sustituidas a consecuencia de un robo como medida de precauci&oacute;n para evitar el f&aacute;cil acceso al establecimiento.<br />
&middot; La infidelidad de empleados.<br />
&middot; La expoliaci&oacute;n a cobradores o transportadores de fondos.<br />
&middot; Los gastos de puesta en orden de archivos.<br />
&middot; Los gastos de limpieza y acondicionamiento del negocio.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'119','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('7','4','4','SANCIONES','Conducci�n negligente/temeraria/indebida','|2|',null,'<p>Circular de manera negligente, o de forma temeraria realizando maniobras indebidas que causen peligro o riesgo para los usuarios de la v&iacute;a.</p>',to_date('06/04/17','DD/MM/RR'),'4',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('15','4','12','SANCIONES','Incumplimiento de las condiciones t�cnicas reglamentarias','|2|',null,'<p>Circular sin extintor cuando cuando las caracter&iacute;sticas del veh&iacute;culo lo hacen necesario, con neum&aacute;ticos en mal estado o sin llevar el separador de carga cuando sea obligatorio </p>',to_date('06/04/17','DD/MM/RR'),'16',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('16','4','13','SANCIONES','No obedecer �rdenes/ se�ales de los agentes de la autoridad','|2|',null,'<p>Circular haciendo caso omiso a las indicaciones del agente de la autoridad . </p>',to_date('06/04/17','DD/MM/RR'),'13',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('21','4','15','SANCIONES','No respetar se�alizaci�n','|2|','Sentido Contrario','<p>Circular sin haber respetado se&ntilde;ales existentes de ceda el paso o de parada obligatoria, o zona peatonal, giro prohibido, o sentido contrario.</p>',to_date('06/04/17','DD/MM/RR'),'15',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('22','4','16','SANCIONES','No tener concertado el seguro obligatorio / No constar en FIVA','|2|',null,'<p>Circular sin tener concertado seguro obligatorio legalmente establecido-no constar en fiva la matr&iacute;cula.</p>',to_date('06/04/17','DD/MM/RR'),'19',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('23','4','17','SANCIONES','Rebasar el sem�foro en rojo/�mbar','|2|',null,'<p>Circular rebasando el sem&aacute;foro en fase roja/ambar: </p>',to_date('06/04/17','DD/MM/RR'),'20',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('24','4','18','SANCIONES','Carnet de conducir','|2|','Permiso Caducado','<p>Circular con un permiso de conducir que no se encuentra vigente, o no aportarlo cuando se le solicita... </p>',to_date('06/04/17','DD/MM/RR'),'21',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('149','1','0','TODAS LAS CAUSAS','Averia de maquinaria o Equipos electr�nicos','|6|7|8|10|',null,'<p><strong>Qu&eacute; est&aacute; cubierto:</strong><br />
Los da&ntilde;os materiales directos a primer riesgo hasta el l&iacute;mite indicado en la p&oacute;liza, que sufra la maquinaria, ordenadores y/o equipos electr&oacute;nicos durante su normal utilizaci&oacute;n, como consecuencia de una causa accidental diferente al resto de las coberturas del contrato.<br />
AXA cubre los bienes asegurados desde el momento en que finalizado el montaje y realizadas las pruebas operacionales, est&aacute;n preparados para comenzar la explotaci&oacute;n normal, permaneciendo cubiertos tanto en funcionamiento como parados, durante su desmontaje y montaje subsiguiente con objeto de proceder a su limpieza, revisi&oacute;n o mantenimiento.<br />
<strong>No est&aacute;n cubiertos:</strong><br />
&middot; Los que encuentren cobertura dentro de las garant&iacute;as en la p&oacute;liza. No se podr&aacute; invocar esta cobertura como complemento a las prestaciones de dichas coberturas, ni como sustituci&oacute;n de sus l&iacute;mites o exclusiones.<br />
&middot; Los da&ntilde;os debidos al uso o desgaste normal o paulatino, as&iacute; como los sufridos por parte de las m&aacute;quinas y equipos que necesiten por su propio funcionamiento un reemplazo frecuente y los producidos por erosi&oacute;n, corrosi&oacute;n, oxidaci&oacute;n, cavitaci&oacute;n, herrumbre o incrustaciones.<br />
&middot; Los da&ntilde;os sufridos por las m&aacute;quinas y equipos de antig&uuml;edad superior a 7 a&ntilde;os.<br />
&middot; Los simples da&ntilde;os y defectos est&eacute;ticos, los que afectan a los elementos que deben ser renovados frecuentemente, los lubricantes y refrigerantes y los defectos y/o vicios ya existentes al contratar el seguro.<br />
&middot; Los da&ntilde;os por exposici&oacute;n de la maquinaria, ordenadores y/o equipos a condiciones anormales o sobrecargas intencionadas, o durante experimentos, ensayos o pruebas en los que se exijan esfuerzos superiores al normal y los causados por fallos o interrupciones en el aprovisionamiento de la energ&iacute;a avisados con antelaci&oacute;n.<br />
&middot; Los da&ntilde;os o p&eacute;rdidas de los que sea legal o contractualmente responsable el fabricante o proveedor de las maquinas y/o equipos.<br />
&middot; Los perjuicios y p&eacute;rdidas indirectas de cualquier clase.<br />
&middot; Las ca&iacute;das de equipos y elementos port&aacute;tiles.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.&#8195;<br />
</strong></p>',to_date('30/11/21','DD/MM/RR'),'123','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('123','2','7','OTROS SERVICIOS DE ASISTENCIA','Control de Plagas','|7|',null,'<p>El servicio se prestar&aacute; exclusivamente en las zonas comunes del Edificio asegurado. Se realiza un tratamiento correctivo. Se considera como tal una plaga de cucarachas, o roedores con riesgo para la salud de los vecinos de la Comunidad de propietarios del inmueble. Puede solicitar este servicio a trav&eacute;s del tel&eacute;fono: 917906351</p>',to_date('13/09/18','DD/MM/RR'),'1',null,'0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('150','1','0','TODAS LAS CAUSAS','Bricopartner','|6|',null,'<p>AXA pone a disposici&oacute;n de sus clientes un servicio de bricolaje en la vivienda asegurada, que incluye:<br />
&middot; Sellado de juntas deterioradas de su ba&ntilde;era que ocasionen humedades por filtraciones en paredes<br />
contiguas.<br />
&middot; Sustituci&oacute;n de grifos y mecanismos de cisterna.<br />
&middot; Colocaci&oacute;n y sustituci&oacute;n de l&aacute;mparas y apliques de techo y pared.<br />
&middot; Montaje de muebles kit y estanter&iacute;as.<br />
&middot; Fijaci&oacute;n de elementos a paredes, tales como cuadros o espejos.<br />
&middot; Colocaci&oacute;n de accesorios de ba&ntilde;o y cocina.<br />
&middot; Instalaci&oacute;n de cortinas, visillos, estores.<br />
&middot; Sustituci&oacute;n de enchufes o interruptores de luz por otros diferentes (sin cambios de ubicaci&oacute;n)<br />
&middot; Puesta en marcha, conectividades y configuraci&oacute;n del equipamiento tecnol&oacute;gico, TDT, DVD, C&aacute;mara Digital, Home Cinema, Video Digital, Ordenadores, TV y V&iacute;deo, Consolas.<br />
&middot; Gastos de desplazamiento de 2 visitas por anualidad de seguro de 2 horas de mano de obra gratis cada una.<br />
&middot; O los gastos de desplazamiento de 1 visita por anualidad de seguro de 4 horas de mano de obra gratis.<br />
&middot; Usted deber&aacute; hacerse cargo de los materiales empleados y en su caso, del exceso de tiempo de mano de obra que se pudiera producir.<br />
&middot; El servicio ser&aacute; prestado por la red de profesionales de AXA de lunes a viernes en horario de 9 a 22 horas.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong><br />
</p>',to_date('30/11/21','DD/MM/RR'),'177','						Recuerda que el asegurado tiene que disponer del material antes de que llegue el reparador . Se pueden utilizar varios servicios siempre que sean de la misma especialidad e impliquen la intervenci�n de un �nico operario. Recuerda que tiene dos servicios por anualidad con un m�ximo de 2 horas cada uno.
																													 
												 
												 
												 
												 
												 
						','1');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('151','1','0','TODAS LAS CAUSAS','Caida Aeronaves y/o Astronaves','|6|7|8|10|',null,'<p>Qu&eacute; est&aacute; cubierto:<br />
El choque o ca&iacute;da de un aparato a&eacute;reo o espacial o de objetos que caigan de los mismos, siempre y cuando no sean de su propiedad ni de una persona de la que Usted sea civilmente responsable.<br />
<strong>* Lo aqu&iacute; recogido responde a unas l&iacute;neas generales de contrataci&oacute;n, para el siniestro en concreto se aplicar&aacute;n las condiciones generales y particulares de la p&oacute;liza contratada por el asegurado.</strong></p>',to_date('30/11/21','DD/MM/RR'),'112','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
Insert into TWAAGCAUSA (CODAG,CODCIA,CODAGCAU,AGDECAUSA,CAUSA,CODRAMO,DESCRIPCION,AYUDA,FECHA_CREACION,CODSIRIUS,AVISO,MOSTRARAVISO) values ('123','1','7','OTROS SERVICIOS DE ASISTENCIA','Control de Plagas','|0|',null,'<p>El servicio se prestar&aacute; exclusivamente en las zonas comunes del Edificio asegurado. Se realiza un tratamiento correctivo. Se considera como tal una plaga de cucarachas, o roedores con riesgo para la salud de los vecinos de la Comunidad de propietarios del inmueble. Puede solicitar este servicio a trav&eacute;s del tel&eacute;fono: 917906351</p>',to_date('30/11/21','DD/MM/RR'),'1','																																																																					 
												 
												 
												 
												 
												 
												 
												 
												 
						','0');
